﻿export const FOOTER_PLACEHOLDER = `
<div id="footer-container" style="display:none;">
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 p-3">
                    <div class="skeleton skeleton-line"></div>
                    <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                </div>
            </div>
        </div>
    </div>
</div>
`;
