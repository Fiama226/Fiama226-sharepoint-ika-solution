export const HEADER_HTML = `
<div class="">
    <header id="header" class="d-flex align-items-center">
        <div class="container-fluid d-flex align-items-center">
            <h1 class="logo"><a href="#page-accueil"><img src="assets/imges/logo-meso.jpg"> </a></h1>
            <nav id="navbar" class="navbar order-last order-lg-0">
                <ul id="navbar-menu-list">
                    <!-- Liens chargés dynamiquement -->
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav>
            <div class="header-right d-flex align-items-center">
                <div class="sidebar ms-4">
                    <div class="sidebar-item search-form">
                        <form action="#">
                            <input type="text">
                            <button type="submit"><i class="bi bi-search"></i></button>
                        </form>
                    </div>
                </div>
                &nbsp;
                <a href="#" class="header-video-thumb">
                    <img id="header-video-thumb" src="" alt="Vidéo">
                    <span class="header-video-overlay"><i class="bi bi-play-circle-fill"></i></span>
                </a>
            </div>
        </div>
    </header>
</div>

<div id="headerVideoOverlay" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.9);z-index:99999;align-items:center;justify-content:center;">
    <button id="headerVideoClose" style="position:absolute;top:20px;right:30px;background:none;border:none;color:#fff;font-size:40px;cursor:pointer;z-index:10;">&times;</button>
    <div style="width:90%;max-width:1000px;">
        <div style="position:relative;padding-bottom:56.25%;height:0;">
            <iframe id="header-video-player" src="" frameborder="0" allowfullscreen style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe>
        </div>
    </div>
</div>
`;
