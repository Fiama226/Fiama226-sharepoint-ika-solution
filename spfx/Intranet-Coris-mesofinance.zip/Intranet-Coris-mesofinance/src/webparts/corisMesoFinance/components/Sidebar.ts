﻿export function SIDEBAR_HTML(prefix: string): string {
  return `
                <div class="agencies-box mb-3" style="flex-shrink:0;">
                    <div class="box-title">
                        <h4>Outils</h4>
                        <div class="title-border"></div>
                    </div>
                    <div class="d-flex align-items-center gap-3 flex-wrap" id="${prefix}-outils-items">
                        <div class="p-3">
                        <div class="skeleton skeleton-line"></div>
                        <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                      </div>
                    </div>
                </div>
                <div class="agencies-box annonces flex-grow-1">
                    <div class="box-title">
                        <h4>Informations financières</h4>
                        <div class="title-border"></div>
                    </div>
                    <ul class="tabs">
                        <li class="tab-link current" data-tab="${prefix}-bourse">Transfert</li>
                        <li class="tab-link" data-tab="${prefix}-device">Cash</li>
                    </ul>
                    <div id="${prefix}-bourse" class="tab-content current">
                        <div id="${prefix}-transfert-items">
                            <div class="p-3">
                        <div class="skeleton skeleton-line"></div>
                        <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                      </div>
                        </div>
                    </div>
                    <div id="${prefix}-device" class="tab-content">
                        <div id="${prefix}-cash-items">
                            <div class="p-3">
                        <div class="skeleton skeleton-line"></div>
                        <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                      </div>
                        </div>
                    </div>
                </div>`;
}
