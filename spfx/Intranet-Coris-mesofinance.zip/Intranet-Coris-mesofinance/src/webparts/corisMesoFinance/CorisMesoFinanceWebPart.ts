import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import * as strings from 'CorisMesoFinanceWebPartStrings';

/* ── CSS imports (bundled by SPFx/webpack) ─────────────────── */
import './assets/css/bootstrap.min.css';
import './assets/css/swiper-bundle.min.css';
import './assets/bootstrap-icons/bootstrap-icons.css';
import './assets/css/style2.css';

/* ── Page templates ─────────────────────────────────────────── */
import { ACCUEIL_HTML } from './pages/Accueil';
import { HEADER_HTML } from './components/Header';
import { PAGE_404_HTML } from './pages/page-404';
import { VISION_HTML } from './pages/Vision';
import { MISSION_HTML } from './pages/Mission';
import { VALEURS_HTML } from './pages/Valeurs';
import { DIRECTIONS_HTML } from './pages/Directions';
import { ORGANIGRAMME_HTML } from './pages/Organigramme';
import { TROMBINOSCOPE_HTML } from './pages/Trombinoscope';
import { POLE_BANQUE_HTML } from './pages/PoleBanque';
import { POLE_MESO_HTML } from './pages/PoleMeso';
import { POLE_BARAKA_HTML } from './pages/PoleBaraka';
import { TOUTES_LES_ACTUALITES_HTML } from './pages/toutes-les-actualites';
import { TOUS_LES_EVENEMENTS_HTML } from './pages/tous-les-evenements';
import { TOUTES_LES_ANNONCES_HTML } from './pages/toutes-les-annonces';
import { TOUT_AGENDA_HTML } from './pages/tout-agenda';
import { TOUS_LES_PRODUITS_HTML } from './pages/tous-les-produits';
import { TOUS_LES_EMPLOYES_DU_MOIS_HTML } from './pages/tous-les-employes-du-mois';
import { TOUS_LES_QUIZ_HTML } from './pages/tous-les-quiz';
import { DETAIL_ACTUALITE_HTML } from './pages/detail-actualite';
import { DETAIL_PRODUIT_HTML } from './pages/detail-produit';
import { DETAIL_EVENEMENT_HTML } from './pages/detail-evenement';
import { DETAIL_ANNONCE_HTML } from './pages/detail-annonce';
import { DETAIL_AGENDA_HTML } from './pages/detail-agenda';
import { DETAIL_EMPLOYE_DU_MOIS_HTML } from './pages/detail-employe-du-mois';
import { AGENDA_PERSONNEL_HTML } from './pages/agenda-personnel';
import { SERVICE_PARTICULIER_HTML } from './pages/service-particulier';
import { DETAIL_SERVICE_PARTICULIER_HTML } from './pages/detail-service-particulier';
import { SERVICE_ENTREPRISE_HTML } from './pages/service-entreprise';
import { DETAIL_SERVICE_ENTREPRISE_HTML } from './pages/detail-service-entreprise';
import { ENTREPRISES_HTML } from './pages/Entreprises';
import { RESEAU_AGENCES_HTML } from './pages/ReseauAgences';
import { PARTENARIATS_HTML } from './pages/Partenariats';
import { TUTORIELS_HTML } from './pages/Tutoriels';
import { DETAIL_RESEAU_AGENCE_HTML } from './pages/detail-reseau-agence';
import { DETAIL_PARTENARIAT_HTML } from './pages/detail-partenariat';
import { DETAIL_TUTORIEL_HTML } from './pages/detail-tutoriel';

/* ── Services — unique source de données ──────────────────────── */
import { loadAgenda, loadEvenements, loadDevise, loadCollaborateurs, loadCollaborateursList, loadEmployeDuMois, loadOutils, loadSurvey, loadAnnouncements, loadActualites, loadHeroSlider, loadProductSlides, loadGalerieFolders, loadGalerieImages } from './services/accueil';
import { loadVision } from './services/vision';
import { loadMission } from './services/mission';
import { loadValeur } from './services/valeur';
import { loadDirection } from './services/direction';
import { loadTrombinoscope } from './services/collaborateur';
import { loadOrganigramme } from './services/organigramme';
import { loadHeaderVideo, extractYouTubeId } from './services/headerVideo';
import { loadActualitesAll, loadActualiteDetail } from './services/actualites';
import { loadEvenementsAll, loadEvenementDetail } from './services/evenements';
import { loadAnnoncesAll, loadAnnonceDetail } from './services/annonces';
import { loadAgendaAll, loadAgendaDetail } from './services/agenda';
import { loadProduitsAll, loadProduitDetail } from './services/produits';
import { loadEmployesDuMoisAll, loadEmployeDuMoisDetail } from './services/employes-du-mois';
import { buildCommentsListHtml, parseComments } from './services/social';
import { loadSurveyAll } from './services/survey';
import { loadFooter } from './services/footer';
import { cacheInvalidate, cacheGet } from './services/cache';
import { loadHeaderMenu } from './services/headerMenu';
import { loadServicesAll, loadServiceDetail } from './services/services-particuliers';
import { loadServicesEntreprisesAll, loadServiceEntrepriseDetail } from './services/services-entreprises';
import { loadReseauAgencesAll, loadReseauAgenceDetail } from './services/reseau-agences';
import { loadPartenariatsAll, loadPartenariatDetail } from './services/partenariats';
import { loadTutorielsAll, loadTutorielDetail } from './services/tutoriels';
import { loadEntreprisesAll } from './services/entreprises';

/* ── Reference ALL files so webpack copies them to dist/ ──── */
const _assetRefs: Record<string, string> = {
  'assets/imges/artical-1.jpg': new URL('./assets/imges/artical-1.jpg', import.meta.url).toString(),
  'assets/imges/artical-2.jpg': new URL('./assets/imges/artical-2.jpg', import.meta.url).toString(),
  'assets/imges/artical-3.jpg': new URL('./assets/imges/artical-3.jpg', import.meta.url).toString(),
  'assets/imges/artical-4.jpg': new URL('./assets/imges/artical-4.jpg', import.meta.url).toString(),
  'assets/imges/cake.png':      new URL('./assets/imges/cake.png', import.meta.url).toString(),
  'assets/imges/event-1.jpg':   new URL('./assets/imges/event-1.jpg', import.meta.url).toString(),
  'assets/imges/event-2.jpg':   new URL('./assets/imges/event-2.jpg', import.meta.url).toString(),
  'assets/imges/event-3.jpg':   new URL('./assets/imges/event-3.jpg', import.meta.url).toString(),
  'assets/imges/event-4.jpg':   new URL('./assets/imges/event-4.jpg', import.meta.url).toString(),
  'assets/imges/tabs-1.jpg':    new URL('./assets/imges/tabs-1.jpg', import.meta.url).toString(),
  'assets/imges/tabs-2.png':    new URL('./assets/imges/tabs-2.png', import.meta.url).toString(),
  'assets/imges/tabs-21.jpg':   new URL('./assets/imges/tabs-21.jpg', import.meta.url).toString(),
  'assets/imges/tabs-22.jpg':   new URL('./assets/imges/tabs-22.jpg', import.meta.url).toString(),
  'assets/imges/tabs-3.png':    new URL('./assets/imges/tabs-3.png', import.meta.url).toString(),
  'assets/imges/vision.png':     new URL('./assets/imges/vision.png', import.meta.url).toString(),
  'assets/imges/mission.png':    new URL('./assets/imges/mission.png', import.meta.url).toString(),
  'assets/imges/nos_valeurs.png': new URL('./assets/imges/nos_valeurs.png', import.meta.url).toString(),
  'assets/imges/logo-holding.png':      new URL('./assets/imges/logo-holding.png', import.meta.url).toString(),
  'assets/imges/corismeso.png':         new URL('./assets/imges/corismeso.png', import.meta.url).toString(),
  'assets/imges/logo_CBI_BARAKA-scaled.jpg': new URL('./assets/imges/logo_CBI_BARAKA-scaled.jpg', import.meta.url).toString(),
  'assets/imges/logo-meso.jpg': new URL('./assets/imges/logo-meso.jpg', import.meta.url).toString(),
  'assets/imges/logo-bank.jpg': new URL('./assets/imges/logo-bank.jpg', import.meta.url).toString(),
  'assets/imges/user-1.jpg':    new URL('./assets/imges/user-1.jpg', import.meta.url).toString(),
  'assets/imges/user-2.jpg':    new URL('./assets/imges/user-2.jpg', import.meta.url).toString(),
  'assets/imges/user-3.jpg':    new URL('./assets/imges/user-3.jpg', import.meta.url).toString(),
  'assets/imges/user-4.jpg':    new URL('./assets/imges/user-4.jpg', import.meta.url).toString(),
  'assets/imges/user-5.jpg':    new URL('./assets/imges/user-5.jpg', import.meta.url).toString(),
  'assets/imges/user-6.jpg':    new URL('./assets/imges/user-6.jpg', import.meta.url).toString(),
};

const _SCRIPT_JQUERY    = new URL('./assets/js/jquery-3.7.1.min.js',   import.meta.url).toString();
const _SCRIPT_BOOTSTRAP = new URL('./assets/js/bootstrap.bundle.min.js', import.meta.url).toString();
const _SCRIPT_SWIPER    = new URL('./assets/js/swiper-bundle.min.js',  import.meta.url).toString();
const _SCRIPT_MAIN      = new URL('./assets/js/main.js',               import.meta.url).toString();
const _SCRIPT_ORGCHARTCSS  = new URL('./assets/js/jquery.orgchart.css.js',  import.meta.url).toString();
const _SCRIPT_ORGCHARTPLUGIN = new URL('./assets/js/jquery.orgchart.min.js', import.meta.url).toString();
const _SCRIPT_ORGCHART      = new URL('./assets/js/Orgchart.js',            import.meta.url).toString();

/* ── Helper: safely set innerHTML (null-safe) ───────────────── */
function setContent(id: string, html: string): void {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}

export interface ICorisMesoFinanceWebPartProps {
  description: string;
}

export default class CorisMesoFinanceWebPart extends BaseClientSideWebPart<ICorisMesoFinanceWebPartProps> {
  private _observer: MutationObserver | null = null;
  private _currentPage: string = '';
  private _collabItems: Array<Record<string, unknown>> = [];
  private _trombinoscopeItems: Array<Record<string, unknown>> = [];
  private _scriptsPromise: Promise<void> | null = null;
  private _routerBound = false;
  private _boundHashChange: (() => void) | null = null;
  private _videoUrl: string = '';
  private _galleryImages: any[] = [];
  private _galleryIndex: number = 0;
  private _socialModalBound = false;
  private _socialModalContext: {
    siteUrl: string;
    listName: string;
    itemId: number;
    userEmail: string;
    userDisplayName: string;
    prefix: string;
  } | null = null;
  private _groupNewsSwiperInitialized = false;
  private _shellInitialized = false;

  /* ══════════════════════════════════════════════════════════════
     ROUTING MODERNE — hashchange + clics interception
     ══════════════════════════════════════════════════════════════ */

  private _initRouter(): void {
    if (this._routerBound) return;
    this._routerBound = true;

    // Intercepter les clics sur les liens #page-*
    this.domElement.addEventListener('click', (e: MouseEvent) => {
      const link = (e.target as HTMLElement).closest('a[href^="#page-"]') as HTMLAnchorElement | null;
      if (!link) return;
      e.preventDefault();
      const page = link.getAttribute('href')?.replace('#page-', '') || '';
      if (page) {
        window.location.hash = `page-${page}`;
      }
    });

    // Modal profil collaborateur – ouverture au clic sur une carte
    this.domElement.addEventListener('click', (e: MouseEvent) => {
      const card = (e.target as HTMLElement).closest('.staff-director[data-collab-name]') as HTMLElement | null;
      if (!card) return;
      e.preventDefault();
      const get = (attr: string) => card.getAttribute(`data-collab-${attr}`) || '';
      const img = document.getElementById('collab-modal-img') as HTMLImageElement;
      const fallback = document.getElementById('collab-modal-img-fallback') as HTMLElement;
      const imgUrl = get('image');
      if (img && fallback) {
        if (imgUrl) {
          img.src = imgUrl;
          img.style.display = '';
          fallback.style.display = 'none';
          img.onerror = () => { img.style.display = 'none'; fallback.style.display = ''; };
        } else {
          img.style.display = 'none';
          fallback.style.display = '';
        }
      }
      const nameEl = document.getElementById('collab-modal-name');
      if (nameEl) nameEl.textContent = get('name');
      const posEl = document.getElementById('collab-modal-position');
      if (posEl) posEl.textContent = get('position');
      const emailVal = get('email');
      const emailEl = document.getElementById('collab-modal-email');
      if (emailEl) emailEl.textContent = emailVal;
      const chatEl = document.getElementById('collab-modal-chat-val');
      if (chatEl) chatEl.textContent = emailVal;
      const phoneVal = get('phone');
      const phoneEl = document.getElementById('collab-modal-phone');
      if (phoneEl) phoneEl.textContent = phoneVal;
      const divEl = document.getElementById('collab-modal-division');
      if (divEl) divEl.textContent = get('division');
      const jobEl = document.getElementById('collab-modal-jobtitle');
      if (jobEl) jobEl.textContent = get('position');
      const emailLink = document.getElementById('collab-modal-email-link') as HTMLAnchorElement;
      if (emailLink) emailLink.href = `mailto:${emailVal}`;
      const phoneLink = document.getElementById('collab-modal-phone-link') as HTMLAnchorElement;
      if (phoneLink) phoneLink.href = `tel:${phoneVal}`;
      const chatLink = document.getElementById('collab-modal-chat') as HTMLAnchorElement;
      if (chatLink) chatLink.href = `mailto:${emailVal}`;
      const modal = document.getElementById('collabProfileModal');
      if (modal) {
        document.body.appendChild(modal);
        if (this._observer) this._observer.disconnect();
        const bs = (window as any).bootstrap;
        if (bs && bs.Modal) {
          const bsModal = new bs.Modal(modal);
          bsModal.show();
          modal.addEventListener('hidden.bs.modal', () => { this._reconnectObserver(); }, { once: true });
        } else {
          modal.classList.add('show');
          modal.style.display = 'block';
          modal.removeAttribute('aria-hidden');
          document.body.classList.add('modal-open');
          const backdrop = document.createElement('div');
          backdrop.className = 'modal-backdrop fade show';
          document.body.appendChild(backdrop);
          const closeModal = () => {
            modal.classList.remove('show');
            modal.style.display = 'none';
            modal.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('modal-open');
            const bd = document.querySelector('.modal-backdrop');
            if (bd) bd.remove();
            this._reconnectObserver();
          };
          const closeBtn = modal.querySelector('.collab-modal-close');
          if (closeBtn) closeBtn.addEventListener('click', closeModal);
          modal.addEventListener('click', (ev: MouseEvent) => { if (ev.target === modal) closeModal(); });
        }
      }
    });

    // Modal détail collaborateur (tableau) – ouverture au clic sur une ligne
    this.domElement.addEventListener('click', (e: MouseEvent) => {
      const row = (e.target as HTMLElement).closest('tr[data-detail-name]') as HTMLElement | null;
      if (!row) return;
      e.preventDefault();
      const get = (attr: string) => row.getAttribute(`data-detail-${attr}`) || '';
      const img = document.getElementById('collab-detail-img') as HTMLImageElement;
      const fallback = document.getElementById('collab-detail-img-fallback') as HTMLElement;
      const imgUrl = get('image');
      if (img && fallback) {
        if (imgUrl) {
          img.src = imgUrl;
          img.style.display = '';
          fallback.style.display = 'none';
          img.onerror = () => { img.style.display = 'none'; fallback.style.display = ''; };
        } else {
          img.style.display = 'none';
          fallback.style.display = '';
        }
      }
      const nameEl = document.getElementById('collab-detail-name');
      if (nameEl) nameEl.textContent = get('name');
      const jobEl = document.getElementById('collab-detail-jobtitle');
      if (jobEl) jobEl.textContent = get('jobtitle');
      const mailVal = get('mail');
      const mailEl = document.getElementById('detail-mail');
      if (mailEl) mailEl.textContent = mailVal;
      const phonesEl = document.getElementById('detail-business-phones');
      if (phonesEl) phonesEl.textContent = get('phones');
      const mobileEl = document.getElementById('detail-mobile');
      if (mobileEl) mobileEl.textContent = get('mobile');
      const deptEl = document.getElementById('detail-department');
      if (deptEl) deptEl.textContent = get('department');
      const officeEl = document.getElementById('detail-office');
      if (officeEl) officeEl.textContent = get('office');
      const countryEl = document.getElementById('detail-country');
      if (countryEl) countryEl.textContent = get('country');
      const givenEl = document.getElementById('detail-given');
      if (givenEl) givenEl.textContent = get('given');
      const surnameEl = document.getElementById('detail-surname');
      if (surnameEl) surnameEl.textContent = get('surname');
      const filialeEl = document.getElementById('detail-filiale');
      if (filialeEl) filialeEl.textContent = get('filiale');
      const emailLink = document.getElementById('detail-email-link') as HTMLAnchorElement;
      if (emailLink) emailLink.href = `mailto:${mailVal}`;
      const phoneLink = document.getElementById('detail-phone-link') as HTMLAnchorElement;
      if (phoneLink) phoneLink.href = `tel:${get('mobile')}`;
      const chatLink = document.getElementById('detail-chat') as HTMLAnchorElement;
      if (chatLink) chatLink.href = `mailto:${mailVal}`;
      const modal = document.getElementById('collabDetailModal');
      if (modal) {
        document.body.appendChild(modal);
        if (this._observer) this._observer.disconnect();
        const bs = (window as any).bootstrap;
        if (bs && bs.Modal) {
          const bsModal = new bs.Modal(modal);
          bsModal.show();
          modal.addEventListener('hidden.bs.modal', () => { this._reconnectObserver(); }, { once: true });
        } else {
          modal.classList.add('show');
          modal.style.display = 'block';
          modal.removeAttribute('aria-hidden');
          document.body.classList.add('modal-open');
          const backdrop = document.createElement('div');
          backdrop.className = 'modal-backdrop fade show';
          document.body.appendChild(backdrop);
          const closeModal = () => {
            modal.classList.remove('show');
            modal.style.display = 'none';
            modal.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('modal-open');
            const bd = document.querySelector('.modal-backdrop');
            if (bd) bd.remove();
            this._reconnectObserver();
          };
          const closeBtn = modal.querySelector('.collab-modal-close');
          if (closeBtn) closeBtn.addEventListener('click', closeModal);
          modal.addEventListener('click', (ev: MouseEvent) => { if (ev.target === modal) closeModal(); });
        }
      }
    });

    // Réagir au changement de hash (bouton Précédent/Suivant du navigateur)
    this._boundHashChange = (): void => {
      const hash = window.location.hash.replace('#', '');
      if (hash.startsWith('page-')) {
        const page = hash.replace('page-', '');
        if (page && page !== this._currentPage) {
          void this._renderPage(page);
        }
      }
    };
    window.addEventListener('hashchange', this._boundHashChange);
  }

  /* ══════════════════════════════════════════════════════════════
     SHAREPOINT CONSTRAINTS
     ══════════════════════════════════════════════════════════════ */

  private _removeSharePointConstraints(): void {
    const el = this.domElement;
    if (!el) return;

    const suiteBar = document.getElementById('suiteBarDelta');
    const suiteBarHeight = (suiteBar && suiteBar.offsetHeight > 0) ? suiteBar.offsetHeight : 48;

    el.style.setProperty('position', 'fixed', 'important');
    el.style.setProperty('top', suiteBarHeight + 'px', 'important');
    el.style.setProperty('left', '0', 'important');
    el.style.setProperty('width', '100vw', 'important');
    el.style.setProperty('height', 'calc(100vh - ' + suiteBarHeight + 'px)', 'important');
    el.style.setProperty('max-width', '100vw', 'important');
    el.style.setProperty('max-height', 'calc(100vh - ' + suiteBarHeight + 'px)', 'important');
    el.style.setProperty('margin', '0', 'important');
    el.style.setProperty('padding', '0', 'important');
    el.style.setProperty('z-index', '1', 'important');
    el.style.setProperty('overflow-y', 'auto', 'important');
    el.style.setProperty('overflow-x', 'hidden', 'important');
    el.style.setProperty('background', '#fff', 'important');

    if (suiteBar) {
      suiteBar.style.setProperty('position', 'fixed', 'important');
      suiteBar.style.setProperty('top', '0', 'important');
      suiteBar.style.setProperty('left', '0', 'important');
      suiteBar.style.setProperty('width', '100vw', 'important');
      suiteBar.style.setProperty('z-index', '99999', 'important');
    }

    document.documentElement.style.setProperty('margin', '0', 'important');
    document.documentElement.style.setProperty('padding', '0', 'important');
    document.documentElement.style.setProperty('overflow-x', 'hidden', 'important');
    document.documentElement.style.setProperty('background', '#fff', 'important');

    document.body.style.setProperty('margin', '0', 'important');
    document.body.style.setProperty('padding', '0', 'important');
    document.body.style.setProperty('overflow-x', 'hidden', 'important');
    document.body.style.setProperty('background', '#fff', 'important');

    const hideById = (id: string): void => {
      const node = document.getElementById(id);
      if (node) {
        node.style.setProperty('display', 'none', 'important');
        node.style.setProperty('height', '0', 'important');
        node.style.setProperty('min-height', '0', 'important');
        node.style.setProperty('overflow', 'hidden', 'important');
      }
    };

    hideById('sideNavBox');
    hideById('footer');
    hideById('globalNavBox');
    hideById('DeltaTopNavigation');
    hideById('DeltaSuiteNavigation');
    hideById('workbench-page');

    const contentBox = document.getElementById('contentBox');
    if (contentBox) {
      contentBox.style.setProperty('margin-left', '0', 'important');
      contentBox.style.setProperty('padding', '0', 'important');
      contentBox.style.setProperty('max-width', 'none', 'important');
      contentBox.style.setProperty('width', '100%', 'important');
    }

    const deltaSPContent = document.getElementById('DeltaSPPageContentArea');
    if (deltaSPContent) deltaSPContent.style.setProperty('padding', '0', 'important');

    let parent = el.parentElement;
    while (parent && parent !== document.body) {
      parent.style.setProperty('max-width', 'none', 'important');
      parent.style.setProperty('width', '100%', 'important');
      parent.style.setProperty('padding-left', '0', 'important');
      parent.style.setProperty('padding-right', '0', 'important');
      parent.style.setProperty('padding-top', '0', 'important');
      parent.style.setProperty('padding-bottom', '0', 'important');
      parent.style.setProperty('margin-left', '0', 'important');
      parent.style.setProperty('margin-right', '0', 'important');
      parent.style.setProperty('margin-top', '0', 'important');
      parent.style.setProperty('margin-bottom', '0', 'important');
      parent.style.setProperty('overflow', 'visible', 'important');
      parent = parent.parentElement;
    }

    this._hideSharePointCanvasBelow();
  }

  /** Masque les elements SharePoint sous le webpart. */
  private _hideSharePointCanvasBelow(): void {
    const el = this.domElement;
    if (!el) return;

    const hide = (node: Element | null | undefined): void => {
      if (!node || node === el || el.contains(node) || node.contains(el)) return;
      (node as HTMLElement).style.setProperty('display', 'none', 'important');
    };

    const canvas = document.getElementById('spPageCanvasContent');
    if (canvas) {
      canvas.style.setProperty('padding-bottom', '0', 'important');
      canvas.style.setProperty('margin-bottom', '0', 'important');
      canvas.style.setProperty('min-height', '0', 'important');
    }

    const section = el.closest('[data-automation-id="CanvasSection"], .CanvasSection') as HTMLElement | null;
    if (section) {
      section.style.setProperty('padding-bottom', '0', 'important');
      section.style.setProperty('margin-bottom', '0', 'important');
      section.style.setProperty('min-height', '0', 'important');

      let sibling = section.nextElementSibling;
      while (sibling) {
        const next = sibling.nextElementSibling;
        hide(sibling);
        sibling = next;
      }
    }

    const controlZone = el.closest('.ControlZone, [data-automation-id="CanvasControl"]');
    if (controlZone?.parentElement) {
      let zoneSibling = controlZone.nextElementSibling;
      while (zoneSibling) {
        const next = zoneSibling.nextElementSibling;
        hide(zoneSibling);
        zoneSibling = next;
      }
    }

    document.querySelectorAll(
      '[data-automation-id="CanvasZone-SectionToolbar"],' +
      '[data-automation-id="insertZone"],' +
      '[data-automation-id="pageFooter"],' +
      '[data-sp-feature-region],' +
      '#CommentsWrapper,' +
      '.sp-pageLayout-pageFooter,' +
      '#footer,' +
      '.sp-pageLayout-spacer,' +
      '#spLeftNav,' +
      '.sp-pageLayout-leftNav'
    ).forEach(hide);

    // Masquer la toolbar d'édition du webpart (pencil/copy/trash)
    const webpartZone = el.closest('.sp-webpart-zone, [data-sp-feature-region], .sp-webpart');
    if (webpartZone) {
      const toolbar = webpartZone.querySelector('[data-automation-id="CanvasZone-SectionToolbar"], .sp-webpart-toolbar, .sp-webpart-header');
      if (toolbar) (toolbar as HTMLElement).style.setProperty('display', 'none', 'important');
    }
    // Masquer toutes les toolbars potentielles au-dessus du contenu
    el.querySelectorAll('[data-automation-id="CanvasZone-SectionToolbar"], .sp-webpart-toolbar').forEach((t) => {
      (t as HTMLElement).style.setProperty('display', 'none', 'important');
    });

    const footer = el.querySelector('.footer') as HTMLElement | null;
    if (footer) {
      footer.style.setProperty('margin-bottom', '0', 'important');
    }
  }

  /* ══════════════════════════════════════════════════════════════
     TEMPLATE & ASSETS
     ══════════════════════════════════════════════════════════════ */

  private _getTemplate(page: string): string {
    // Extraire le nom de la page (avant &id=xxx)
    const cleanPage = page.split('&')[0];
    switch (cleanPage) {
      case 'vision':        return VISION_HTML;
      case 'mission':       return MISSION_HTML;
      case 'valeur':        return VALEURS_HTML;
      case 'valeurs':       return VALEURS_HTML;
      case 'direction':     return DIRECTIONS_HTML;
      case 'directions':    return DIRECTIONS_HTML;
      case 'organigramme':  return ORGANIGRAMME_HTML;
      case 'trombinoscope': return TROMBINOSCOPE_HTML;
      case 'pole-banque':   return POLE_BANQUE_HTML;
      case 'pole-meso':     return POLE_MESO_HTML;
      case 'pole-baraka':   return POLE_BARAKA_HTML;
      case 'accueil':      return ACCUEIL_HTML;
      // Pages "Toutes les..."
      case 'toutes-les-actualites':      return TOUTES_LES_ACTUALITES_HTML;
      case 'tous-les-evenements':        return TOUS_LES_EVENEMENTS_HTML;
      case 'toutes-les-annonces':        return TOUTES_LES_ANNONCES_HTML;
      case 'tout-agenda':                return TOUT_AGENDA_HTML;
      case 'tous-les-produits':          return TOUS_LES_PRODUITS_HTML;
      case 'tous-les-employes-du-mois':  return TOUS_LES_EMPLOYES_DU_MOIS_HTML;
      case 'tous-les-quiz':                return TOUS_LES_QUIZ_HTML;
      // Pages Détail
      case 'detail-actualite':           return DETAIL_ACTUALITE_HTML;
      case 'detail-produit':             return DETAIL_PRODUIT_HTML;
      case 'detail-evenement':           return DETAIL_EVENEMENT_HTML;
      case 'detail-annonce':             return DETAIL_ANNONCE_HTML;
      case 'detail-agenda':              return DETAIL_AGENDA_HTML;
      case 'detail-employe-du-mois':     return DETAIL_EMPLOYE_DU_MOIS_HTML;
      case 'agenda-personnel':           return AGENDA_PERSONNEL_HTML;
      case 'service-particulier':        return SERVICE_PARTICULIER_HTML;
      case 'detail-service-particulier': return DETAIL_SERVICE_PARTICULIER_HTML;
      case 'service-entreprise':         return SERVICE_ENTREPRISE_HTML;
      case 'detail-service-entreprise':  return DETAIL_SERVICE_ENTREPRISE_HTML;
      case 'entreprises':                return ENTREPRISES_HTML;
      case 'reseau-agences':             return RESEAU_AGENCES_HTML;
      case 'partenariats':               return PARTENARIATS_HTML;
      case 'tutoriels':                  return TUTORIELS_HTML;
      case 'detail-reseau-agence':       return DETAIL_RESEAU_AGENCE_HTML;
      case 'detail-partenariat':         return DETAIL_PARTENARIAT_HTML;
      case 'detail-tutoriel':            return DETAIL_TUTORIEL_HTML;
      default:              return PAGE_404_HTML;
    }
  }

  private _resolveAssets(html: string): string {
    const siteUrl = this.context.pageContext.web.absoluteUrl;
    html = html.split('{siteUrl}').join(siteUrl);

    Object.keys(_assetRefs).forEach((path) => {
      html = html.split(path).join(_assetRefs[path]);
    });
    return html;
  }

  private _openTeamsCalendarWeb(): void {
    window.open('https://teams.microsoft.com/v2/#/calendarv2', '_blank', 'noopener,noreferrer');
  }

  private _openTeamsCalendarApp(): void {
    const abortController = new AbortController();
    const fallbackTimer = window.setTimeout(() => {
      if (!document.hidden) {
        this._openTeamsCalendarWeb();
      }
    }, 1200);

    const clearFallback = (): void => {
      window.clearTimeout(fallbackTimer);
      abortController.abort();
    };

    window.addEventListener('blur', clearFallback, { once: true, signal: abortController.signal });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) clearFallback();
    }, { once: true, signal: abortController.signal });
    window.location.href = 'msteams://teams.microsoft.com/v2/#/calendarv2';
  }

  private _autoOpenTeamsCalendarApp(): void {
    window.setTimeout(() => {
      window.location.href = 'msteams://teams.microsoft.com/v2/#/calendarv2';
    }, 300);
  }

  /* ══════════════════════════════════════════════════════════════
     SCRIPT LOADING (une seule fois)
     ══════════════════════════════════════════════════════════════ */

  private _loadScripts(): Promise<void> {
    const win = window as any;
    const originalDefine = win.define;
    let currentDefine = originalDefine;

    if (originalDefine) {
      Object.defineProperty(win, 'define', {
        get: () => {
          const customDefine = (...args: any[]) => {
            const isAnonymous = args.length > 0 && typeof args[0] !== 'string';
            if (isAnonymous) {
              return;
            }
            return currentDefine.apply(win, args);
          };
          (customDefine as any).amd = originalDefine.amd;
          return customDefine;
        },
        set: (val) => {
          currentDefine = val;
        },
        configurable: true
      });
    }

    return this._loadScript(_SCRIPT_JQUERY)
      .then(() => this._loadScript(_SCRIPT_BOOTSTRAP))
      .then(() => this._loadScript(_SCRIPT_SWIPER))
      .then(() => this._loadScript(_SCRIPT_MAIN))
      .then(() => this._loadScript(_SCRIPT_ORGCHARTCSS))
      .then(() => this._loadScript(_SCRIPT_ORGCHARTPLUGIN))
      .then(() => this._loadScript(_SCRIPT_ORGCHART))
      .then(() => {
        if (originalDefine) {
          Object.defineProperty(win, 'define', {
            value: currentDefine,
            writable: true,
            configurable: true
          });
        }
      })
      .catch((err) => {
        if (originalDefine) {
          Object.defineProperty(win, 'define', {
            value: currentDefine,
            writable: true,
            configurable: true
          });
        }
        throw err;
      });
  }

  private _loadScript(url: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = url;
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('Failed: ' + url));
      document.head.appendChild(script);
    });
  }

  /* ══════════════════════════════════════════════════════════════
     PLUGINS INIT (Swiper, Tabs, Accordion)
     ══════════════════════════════════════════════════════════════ */

  private _initGroupNewsSwiper(): void {
    if (this._groupNewsSwiperInitialized) return;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const Swiper: any = (window as any).Swiper;
    if (!Swiper) return;

    new Swiper('.group-news', {
      slidesPerView: 4,
      spaceBetween: 16,
      autoplay: { delay: 2500, disableOnInteraction: false },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
    this._groupNewsSwiperInitialized = true;
  }

  private _initSwiper(): void {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const Swiper: any = (window as any).Swiper;
    if (!Swiper) return;

    // Slider actualités du groupe
    this._initGroupNewsSwiper();

    // Hero slider
    new Swiper('.VisionSwiper', {
      loop: true,
      autoplay: { delay: 4000, disableOnInteraction: false },
    });

    // Slider vertical produits
    new Swiper('.verticalSwiper', {
      direction: 'vertical',
      loop: true,
      autoplay: { delay: 3000, disableOnInteraction: false },
      slidesPerView: 2,
      spaceBetween: 10,
    });
  }

  private _loadSidebar(prefix: string, siteUrl: string): void {
    const setContent = (id: string, html: string) => {
      const el = document.getElementById(id);
      if (el) el.innerHTML = html;
    };
    loadOutils(siteUrl)
      .then((h) => setContent(prefix + '-outils-items', this._resolveAssets(h)))
      .catch((e) => console.error('[Coris Meso Finance] Sidebar Outils:', e));
    loadDevise(siteUrl)
      .then(({ transfert, cash }) => {
        setContent(prefix + '-transfert-items', this._resolveAssets(transfert));
        setContent(prefix + '-cash-items', this._resolveAssets(cash));
        this._initTabs();
      })
      .catch((e) => console.error('[Coris Meso Finance] Sidebar Devise:', e));
  }

  private _initTabs(): void {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const $: any = (window as any).$;
    if (!$) return;

    const $contexts = $('.agencies-box.annonces, .annonces').each(function (this: HTMLElement) {
      const $box = $(this);
      $box.find('ul.tabs li').on('click', function (this: HTMLElement) {
        const tabId = $(this).attr('data-tab');
        $box.find('ul.tabs li').removeClass('current');
        $box.find('.tab-content').removeClass('current');
        $(this).addClass('current');
        $box.find('#' + tabId).addClass('current');
      });
    });
  }

  private _initDirectionAccordion(): void {
    const accordion = document.getElementById('accordionDirections');
    if (!accordion) return;

    accordion.addEventListener('click', (e: MouseEvent) => {
      const btn = (e.target as HTMLElement).closest('button[data-bs-target]') as HTMLButtonElement | null;
      if (!btn) return;

      const targetId = btn.getAttribute('data-bs-target');
      if (!targetId) return;

      const target = document.getElementById(targetId.substring(1));
      if (!target) return;

      const isOpen = target.classList.contains('show');

      accordion.querySelectorAll('.accordion-collapse.show').forEach((el) => {
        if (el.id !== targetId.substring(1)) {
          el.classList.remove('show');
          const otherBtn = accordion.querySelector('[data-bs-target="#' + el.id + '"]') as HTMLButtonElement | null;
          if (otherBtn) {
            otherBtn.classList.add('collapsed');
            otherBtn.setAttribute('aria-expanded', 'false');
          }
        }
      });

      if (isOpen) {
        target.classList.remove('show');
        btn.classList.add('collapsed');
        btn.setAttribute('aria-expanded', 'false');
      } else {
        target.classList.add('show');
        btn.classList.remove('collapsed');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  }

  /* ══════════════════════════════════════════════════════════════
     COLLABORATEUR FILTERS (UI uniquement)
     ══════════════════════════════════════════════════════════════ */

  private _initCollabFilters(): void {
    const nomInput = document.getElementById('collab-filter-nom') as HTMLInputElement;
    const deptSelect = document.getElementById('collab-filter-dept') as HTMLSelectElement;
    const searchBtn = document.getElementById('collab-search-btn');

    if (!nomInput && !deptSelect) return;

    const applyFilter = (): void => {
      const nom = nomInput ? nomInput.value.toLowerCase() : '';
      const dept = deptSelect ? deptSelect.value : '';

      const filtered = this._collabItems.filter((item: Record<string, unknown>) => {
        const displayName = String(item.displayName || item.givenName || item.Title || '').toLowerCase();
        const surname = String(item.surname || '').toLowerCase();
        const deptVal = String(item.department || '');
        const matchNom = !nom || displayName.indexOf(nom) !== -1 || surname.indexOf(nom) !== -1;
        const matchDept = !dept || deptVal === dept;
        return matchNom && matchDept;
      });

      // Update count
      const countEl = document.getElementById('collab-count');
      if (countEl) {
        countEl.textContent = filtered.length + ' collaborateur' + (filtered.length > 1 ? 's' : '');
      }

      this._renderCollaborateurs(filtered);
    };

    if (searchBtn) searchBtn.addEventListener('click', applyFilter);
    if (nomInput) nomInput.addEventListener('keyup', (e: KeyboardEvent) => { if (e.key === 'Enter') applyFilter(); });
    if (deptSelect) deptSelect.addEventListener('change', applyFilter);
  }

  private _initTrombinoscopeFilters(): void {
    const searchInput = document.getElementById('searchByNameInput') as HTMLInputElement;
    const letterBtns = document.querySelectorAll('#trombinoscope-letter-buttons .btn');

    const applyFilter = (letter?: string): void => {
      const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';

      const filtered = this._trombinoscopeItems.filter((item) => {
        const displayName = String(item.displayName || '').toLowerCase();
        const givenName = String(item.givenName || '').toLowerCase();
        const surname = String(item.surname || '').toLowerCase();
        const fullName = displayName || `${givenName} ${surname}`.trim() || '';

        const matchSearch = !searchTerm || fullName.indexOf(searchTerm) !== -1;
        const matchLetter = !letter || fullName.startsWith(letter.toLowerCase());
        return matchSearch && matchLetter;
      });

      this._renderTrombinoscope(filtered);
    };

    if (searchInput) {
      searchInput.addEventListener('keyup', (e: KeyboardEvent) => { if (e.key === 'Enter') applyFilter(); });
    }

    const searchForm = document.getElementById('searchByNameForm');
    if (searchForm) {
      searchForm.addEventListener('submit', (e) => { e.preventDefault(); applyFilter(); });
    }

    letterBtns.forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const letter = (e.currentTarget as HTMLElement).textContent || '';
        applyFilter(letter);
      });
    });
  }

  private _renderTrombinoscope(items: Array<Record<string, unknown>>): void {
    const container = document.getElementById('trombinoscope-content');
    if (!container) return;

    if (items.length === 0) {
      container.innerHTML = '<p class="text-center text-muted p-3">Aucun collaborateur trouvé</p>';
      return;
    }

    const html = items.map((item) => {
      const displayName = String(item.displayName || '');
      const givenName = String(item.givenName || '');
      const surname = String(item.surname || '');
      const fullName = displayName || `${givenName} ${surname}`.trim() || 'Nom Prénom';
      const jobTitle = String(item.jobTitle || '');
      const department = String(item.department || '');
      const imageUrl = String(item._imageUrl || '');

      const imgHtml = imageUrl
        ? `<img src="${imageUrl}" class="card-img-top" alt="Photo de ${fullName}">`
        : `<div class="card-img-top d-flex align-items-center justify-content-center" style="background:#f0f0f0;"><i class="bi bi-person-circle" style="font-size:80px;color:#004991;"></i></div>`;

      return `
            <div class="col-md-3 mb-3">
              <div class="card h-100">
                ${imgHtml}
                <div class="card-body">
                  <h5 class="card-title">${fullName}</h5>
                  <p class="card-text">${jobTitle}</p>
                  <p class="card-text">${department}</p>
                </div>
              </div>
            </div>`;
    }).join('');

    container.innerHTML = html;
  }

  private _renderCollaborateurs(items: Array<Record<string, unknown>>): void {
    const tbody = document.getElementById('collaborateurs-tbody');
    if (!tbody) return;

    if (items.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted p-3">Aucun collaborateur</td></tr>';
      return;
    }

    const rows = items.map((item: Record<string, unknown>) => {
      const imageUrl = String(item._imageUrl || '');
      const imgHtml = imageUrl
        ? '<div class="table-user"><img src="' + imageUrl + '"></div>'
        : '<div class="table-user d-flex align-items-center justify-content-center" style="width:24px;height:24px"><i class="bi bi-person-circle" style="font-size:24px;color:#004991"></i></div>';
      const esc = (s: string) => s.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
      const givenName = String(item.givenName || item.displayName || '');
      const surname = String(item.surname || '');
      const mail = String(item.mail || '');
      const jobTitle = String(item.jobTitle || '');
      const dept = String(item.department || '');
      const phones = String(item.businessPhones || '');
      const office = String(item.officeLocation || '');
      const mobile = String(item.mobilePhone || '');
      const country = String(item.country || '');
      const filiale = String(item.NomFiliales || '');

      return `
        <tr role="button" tabindex="0"
          data-detail-image="${esc(imageUrl)}"
          data-detail-name="${esc(givenName + ' ' + surname)}"
          data-detail-given="${esc(givenName)}"
          data-detail-surname="${esc(surname)}"
          data-detail-mail="${esc(mail)}"
          data-detail-jobtitle="${esc(jobTitle)}"
          data-detail-department="${esc(dept)}"
          data-detail-phones="${esc(phones)}"
          data-detail-office="${esc(office)}"
          data-detail-mobile="${esc(mobile)}"
          data-detail-country="${esc(country)}"
          data-detail-filiale="${esc(filiale)}">
          <td>${imgHtml}</td>
          <td>${givenName}</td>
          <td>${surname}</td>
          <td>${mail}</td>
          <td>${jobTitle}</td>
          <td>${dept}</td>
          <td>${phones}</td>
          <td>${office}</td>
          <td>${mobile}</td>
        </tr>`;
    }).join('');

    tbody.innerHTML = rows;
  }

  /* ══════════════════════════════════════════════════════════════
     DATA LOADING — via les services uniquement
     ══════════════════════════════════════════════════════════════ */

  private async _loadAccueilData(siteUrl: string): Promise<void> {
    const userEmail = this.context.pageContext.user?.email || '';
    const userDisplay = this.context.pageContext.user?.displayName || '';

    await Promise.all([
      // Agenda
      loadAgenda(siteUrl)
        .then((html) => setContent('agenda-items', html))
        .catch((e) => console.error('[Coris Meso Finance] Agenda:', e)),

      // Événements
      loadEvenements(siteUrl)
        .then((html) => setContent('evenements-items', this._resolveAssets(html)))
        .catch((e) => console.error('[Coris Meso Finance] Evenements:', e)),

      // Informations financières (devises)
      loadDevise(siteUrl)
        .then(({ transfert, cash }) => {
          setContent('transfert-items', this._resolveAssets(transfert));
          setContent('cash-items', this._resolveAssets(cash));
        })
        .catch((e) => console.error('[Coris Meso Finance] Devise:', e)),

      // Nouveaux collaborateurs
      loadCollaborateurs(siteUrl)
        .then((html) => setContent('collaborateurs-items', this._resolveAssets(html)))
        .catch((e) => console.error('[Coris Meso Finance] Nouveaux collab.:', e)),

      // Employé du mois
      loadEmployeDuMois(siteUrl, userEmail, userDisplay)
        .then((html) => setContent('employe-mois', this._resolveAssets(html)))
        .catch((e) => console.error('[Coris Meso Finance] Employé du mois:', e)),

      // Outils
      loadOutils(siteUrl)
        .then((html) => setContent('outils-items', this._resolveAssets(html)))
        .catch((e) => console.error('[Coris Meso Finance] Outils:', e)),

      // Sondages/Quiz
      loadSurvey(siteUrl)
        .then((html) => setContent('survey-items', html))
        .catch((e) => console.error('[Coris Meso Finance] Survey:', e)),

      // Annonces
      loadAnnouncements(siteUrl, userEmail, userDisplay)
        .then((annonces) => {
          const map: Record<string, string> = {
            birthday: 'annonces-birthday',
            mariage: 'annonces-mariage',
            death: 'annonces-death',
            other: 'annonces-other',
          };
          Object.keys(map).forEach((key) => {
            setContent(map[key], this._resolveAssets(annonces[key] || ''));
          });
        })
        .catch((e) => console.error('[Coris Meso Finance] Annonces:', e)),

      // Actualités du groupe
      loadActualites(siteUrl)
        .then((html) => {
          setContent('actualites-items', html);
          this._initGroupNewsSwiper();
        })
        .catch((e) => console.error('[Coris Meso Finance] Actualités:', e)),

      // Hero slider
      loadHeroSlider(siteUrl)
        .then((html) => setContent('hero-slider-items', this._resolveAssets(html)))
        .catch((e) => console.error('[Coris Meso Finance] Hero slider:', e)),

      // Product slides (vertical)
      loadProductSlides(siteUrl)
        .then(({ slides }) => setContent('hero-vertical-items', this._resolveAssets(slides)))
        .catch((e) => console.error('[Coris Meso Finance] Product slides:', e)),

      // Collaborateurs (tableau avec filtres)
      loadCollaborateursList(siteUrl)
        .then((result) => {
          const tbody = document.getElementById('collaborateurs-tbody');
          if (tbody) tbody.innerHTML = result.html;

          const countEl = document.getElementById('collab-count');
          if (countEl) {
            countEl.textContent = result.count + ' collaborateur' + (result.count > 1 ? 's' : '');
          }

          // Remplir le filtre département
          const deptSelect = document.getElementById('collab-filter-dept') as HTMLSelectElement;
          if (deptSelect) {
            deptSelect.innerHTML = '<option value="">Toutes les directions</option>';
            result.depts.forEach((d) => {
              const opt = document.createElement('option');
              opt.value = d;
              opt.textContent = d;
              deptSelect.appendChild(opt);
            });
          }

          this._collabItems = result.items;
          this._initCollabFilters();
        })
        .catch((e) => console.error('[Coris Meso Finance] Liste collaborateurs:', e)),

      // Galerie Folders
      loadGalerieFolders(siteUrl)
        .then((html) => {
          setContent('galerie-folders', html);
          this._initGalerieEvents(siteUrl);
        })
        .catch((e) => console.error('[Coris Meso Finance] Galerie Folders:', e)),
    ]);
  }

  private async _loadPageData(pageHash: string): Promise<void> {
    const siteUrl = this.context.pageContext.web.absoluteUrl;

    // Extraire le nom de la page et l'ID du hash
    const parts = pageHash.split('&');
    const page = parts[0];
    let itemId: number | null = null;
    for (let i = 1; i < parts.length; i++) {
      const kv = parts[i].split('=');
      if (kv[0] === 'id') itemId = parseInt(kv[1], 10) || null;
    }

    switch (page) {
      case 'accueil':
        await this._loadAccueilData(siteUrl);
        break;

      case 'vision':
        try {
          const html = await loadVision(siteUrl);
          setContent('vision-content', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Vision:', e); }
        this._loadSidebar('vis', siteUrl);
        break;

      case 'mission':
        try {
          const html = await loadMission(siteUrl);
          setContent('mission-content', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Mission:', e); }
        this._loadSidebar('mis', siteUrl);
        break;

      case 'valeur':
      case 'valeurs':
        try {
          const html = await loadValeur(siteUrl);
          setContent('valeurs-content', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Valeur:', e); }
        this._loadSidebar('val', siteUrl);
        break;

      case 'direction':
      case 'directions':
        try {
          const html = await loadDirection(siteUrl);
          setContent('accordionDirections', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Direction:', e); }
        this._loadSidebar('dir', siteUrl);
        break;

      case 'organigramme':
        try {
          const html = await loadOrganigramme(siteUrl);
          setContent('organigramme-content', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Organigramme:', e); }
        this._loadSidebar('org', siteUrl);
        break;

      case 'trombinoscope':
        try {
          const result = await loadTrombinoscope(siteUrl);
          this._trombinoscopeItems = result.items;
          setContent('trombinoscope-content', this._resolveAssets(result.html));
          this._initTrombinoscopeFilters();
        } catch (e) { console.error('[Coris Meso Finance] Trombinoscope:', e); }
        this._loadSidebar('trom', siteUrl);
        break;

      case 'pole-banque':
        this._loadSidebar('pb', siteUrl);
        break;

      case 'pole-meso':
        this._loadSidebar('pm', siteUrl);
        break;

      case 'pole-baraka':
        this._loadSidebar('pba', siteUrl);
        break;

      /* ── Pages "Toutes les..." ─────────────────────────── */
      case 'toutes-les-actualites':
        try {
          const html = await loadActualitesAll(siteUrl);
          setContent('actualites-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Toutes actualites:', e); }
        this._loadSidebar('ta', siteUrl);
        break;

      case 'tous-les-evenements':
        try {
          const html = await loadEvenementsAll(siteUrl);
          setContent('evenements-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Tous evenements:', e); }
        this._loadSidebar('tevt', siteUrl);
        break;

      case 'toutes-les-annonces':
        try {
          const annonces = await loadAnnoncesAll(siteUrl);
          const map: Record<string, string> = {
            birthday: 'annonces-all-birthday',
            mariage: 'annonces-all-mariage',
            death: 'annonces-all-death',
            other: 'annonces-all-other',
          };
          Object.keys(map).forEach((key) => {
            setContent(map[key], this._resolveAssets(annonces[key] || ''));
          });
        } catch (e) { console.error('[Coris Meso Finance] Toutes annonces:', e); }
        this._loadSidebar('tann', siteUrl);
        break;

      case 'tout-agenda':
        try {
          const html = await loadAgendaAll(siteUrl);
          setContent('agenda-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Tout agenda:', e); }
        this._loadSidebar('tag', siteUrl);
        break;

      case 'tous-les-produits':
        try {
          const html = await loadProduitsAll(siteUrl);
          setContent('produits-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Tous produits:', e); }
        this._loadSidebar('tp', siteUrl);
        break;

      case 'tous-les-employes-du-mois':
        try {
          const html = await loadEmployesDuMoisAll(siteUrl);
          setContent('employes-mois-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Tous employes mois:', e); }
        this._loadSidebar('tem', siteUrl);
        break;

      case 'tous-les-quiz':
        try {
          const html = await loadSurveyAll(siteUrl);
          setContent('quiz-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Tous quiz:', e); }
        this._loadSidebar('tquiz', siteUrl);
        break;

      /* ── Pages Détail ──────────────────────────────────── */
      case 'detail-actualite':
        if (itemId) {
          try {
            const html = await loadActualiteDetail(siteUrl, itemId);
            setContent('detail-actualite-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail actualite:', e); }
        }
        this._loadSidebar('da', siteUrl);
        break;

      case 'detail-produit':
        if (itemId) {
          try {
            const html = await loadProduitDetail(siteUrl, itemId);
            setContent('detail-produit-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail produit:', e); }
        }
        this._loadSidebar('dp', siteUrl);
        break;

      case 'detail-evenement':
        if (itemId) {
          try {
            const html = await loadEvenementDetail(siteUrl, itemId);
            setContent('detail-evenement-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail evenement:', e); }
        }
        this._loadSidebar('devt', siteUrl);
        break;

      case 'detail-annonce':
        if (itemId) {
          try {
            const userEmail = this.context.pageContext.user?.email || '';
            const userDisplay = this.context.pageContext.user?.displayName || '';
            const html = await loadAnnonceDetail(siteUrl, itemId, userEmail, userDisplay);
            setContent('detail-annonce-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail annonce:', e); }
        }
        this._loadSidebar('dann', siteUrl);
        break;

      case 'detail-agenda':
        if (itemId) {
          try {
            const html = await loadAgendaDetail(siteUrl, itemId);
            setContent('detail-agenda-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail agenda:', e); }
        }
        this._loadSidebar('dag', siteUrl);
        break;

      case 'detail-employe-du-mois':
        if (itemId) {
          try {
            const userEmail = this.context.pageContext.user?.email || '';
            const userDisplay = this.context.pageContext.user?.displayName || '';
            const html = await loadEmployeDuMoisDetail(siteUrl, itemId, userEmail, userDisplay);
            setContent('detail-employe-mois-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail employe mois:', e); }
        }
        this._loadSidebar('dem', siteUrl);
        break;

      case 'agenda-personnel':
        this._loadSidebar('ap', siteUrl);
        const btnWeb = this.domElement.querySelector('#btn-open-teams-web');
        if (btnWeb) {
          btnWeb.addEventListener('click', (e) => {
            e.preventDefault();
            this._openTeamsCalendarWeb();
          });
        }
        const btnApp = this.domElement.querySelector('#btn-open-teams-app');
        if (btnApp) {
          btnApp.addEventListener('click', () => {
            this._openTeamsCalendarApp();
          });
        }
        this._autoOpenTeamsCalendarApp();
        break;

      /* ── Services Particuliers ──────────────────────────── */
      case 'service-particulier':
        try {
          const html = await loadServicesAll(siteUrl);
          setContent('services-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Service particulier:', e); }
        this._loadSidebar('sp', siteUrl);
        break;

      case 'detail-service-particulier':
        if (itemId) {
          try {
            const html = await loadServiceDetail(siteUrl, itemId);
            setContent('detail-service-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail service particulier:', e); }
        }
        this._loadSidebar('dsp', siteUrl);
        break;

      /* ── Services Entreprises ──────────────────────────── */
      case 'service-entreprise':
        try {
          const html = await loadServicesEntreprisesAll(siteUrl);
          setContent('services-entreprises-all-items', this._resolveAssets(html));
        } catch (e) { console.error('[Coris Meso Finance] Service entreprise:', e); }
        this._loadSidebar('se', siteUrl);
        break;

      case 'detail-service-entreprise':
        if (itemId) {
          try {
            const html = await loadServiceEntrepriseDetail(siteUrl, itemId);
            setContent('detail-service-entreprise-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail service entreprise:', e); }
        }
        this._loadSidebar('dse', siteUrl);
        break;

      /* ── Produits et Services pages ──────────────────────────── */
      case 'entreprises':
        try {
          const entHtml = await loadEntreprisesAll(siteUrl);
          setContent('entreprises-all-items', this._resolveAssets(entHtml));
        } catch (e) { console.error('[Coris Meso Finance] Entreprises:', e); }
        this._loadSidebar('ent', siteUrl);
        break;

      case 'reseau-agences':
        try {
          const raHtml = await loadReseauAgencesAll(siteUrl);
          setContent('reseau-agences-all-items', this._resolveAssets(raHtml));
        } catch (e) { console.error('[Coris Meso Finance] Réseau agences:', e); }
        this._loadSidebar('ra', siteUrl);
        break;

      case 'detail-reseau-agence':
        if (itemId) {
          try {
            const html = await loadReseauAgenceDetail(siteUrl, itemId);
            setContent('detail-reseau-agence-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail réseau agence:', e); }
        }
        this._loadSidebar('dra', siteUrl);
        break;

      case 'partenariats':
        try {
          const partenHtml = await loadPartenariatsAll(siteUrl);
          setContent('partenariats-all-items', this._resolveAssets(partenHtml));
        } catch (e) { console.error('[Coris Meso Finance] Partenariats:', e); }
        this._loadSidebar('parten', siteUrl);
        break;

      case 'detail-partenariat':
        if (itemId) {
          try {
            const html = await loadPartenariatDetail(siteUrl, itemId);
            setContent('detail-partenariat-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail partenariat:', e); }
        }
        this._loadSidebar('dp', siteUrl);
        break;

      case 'tutoriels':
        try {
          const tutoHtml = await loadTutorielsAll(siteUrl);
          setContent('tutoriels-all-items', this._resolveAssets(tutoHtml));
        } catch (e) { console.error('[Coris Meso Finance] Tutoriels:', e); }
        this._loadSidebar('tuto', siteUrl);
        break;

      case 'detail-tutoriel':
        if (itemId) {
          try {
            const html = await loadTutorielDetail(siteUrl, itemId);
            setContent('detail-tutoriel-content', this._resolveAssets(html));
          } catch (e) { console.error('[Coris Meso Finance] Detail tutoriel:', e); }
        }
        this._loadSidebar('dt', siteUrl);
        break;
    }
  }

  /* ══════════════════════════════════════════════════════════════
     RENDER — point d'entrée
     ══════════════════════════════════════════════════════════════ */

  public render(): void {
    if (!this._shellInitialized) {
      this._shellInitialized = true;
      const resolvedHeaderHtml = this._resolveAssets(HEADER_HTML);
      this.domElement.innerHTML = `
        <div id="main-header">${resolvedHeaderHtml}</div>
        <div id="page-content"></div>
        <div id="footer-container" style="display:none;"></div>
      `;
      this._removeSharePointConstraints();
      if (!this._observer) {
        this._observer = new MutationObserver(() => this._removeSharePointConstraints());
        const targetNode = document.getElementById('spPageCanvasContent') || document.body;
        this._observer.observe(targetNode, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['style', 'class'],
        });
      }
      this._initHeader();
      void this._loadHeaderMenuData(this.context.pageContext.web.absoluteUrl);
      void this._loadHeaderVideo(this.context.pageContext.web.absoluteUrl);
      loadFooter(this.context.pageContext.web.absoluteUrl)
        .then((footerHtml) => setContent('footer-container', footerHtml))
        .catch((e) => console.error('[Coris Meso Finance] Footer:', e));
      if (!this._scriptsPromise) {
        this._scriptsPromise = this._loadScripts();
      }
    }
    this._initRouter();
    const hash = window.location.hash.replace('#', '');
    const startPage = hash.startsWith('page-') ? hash.replace('page-', '') : 'accueil';
    this._currentPage = '';
    void this._renderPage(startPage);
  }

  private async _renderPage(page: string): Promise<void> {
    this._currentPage = page;
    window.scrollTo(0, 0);
    this.domElement.scrollTop = 0;

    // Nettoyer overlay vidéo si ouvert
    document.body.style.overflow = '';

    // 1. Rendre le contenu de la page (le shell header/footer est persistant)
    this._socialModalBound = false;
    this._socialModalContext = null;
    this._groupNewsSwiperInitialized = false;
    let html = this._getTemplate(page);
    html = this._resolveAssets(html);
    const contentEl = document.getElementById('page-content');
    if (contentEl) contentEl.innerHTML = html;

    // 2. Pré-remplir le contenu depuis le cache synchrone
    this._prefillFromCache(page);

    // 3. Attendre les scripts AVANT les données
    await this._scriptsPromise;

    // 4. Charger les données via les services (async)
    await this._loadPageData(page);

    // 5. Afficher le footer
    const footerEl = document.getElementById('footer-container');
    if (footerEl) footerEl.style.display = '';

    // 6. Initialiser Swiper + Tabs
    this._initSwiper();
    this._initTabs();

    // 7. Interactions post-données
    this._initDirectionAccordion();
    this._initAllSocialEvents(this.context.pageContext.web.absoluteUrl);
  }

  /**
   * Pré-remplit le contenu depuis le cache synchrone (sessionStorage)
   * pour éviter le flash "Chargement..." lors des navigations.
   * Appelé SYNCHRONEMENT dans _renderPage, avant tout await.
   */
  private _prefillFromCache(page: string): void {
    const siteUrl = this.context.pageContext.web.absoluteUrl;
    const cacheMap: Record<string, Array<{ key: string; ids: string[]; isRecord?: boolean }>> = {
      'vision':             [{ key: 'vision-html',           ids: ['vision-content'] }],
      'mission':            [{ key: 'mission-html',          ids: ['mission-content'] }],
      'valeur':             [{ key: 'valeur-html',           ids: ['valeurs-content'] }],
      'direction':          [{ key: 'direction-html',        ids: ['accordionDirections'] }],
      'trombinoscope':      [{ key: 'trombinoscope',         ids: ['trombinoscope-content'] }],
      'toutes-les-actualites':   [{ key: 'actualites-all',       ids: ['actualites-all-items'] }],
      'tous-les-evenements':     [{ key: 'evenements-all',       ids: ['evenements-all-items'] }],
      'toutes-les-annonces':     [{ key: 'annonces-all',         ids: ['annonces-all-birthday', 'annonces-all-mariage', 'annonces-all-death', 'annonces-all-other'], isRecord: true }],
      'tout-agenda':             [{ key: 'agenda-all',           ids: ['agenda-all-items'] }],
      'tous-les-produits':       [{ key: 'produits-all',         ids: ['produits-all-items'] }],
      'tous-les-employes-du-mois': [{ key: 'employes-du-mois-all', ids: ['employes-mois-all-items'] }],
      'tous-les-quiz':           [{ key: 'survey-all',           ids: ['quiz-all-items'] }],
      'service-particulier':     [{ key: 'services-all',               ids: ['services-all-items'] }],
      'service-entreprise':      [{ key: 'services-entreprises-all',   ids: ['services-entreprises-all-items'] }],
    };

    const entries = cacheMap[page];
    if (!entries) return;

    for (const entry of entries) {
      const data = cacheGet<any>(entry.key);
      if (data === undefined) continue;
      if (entry.isRecord) {
        const record = data as Record<string, string>;
        const typeOrder = ['birthday', 'mariage', 'death', 'other'];
        typeOrder.forEach((type, idx) => {
          if (record[type] && entry.ids[idx]) {
            setContent(entry.ids[idx], this._resolveAssets(record[type]));
          }
        });
      } else {
        for (const id of entry.ids) {
          setContent(id, this._resolveAssets(data as string));
        }
      }
    }
  }

  /* ══════════════════════════════════════════════════════════════
     HEADER INIT — ré-attache les écouteurs après innerHTML
     ══════════════════════════════════════════════════════════════ */

  private _initHeader(): void {
    // Mobile nav toggle
    const toggle = this.domElement.querySelector('.mobile-nav-toggle') as HTMLElement | null;
    const navbar = this.domElement.querySelector('#navbar') as HTMLElement | null;
    if (toggle && navbar) {
      toggle.addEventListener('click', () => {
        navbar.classList.toggle('navbar-mobile');
        toggle.classList.toggle('bi-list');
        toggle.classList.toggle('bi-x');
      });
    }

    // Dropdowns en mode mobile
    this.domElement.querySelectorAll('.navbar .dropdown > a').forEach((link) => {
      link.addEventListener('click', (e: Event) => {
        if (navbar?.classList.contains('navbar-mobile')) {
          e.preventDefault();
          const nextEl = (link as HTMLElement).nextElementSibling as HTMLElement | null;
          if (nextEl) nextEl.classList.toggle('dropdown-active');
        }
      });
    });

    // Video overlay
    const thumb = this.domElement.querySelector('.header-video-thumb') as HTMLElement | null;
    if (thumb) {
      thumb.addEventListener('click', (e: Event) => {
        e.preventDefault();
        this._openVideoOverlay();
      });
    }
    const closeBtn = document.getElementById('headerVideoClose');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this._closeVideoOverlay());
    }
    const overlay = document.getElementById('headerVideoOverlay');
    if (overlay) {
      overlay.addEventListener('click', (e: Event) => {
        if (e.target === overlay) this._closeVideoOverlay();
      });
    }
  }

  private async _loadHeaderMenuData(siteUrl: string): Promise<void> {
    try {
      const menuHtml = await loadHeaderMenu(siteUrl);
      setContent('navbar-menu-list', menuHtml);
      // Réattacher les événements de navigation (dropdowns mobile, etc.) sur les nouveaux éléments
      this._initHeader();
    } catch (e) {
      console.error('[Coris Meso Finance] Dynamic Menu:', e);
      setContent('navbar-menu-list', '<li style="padding: 10px 20px; color: red;">Erreur de chargement du menu</li>');
    }
  }

  private _initGalerieEvents(siteUrl: string): void {
    const foldersContainer = document.getElementById('galerie-folders');
    if (!foldersContainer) return;

    // Attach click events on the folder buttons
    foldersContainer.addEventListener('click', async (e: MouseEvent) => {
      const btn = (e.target as HTMLElement).closest('.galerie-folder[data-gallery-folder-url]') as HTMLElement | null;
      if (!btn) return;
      e.preventDefault();

      const folderUrl = btn.getAttribute('data-gallery-folder-url') || '';
      const folderTitle = btn.getAttribute('data-gallery-folder-title') || '';

      const modal = document.getElementById('galerie-modal');
      const stage = modal?.querySelector('.coris-gallery-stage');
      const imgEl = document.getElementById('galerie-modal-img') as HTMLImageElement | null;
      const titleEl = document.getElementById('galerie-modal-title');
      const descEl = document.getElementById('galerie-modal-description');
      const counterEl = document.getElementById('galerie-modal-counter');

      if (modal) {
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        if (stage) stage.classList.remove('has-image');
        if (imgEl) imgEl.src = '';
        if (titleEl) titleEl.textContent = folderTitle;
        if (descEl) descEl.innerHTML = '<div class="skeleton skeleton-line"></div><div class="skeleton skeleton-line-sm" style="width:60%"></div>';
        if (counterEl) counterEl.textContent = '';
      }

      try {
        const images = await loadGalerieImages(siteUrl, folderUrl);
        if (images.length === 0) {
          if (descEl) descEl.textContent = 'Aucune image dans ce dossier.';
          return;
        }
        this._galleryImages = images;
        this._galleryIndex = 0;
        this._showGalleryImage(this._galleryIndex);
      } catch (err) {
        console.error('[Coris Meso Finance] Error loading gallery images:', err);
        if (descEl) descEl.textContent = 'Erreur lors du chargement des images.';
      }
    });

    // Modal navigation & close events (attach once)
    const modal = document.getElementById('galerie-modal');
    if (modal && !modal.getAttribute('data-events-bound')) {
      modal.setAttribute('data-events-bound', 'true');

      const closeBtn = document.getElementById('galerie-close');
      const prevBtn = document.getElementById('galerie-prev');
      const nextBtn = document.getElementById('galerie-next');

      const closeModal = () => {
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        const imgEl = document.getElementById('galerie-modal-img') as HTMLImageElement | null;
        if (imgEl) imgEl.src = '';
      };

      closeBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        closeModal();
      });

      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          closeModal();
        }
      });

      prevBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        if (this._galleryImages.length > 0) {
          this._galleryIndex = (this._galleryIndex - 1 + this._galleryImages.length) % this._galleryImages.length;
          this._showGalleryImage(this._galleryIndex);
        }
      });

      nextBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        if (this._galleryImages.length > 0) {
          this._galleryIndex = (this._galleryIndex + 1) % this._galleryImages.length;
          this._showGalleryImage(this._galleryIndex);
        }
      });

      // Keyboard navigation
      const handleKeyDown = (e: KeyboardEvent) => {
        if (!modal.classList.contains('is-open')) return;
        if (e.key === 'Escape') {
          closeModal();
        } else if (e.key === 'ArrowLeft' && this._galleryImages.length > 0) {
          this._galleryIndex = (this._galleryIndex - 1 + this._galleryImages.length) % this._galleryImages.length;
          this._showGalleryImage(this._galleryIndex);
        } else if (e.key === 'ArrowRight' && this._galleryImages.length > 0) {
          this._galleryIndex = (this._galleryIndex + 1) % this._galleryImages.length;
          this._showGalleryImage(this._galleryIndex);
        }
      };
      document.addEventListener('keydown', handleKeyDown);
    }
  }

  private _showGalleryImage(index: number): void {
    if (index < 0 || index >= this._galleryImages.length) return;
    const img = this._galleryImages[index];

    const modal = document.getElementById('galerie-modal');
    const stage = modal?.querySelector('.coris-gallery-stage');
    const imgEl = document.getElementById('galerie-modal-img') as HTMLImageElement | null;
    const titleEl = document.getElementById('galerie-modal-title');
    const descEl = document.getElementById('galerie-modal-description');
    const counterEl = document.getElementById('galerie-modal-counter');

    if (stage) stage.classList.remove('has-image');
    if (imgEl) {
      imgEl.onload = () => {
        if (stage) stage.classList.add('has-image');
      };
      imgEl.src = img.url;
      imgEl.alt = img.title;
    }
    if (titleEl) titleEl.textContent = img.title || img.name;
    if (descEl) descEl.textContent = img.description || '';
    if (counterEl) counterEl.textContent = `${index + 1} / ${this._galleryImages.length}`;
  }

  // ── SOCIAL: Likes & Comments ──────────────────────────────────────────────

  private _initAllSocialEvents(siteUrl: string): void {
    const userEmail = this.context.pageContext.user?.email || '';
    const userDisplay = this.context.pageContext.user?.displayName || '';
    if (!userEmail) return;

    this.domElement.querySelectorAll('[data-social-list][data-social-item-id]').forEach((el) => {
      const listName = el.getAttribute('data-social-list') || '';
      const itemId = parseInt(el.getAttribute('data-social-item-id') || '0', 10);
      if (!listName || !itemId) return;
      this._initSocialEvents(siteUrl, listName, itemId, userEmail, userDisplay);
    });
  }

  private _initSocialEvents(
    siteUrl: string,
    listName: string,
    itemId: number,
    userEmail: string,
    userDisplayName: string
  ): void {
    if (!userEmail) return;

    const prefix = listName === 'annonces' ? `annonce-${itemId}` : `edm-${itemId}`;
    const socialBar = this.domElement.querySelector(
      `[data-social-list="${listName}"][data-social-item-id="${itemId}"]`
    ) as HTMLElement | null;
    if (socialBar?.getAttribute('data-social-bound') === 'true') return;
    if (socialBar) socialBar.setAttribute('data-social-bound', 'true');

    const likeBtn = this.domElement.querySelector(`#like-btn-${prefix}`) as HTMLButtonElement | null;
    const commentToggleBtn = this.domElement.querySelector(`#comment-toggle-${prefix}`) as HTMLButtonElement | null;

    // -- Toggle like
    if (likeBtn) {
      likeBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await this._updateLike(siteUrl, listName, itemId, userEmail, likeBtn, prefix);
      });
    }

    // -- Ouvrir le modal commentaires
    if (commentToggleBtn) {
      commentToggleBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        void this._openSocialCommentsModal(siteUrl, listName, itemId, userEmail, userDisplayName, prefix);
      });
    }
  }

  private _ensureSocialCommentsModal(): void {
    if (document.getElementById('socialCommentsModal')) {
      return;
    }

    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
      <div class="modal fade" id="socialCommentsModal" tabindex="-1" aria-labelledby="socialCommentsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
          <div class="modal-content social-comments-modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="socialCommentsModalLabel">
                <i class="bi bi-chat-dots-fill me-2"></i>Commentaires
              </h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
            </div>
            <div class="modal-body social-comments-modal-body">
              <div id="social-comments-modal-list" class="social-comments-list"></div>
            </div>
            <div class="modal-footer social-comments-modal-footer">
              <div class="social-comment-form social-comment-form--modal">
                <div class="social-comment-form-avatar" id="social-comments-modal-avatar">U</div>
                <div class="social-comment-form-input-wrap">
                  <textarea
                    id="social-comments-modal-input"
                    class="social-comment-input"
                    placeholder="Écrivez un commentaire..."
                    rows="3"></textarea>
                  <button type="button" class="social-comment-submit" id="social-comments-modal-submit">
                    <i class="bi bi-send-fill"></i> Publier
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>`;

    const modalEl = wrapper.firstElementChild as HTMLElement;
    document.body.appendChild(modalEl);

    // Fermeture : clic en dehors du modal
    modalEl.addEventListener('click', (ev: MouseEvent) => {
      if (ev.target === modalEl) this._hideBootstrapModal(modalEl);
    });

    // Fermeture : bouton X
    const closeBtn = modalEl.querySelector('.btn-close') as HTMLElement | null;
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this._hideBootstrapModal(modalEl));
    }

    if (this._socialModalBound) {
      return;
    }
    this._socialModalBound = true;

    const submitBtn = document.getElementById('social-comments-modal-submit') as HTMLButtonElement | null;
    const inputEl = document.getElementById('social-comments-modal-input') as HTMLTextAreaElement | null;

    const submitFromModal = async (): Promise<void> => {
      const ctx = this._socialModalContext;
      if (!ctx || !inputEl || !submitBtn) return;
      const text = inputEl.value.trim();
      if (!text) return;
      submitBtn.disabled = true;
      await this._submitComment(
        ctx.siteUrl,
        ctx.listName,
        ctx.itemId,
        ctx.userEmail,
        ctx.userDisplayName,
        text,
        ctx.prefix,
        true
      );
      if (inputEl) inputEl.value = '';
      if (submitBtn) submitBtn.disabled = false;
    };

    if (submitBtn) {
      submitBtn.addEventListener('click', () => { void submitFromModal(); });
    }
    if (inputEl) {
      inputEl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          void submitFromModal();
        }
      });
    }
  }

  private _reconnectObserver(): void {
    if (this._observer) {
      const targetNode = document.getElementById('spPageCanvasContent') || document.body;
      this._observer.observe(targetNode, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
    }
  }

  private _showBootstrapModal(modal: HTMLElement): void {
    document.body.appendChild(modal);
    if (this._observer) this._observer.disconnect();
    const bs = (window as { bootstrap?: { Modal?: new (el: HTMLElement) => { show: () => void; hide?: () => void } } }).bootstrap;
    if (bs && bs.Modal) {
      new bs.Modal(modal).show();
      modal.addEventListener('hidden.bs.modal', () => {
        this._reconnectObserver();
      }, { once: true });
      return;
    }
    modal.classList.add('show');
    modal.style.display = 'block';
    modal.removeAttribute('aria-hidden');
    document.body.classList.add('modal-open');
  }

  private _hideBootstrapModal(modal: HTMLElement): void {
    const bs = (window as { bootstrap?: { Modal?: new (el: HTMLElement) => { hide: () => void } } }).bootstrap;
    if (bs && bs.Modal) {
      const instance = (bs.Modal as any).getInstance?.(modal);
      if (instance) { instance.hide(); this._reconnectObserver(); return; }
    }
    modal.classList.remove('show');
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    this._reconnectObserver();
  }

  private async _openSocialCommentsModal(
    siteUrl: string,
    listName: string,
    itemId: number,
    userEmail: string,
    userDisplayName: string,
    prefix: string
  ): Promise<void> {
    this._ensureSocialCommentsModal();
    this._socialModalContext = { siteUrl, listName, itemId, userEmail, userDisplayName, prefix };

    const modal = document.getElementById('socialCommentsModal') as HTMLElement | null;
    const listEl = modal ? modal.querySelector('#social-comments-modal-list') as HTMLElement | null : null;
    const inputEl = modal ? modal.querySelector('#social-comments-modal-input') as HTMLTextAreaElement | null : null;
    const submitBtn = modal ? modal.querySelector('#social-comments-modal-submit') as HTMLButtonElement | null : null;
    const avatarEl = modal ? modal.querySelector('#social-comments-modal-avatar') as HTMLElement | null : null;
    const titleEl = modal ? modal.querySelector('#socialCommentsModalLabel') as HTMLElement | null : null;

    if (listEl) listEl.innerHTML = '<div class="p-3"><div class="skeleton skeleton-line"></div><div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div></div>';
    if (inputEl) {
      inputEl.value = '';
      inputEl.disabled = !userEmail;
    }
    if (submitBtn) submitBtn.disabled = !userEmail;
    if (avatarEl) {
      avatarEl.textContent = (userDisplayName || 'U')
        .split(' ')
        .map((p) => p[0])
        .join('')
        .substring(0, 2)
        .toUpperCase();
    }
    if (titleEl) {
      titleEl.innerHTML = `<i class="bi bi-chat-dots-fill me-2"></i>Commentaires`;
    }

    if (modal) this._showBootstrapModal(modal);

    try {
      const res = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})?$select=*`,
        { headers: { Accept: 'application/json;odata=nometadata' } }
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const commentsField = this._findFieldKey(data, 'Comments');
      const comments = parseComments(data[commentsField]);
      if (listEl) listEl.innerHTML = buildCommentsListHtml(comments);
    } catch (e) {
      console.error('[Social] Comments load error:', e);
      if (listEl) listEl.innerHTML = '<p class="text-center text-muted p-3">Erreur de chargement des commentaires</p>';
    }
  }

  private _updateCommentToggleUi(prefix: string, count: number): void {
    const toggleBtn = this.domElement.querySelector(`#comment-toggle-${prefix}`) as HTMLElement | null;
    if (!toggleBtn) return;

    const labelEl = toggleBtn.querySelector('.social-comment-label') as HTMLElement | null;
    if (labelEl) {
      if (labelEl.classList.contains('social-comment-label--count-only')) {
        labelEl.textContent = String(count);
      } else {
        labelEl.textContent = `${count} Commentaire${count > 1 ? 's' : ''}`;
      }
    }
    const iconEl = toggleBtn.querySelector('i');
    if (iconEl) {
      iconEl.className = count > 0 ? 'bi bi-chat-dots-fill' : 'bi bi-chat-dots';
    }
  }

  private async _getRequestDigest(siteUrl: string): Promise<string> {
    const res = await fetch(`${siteUrl}/_api/contextinfo`, {
      method: 'POST',
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) throw new Error('Cannot get request digest');
    const data = await res.json();
    return data.FormDigestValue as string;
  }

  private _findFieldKey(data: Record<string, unknown>, name: string): string {
    return Object.keys(data).find((k) => k.toLowerCase() === name.toLowerCase()) || name;
  }

  private async _updateLike(
    siteUrl: string,
    listName: string,
    itemId: number,
    userEmail: string,
    likeBtn: HTMLButtonElement,
    prefix: string
  ): Promise<void> {
    try {
      // Fetch item without $select to avoid 400 on lists with different internal field names
      const res = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})`,
        { headers: { Accept: 'application/json;odata=nometadata' } }
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      // Find the actual "liked by" field key dynamically (case-insensitive, handles internal name mismatches)
      const keys = Object.keys(data);
      const likeField = keys.find((k) => k.toLowerCase().replace(/[^a-z]/g, '') === 'likedby') || 'LikedBy';
      let likedBy: string[] = [];
      try { likedBy = JSON.parse(String(data[likeField] || '[]')); } catch { likedBy = []; }

      const alreadyLiked = likedBy.indexOf(userEmail) !== -1;
      if (alreadyLiked) {
        likedBy = likedBy.filter((e) => e !== userEmail);
      } else {
        likedBy.push(userEmail);
      }

      const digest = await this._getRequestDigest(siteUrl);
      const updateRes = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})`,
        {
          method: 'POST',
          headers: {
            Accept: 'application/json;odata=nometadata',
            'Content-Type': 'application/json;odata=nometadata',
            'X-RequestDigest': digest,
            'X-HTTP-Method': 'MERGE',
            'IF-MATCH': '*',
          },
          body: JSON.stringify({ [likeField]: JSON.stringify(likedBy) }),
        }
      );
      if (!updateRes.ok) {
        const errText = await updateRes.text().catch(() => '');
        console.error('[Social] Like MERGE failed. Keys:', keys, 'likeField:', likeField, 'Error:', errText);
        throw new Error(`Update HTTP ${updateRes.status}: ${errText}`);
      }

      cacheInvalidate(listName === 'annonces' ? 'announcements-home' : 'employe-du-mois');
      cacheInvalidate(listName === 'annonces' ? 'annonces-all' : 'employes-du-mois-all');
      cacheInvalidate(listName === 'annonces' ? `detail-annonce-${itemId}` : `detail-employe-du-mois-${itemId}`);

      // Update UI
      const countEl = this.domElement.querySelector(`#like-count-${prefix}`) as HTMLElement | null;
      if (countEl) countEl.textContent = String(likedBy.length);
      const iconEl = likeBtn.querySelector('i');
      if (alreadyLiked) {
        likeBtn.classList.remove('liked');
        if (iconEl) {
          iconEl.classList.remove('bi-hand-thumbs-up-fill');
          iconEl.classList.add('bi-hand-thumbs-up');
        }
      } else {
        likeBtn.classList.add('liked');
        if (iconEl) {
          iconEl.classList.remove('bi-hand-thumbs-up');
          iconEl.classList.add('bi-hand-thumbs-up-fill');
        }
      }
    } catch (e) {
      console.error('[Social] Like update error:', e);
    }
  }

  private async _submitComment(
    siteUrl: string,
    listName: string,
    itemId: number,
    userEmail: string,
    userDisplayName: string,
    text: string,
    prefix: string,
    refreshModal = false
  ): Promise<void> {
    try {
      // Fetch current Comments (use * to avoid case-sensitivity issues)
      const res = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})?$select=*`,
        { headers: { Accept: 'application/json;odata=nometadata' } }
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      const commentsField = this._findFieldKey(data, 'Comments');
      let comments: Array<{ user: string; email: string; text: string; date: string }> = [];
      try { comments = JSON.parse(String(data[commentsField] || '[]')); } catch { comments = []; }

      const newComment = {
        user: userDisplayName || userEmail,
        email: userEmail,
        text,
        date: new Date().toISOString(),
      };
      comments.push(newComment);

      const digest = await this._getRequestDigest(siteUrl);
      const updateRes = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})`,
        {
          method: 'POST',
          headers: {
            Accept: 'application/json;odata=nometadata',
            'Content-Type': 'application/json;odata=nometadata',
            'X-RequestDigest': digest,
            'X-HTTP-Method': 'MERGE',
            'IF-MATCH': '*',
          },
          body: JSON.stringify({ [commentsField]: JSON.stringify(comments) }),
        }
      );
      if (!updateRes.ok) throw new Error(`Update HTTP ${updateRes.status}`);

      cacheInvalidate(listName === 'annonces' ? 'announcements-home' : 'employe-du-mois');
      cacheInvalidate(listName === 'annonces' ? 'annonces-all' : 'employes-du-mois-all');
      cacheInvalidate(listName === 'annonces' ? `detail-annonce-${itemId}` : `detail-employe-du-mois-${itemId}`);

      const modalListEl = document.getElementById('social-comments-modal-list') as HTMLElement | null;
      if (refreshModal && modalListEl) {
        modalListEl.innerHTML = buildCommentsListHtml(comments);
      }

      this._updateCommentToggleUi(prefix, comments.length);
    } catch (e) {
      console.error('[Social] Comment submit error:', e);
    }
  }

  // ── END SOCIAL ────────────────────────────────────────────────────────────

  private async _loadHeaderVideo(siteUrl: string): Promise<void> {
    try {
      const videoUrl = await loadHeaderVideo(siteUrl);
      const videoId = extractYouTubeId(videoUrl);
      if (!videoId) return;

      const thumb = document.getElementById('header-video-thumb') as HTMLImageElement | null;
      if (thumb) thumb.src = `https://img.youtube.com/vi/${videoId}/0.jpg`;

      this._videoUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
    } catch (e) {
      console.error('[Coris Meso Finance] Header video:', e);
    }
  }

  private _openVideoOverlay(): void {
    const overlay = document.getElementById('headerVideoOverlay');
    const player = document.getElementById('header-video-player') as HTMLIFrameElement | null;
    if (!overlay || !player) return;

    player.src = this._videoUrl;
    overlay.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  private _closeVideoOverlay(): void {
    const overlay = document.getElementById('headerVideoOverlay');
    const player = document.getElementById('header-video-player') as HTMLIFrameElement | null;
    if (!overlay || !player) return;

    player.src = '';
    overlay.style.display = 'none';
    document.body.style.overflow = '';
  }

  /* ══════════════════════════════════════════════════════════════
     LIFECYCLE
     ══════════════════════════════════════════════════════════════ */

  protected onInit(): Promise<void> {
    const url = new URL(window.location.href);
    const currentMode = url.searchParams.get('Mode');
    if (currentMode && currentMode.toLowerCase() === 'edit') {
      url.searchParams.delete('Mode');
      window.location.replace(url.toString());
      return Promise.resolve();
    }

    const styleId = 'coris-mesofinance-global-fullscreen-style';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.type = 'text/css';
      style.innerHTML = `
        html, body {
          margin: 0 !important; padding: 0 !important;
          background: #fff !important;
        }
        [data-automation-id="webpartToolbar"],
        [data-automation-id="WebPartToolbar"],
        .sp-webpart-toolbar,
        .sp-webpartzone-cell .webPartToolbar,
        [class*="webpartToolbar"],
        [class*="WebPartToolbar"],
        [class*="toolbarContainer_"],
        [class*="editMenuButton_"],
        [class*="commandBar_"] {
          display: none !important;
          pointer-events: none !important;
        }
      `;
      document.head.appendChild(style);
    }

    /* ── MutationObserver : ré-applique les masquages après chaque rendu dynamique de SharePoint ── */
    if (!this._observer) {
      let _debounceTimer: ReturnType<typeof setTimeout> | null = null;
      this._observer = new MutationObserver(() => {
        if (_debounceTimer) clearTimeout(_debounceTimer);
        _debounceTimer = setTimeout(() => {
          this._removeSharePointConstraints();
          this._hideSharePointCanvasBelow();
          this._hideSpEditToolbars();
        }, 150);
      });
      this._observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: false,
      });
    }

    return Promise.resolve();
  }

  /** Masque spécifiquement les toolbars d'édition (boutons + haut/bas) après chaque mutation. */
  private _hideSpEditToolbars(): void {
    const selectors = [
      '[data-automation-id="CanvasZone-SectionToolbar"]',
      '[data-automation-id="insertSection"]',
      '[data-automation-id="insertZone"]',
      '[data-automation-id="sectionToolbar"]',
      '[data-automation-id="pageFooter"]',
      '[data-automation-id="CanvasZone-insertZone"]',
      '[data-automation-id="canvasFooter"]',
      '[data-automation-id="bottomToolbar"]',
      '[data-automation-id="webpartToolbar"]',
      '[data-automation-id="WebPartToolbar"]',
      '.sp-webpart-toolbar',
      '#CommentsWrapper',
      '#footer',
    ];
    const classPatterns = [
      'sectionToolbar',
      'addSection',
      'insertZone',
      'insertionPoint',
      'addWebPart',
      'addControl',
      'pageFooter',
      'canvasFooter',
      'bottomToolbar',
      'spacer',
      'webpartToolbar',
      'WebPartToolbar',
      'toolbarContainer',
      'editMenuButton',
    ];

    // Masquer par sélecteur exact
    document.querySelectorAll(selectors.join(',')).forEach((el) => {
      (el as HTMLElement).style.setProperty('display', 'none', 'important');
      (el as HTMLElement).style.setProperty('height', '0', 'important');
      (el as HTMLElement).style.setProperty('min-height', '0', 'important');
      (el as HTMLElement).style.setProperty('overflow', 'hidden', 'important');
    });

    // Masquer par classes hachées SPFx (ex: sectionToolbar_abc123)
    classPatterns.forEach((pattern) => {
      document.querySelectorAll(`[class*="${pattern}_"]`).forEach((el) => {
        (el as HTMLElement).style.setProperty('display', 'none', 'important');
        (el as HTMLElement).style.setProperty('height', '0', 'important');
        (el as HTMLElement).style.setProperty('min-height', '0', 'important');
        (el as HTMLElement).style.setProperty('overflow', 'hidden', 'important');
      });
    });
  }

  public onDispose(): void {
    if (this._observer) {
      this._observer.disconnect();
      this._observer = null;
    }
    if (this._boundHashChange) {
      window.removeEventListener('hashchange', this._boundHashChange);
      this._boundHashChange = null;
    }
    this._routerBound = false;
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: { description: strings.PropertyPaneDescription },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', { label: strings.DescriptionFieldLabel }),
              ],
            },
          ],
        },
      ],
    };
  }
}
