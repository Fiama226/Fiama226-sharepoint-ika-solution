import { cacheFetchSmart } from './cache';

const HEADER_MENU_CACHE_KEY = 'header-menu-items';
const HEADER_MENU_TTL = 15 * 60 * 1000; // 15 minutes

export interface IMenuItem {
  Title: string;
  MenuUrl: string;
  Position: number;
  IsActive: boolean;
  ParentMenu: string | null;
  children?: IMenuItem[];
}

export async function loadHeaderMenu(siteUrl: string): Promise<string> {
  return cacheFetchSmart(HEADER_MENU_CACHE_KEY, siteUrl, 'HeaderDetail', async () => {
    // 1. Récupérer les données de la liste SharePoint "HeaderDetail" (avec $expand sur ParentMenu)
    let url = `${siteUrl}/_api/web/lists/getbytitle('HeaderDetail')/items?$select=Title,MenuUrl,Position,IsActive,ParentMenu/Title&$expand=ParentMenu&$top=200`;
    let res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata' },
    });
    // Fallback 1 : si ParentMenu est un texte simple (ex: import CSV)
    if (!res.ok) {
      url = `${siteUrl}/_api/web/lists/getbytitle('HeaderDetail')/items?$select=Title,MenuUrl,Position,IsActive,ParentMenu&$top=200`;
      res = await fetch(url, {
        headers: { Accept: 'application/json;odata=nometadata' },
      });
    }
    // Fallback 2 : si le champ s'appelle "field_1" (cas typique de l'import CSV dans SharePoint)
    if (!res.ok) {
      url = `${siteUrl}/_api/web/lists/getbytitle('HeaderDetail')/items?$select=Title,MenuUrl,Position,IsActive,field_1&$top=200`;
      res = await fetch(url, {
        headers: { Accept: 'application/json;odata=nometadata' },
      });
    }
    // Fallback 3 : au cas où aucune colonne de parent n'existe
    if (!res.ok) {
      url = `${siteUrl}/_api/web/lists/getbytitle('HeaderDetail')/items?$select=Title,MenuUrl,Position,IsActive&$top=200`;
      res = await fetch(url, {
        headers: { Accept: 'application/json;odata=nometadata' },
      });
    }
    if (!res.ok) throw new Error(await res.text());

    const data = await res.json();
    const rawItems: Array<Record<string, any>> = data.value || [];

    // 2. Filtrer uniquement les éléments actifs et les trier par Position
    const items: IMenuItem[] = rawItems
      .filter((item) => item.IsActive === true || item.IsActive === 'Oui' || item.IsActive === 'Yes' || item.IsActive === 1)
      .map((item) => {
        // Gérer de façon robuste si ParentMenu (ou field_1) est un Lookup (objet) ou du texte (string)
        let parent: string | null = null;
        const parentVal = item.ParentMenu !== undefined ? item.ParentMenu : item.field_1;
        if (parentVal) {
          if (typeof parentVal === 'object') {
            parent = parentVal.Title ? String(parentVal.Title).trim() : null;
          } else {
            parent = String(parentVal).trim();
          }
        }

        return {
          Title: String(item.Title || ''),
          MenuUrl: String(item.MenuUrl || '#'),
          Position: Number(item.Position ?? 0),
          IsActive: true,
          ParentMenu: parent,
        };
      })
      .sort((a, b) => a.Position - b.Position);

    // 3. Construire la structure hiérarchique (Parent-Enfant)
    const map = new Map<string, IMenuItem>();
    const roots: IMenuItem[] = [];

    items.forEach((item) => {
      item.children = [];
      map.set(item.Title.trim().toLowerCase(), item);
    });

    items.forEach((item) => {
      const parentName = item.ParentMenu ? item.ParentMenu.trim().toLowerCase() : '';
      if (parentName) {
        const parent = map.get(parentName);
        if (parent) {
          parent.children!.push(item);
        } else {
          // Si le parent n'existe pas, on le place au niveau principal
          roots.push(item);
        }
      } else {
        roots.push(item);
      }
    });

    // 4. Générer le code HTML récursivement
    function renderMenuItemHtml(item: IMenuItem, level: number): string {
      const hasChildren = item.children && item.children.length > 0;

      if (hasChildren) {
        if (level === 1) {
          // Menu principal déroulant
          return `
            <li class="dropdown"><a href="${item.MenuUrl || '#'}"><span>${item.Title}</span> <i class="bi bi-chevron-down"></i></a>
              <ul>
                ${item.children!.map((child) => renderMenuItemHtml(child, level + 1)).join('')}
              </ul>
            </li>`;
        } else {
          // Sous-menu de niveau 2+ déroulant
          return `
            <li class="dropdown">
              <a href="${item.MenuUrl || '#'}">${item.Title} <span class="submenu-arrow">&#8250;</span></a>
              <ul>
                ${item.children!.map((child) => renderMenuItemHtml(child, level + 1)).join('')}
              </ul>
            </li>`;
        }
      } else {
        // Lien normal sans enfants
        return `<li><a href="${item.MenuUrl || '#'}">${item.Title}</a></li>`;
      }
    }

    // Retourner le HTML final contenant tous les menus racine
    const html = roots.map((root) => renderMenuItemHtml(root, 1)).join('');
    return html;
  }, HEADER_MENU_TTL);
}
