﻿import { resolveImage } from './utils';
import { buildSocialWidgetHtml, parseComments, parseLikedBy } from './social';
import { cacheFetchSmart, cacheFetchSmartItem } from './cache';

const fallbackImg = 'assets/imges/user-1.jpg';
const CACHE_TTL = 5 * 60 * 1000;

/**
 * Charge toutes les annonces (groupées par type)
 */
export function loadAnnoncesAll(siteUrl: string): Promise<Record<string, string>> {
  return cacheFetchSmart('annonces-all', siteUrl, 'annonces', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('annonces')/items?$select=*&$orderby=DateDeEvenement desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const now = new Date();
    const valid = (data.value || []).filter((item: Record<string, unknown>) => {
      const startDate = item.DateDeEvenement ? new Date(String(item.DateDeEvenement)) : null;
      const endDate = item.DateDeFin ? new Date(String(item.DateDeFin)) : null;
      if (startDate && now < startDate) return false;
      if (endDate && now > endDate) return false;
      return true;
    });

    const groups: Record<string, Array<Record<string, unknown>>> = { birthday: [], mariage: [], death: [], other: [] };
    valid.forEach((item: Record<string, unknown>) => {
      const t = String(item.type || '').toLowerCase();
      if (t === 'anniversaire') groups.birthday.push(item);
      else if (t === 'mariage') groups.mariage.push(item);
      else if (t === 'nécrologie' || t === 'necrologie') groups.death.push(item);
      else groups.other.push(item);
    });

    const greetingMap: Record<string, string> = {
      birthday: 'Joyeux anniversaire à ',
      mariage: 'Joyeux anniversaire de mariage',
      death: 'Nos sincères condoléances',
      other: '',
    };

    const iconMap: Record<string, string> = {
      birthday: '<i class="bi bi-gift-fill" style="font-size:20px;color:#fff"></i>',
      mariage: '<i class="bi bi-heart-fill" style="font-size:20px;color:#fff"></i>',
      death: '<i class="bi bi-flower1" style="font-size:20px;color:#fff"></i>',
      other: '<i class="bi bi-megaphone-fill" style="font-size:20px;color:#fff"></i>',
    };

    const result: Record<string, string> = {};

    await Promise.all(
      Object.keys(groups).map(async (type) => {
        const typeItems = groups[type];
        if (typeItems.length === 0) {
          result[type] = '<p class="text-center text-muted p-3">Aucune donnée disponible</p>';
          return;
        }
        const htmls = await Promise.all(
          typeItems.map((item: Record<string, unknown>) =>
            resolveImage(siteUrl, 'annonces', item, fallbackImg).then((imageUrl) => {
              const name = String(item.Titre || item.Title || '');
              const greeting = greetingMap[type] || '';
              const greetingText = greeting ? greeting + ' ' + name : name;
              const description = item.Description ? String(item.Description) : '';
              let dateStr = '';
              if (item.DateDeEvenement) {
                const d = new Date(String(item.DateDeEvenement));
                dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
              }
              let endDateStr = '';
              if (item.DateDeFin) {
                const d = new Date(String(item.DateDeFin));
                endDateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
              }
              const likes = item.AimePar || 0;
              const lieu = item.Lieu ? String(item.Lieu) : '';
              const lieuHtml = lieu ? '<p style="font-size:12px;color:#999;margin:4px 0 0 0"><i class="bi bi-geo-alt"></i> ' + lieu + '</p>' : '';
              const endDateHtml = endDateStr ? '<p style="font-size:12px;color:#999;margin:4px 0 0 0"><i class="bi bi-calendar-check"></i> Fin : ' + endDateStr + '</p>' : '';
              const descriptionHtml = description
                ? '<div class="annonce-description">' + description + '</div>'
                : '';
              const typeIcon = iconMap[type] || iconMap.other;

              return `
                  <div class="event-news">
                    <a href="#page-detail-annonce&id=${item.Id}" class="d-flex align-content-start gap-2">
                      <div class="img-box"><img src="${imageUrl}"></div>
                      <div class="event-text d-flex flex-column justify-content-between flex-grow-1">
                        <div class="d-flex gap-3 align-items-start">
                          <div class="annouce-icon">${typeIcon}</div>
                          <div>
                            <h3>${greetingText}</h3>
                            ${dateStr ? '<p style="font-size:13px;color:#666;margin:4px 0 0 0"><i class="bi bi-calendar"></i> ' + dateStr + '</p>' : ''}
                            ${endDateHtml}
                            ${lieuHtml}
                            ${descriptionHtml}
                          </div>
                        </div>
                        <div class="d-flex align-items-center gap-2 justify-content-end">
                          <div class="d-flex align-items-center like-btn">
                            <p>${likes}</p>
                            <button type="button"><i class="bi bi-hand-thumbs-up-fill"></i></button>
                          </div>
                        </div>
                      </div>
                    </a>
                  </div>`;
            })
          )
        );
        result[type] = htmls.join('');
      })
    );

    return result;
  }, CACHE_TTL).catch((err) => {
    console.error('[Annonces] load error:', err);
    return {
      birthday: '<p class="text-center text-muted p-3">Erreur de chargement</p>',
      mariage: '<p class="text-center text-muted p-3">Erreur de chargement</p>',
      death: '<p class="text-center text-muted p-3">Erreur de chargement</p>',
      other: '<p class="text-center text-muted p-3">Erreur de chargement</p>',
    };
  });
}

/**
 * Charge le détail d'une annonce par son ID
 */
export function loadAnnonceDetail(
  siteUrl: string,
  itemId: number,
  currentUserEmail = '',
  currentUserDisplayName = ''
): Promise<string> {
  return cacheFetchSmartItem(`detail-annonce-${itemId}`, siteUrl, 'annonces', itemId, async () => {
    try {
      const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('annonces')/items(${itemId})`;
      const res = await fetch(listApiUrl, {
        headers: {
          Accept: 'application/json;odata=nometadata',
          'Content-Type': 'application/json;odata=nometadata',
        },
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`HTTP ${res.status}: ${t}`);
      }
      const item = await res.json();
      if (!item) return '<p class="text-center text-muted p-3">Annonce introuvable</p>';

      const name = String(item.Titre || item.Title || '');
      const description = String(item.Description || '');
      const lieu = item.Lieu ? String(item.Lieu) : '';
      const type = String(item.type || '');

      const likedBy = parseLikedBy(item.LikedBy);
      const comments = parseComments(item.Comments);
      const itemIdNum = Number(item.Id);

      const typeLabels: Record<string, string> = {
        anniversaire: 'Anniversaire',
        mariage: 'Mariage',
        nécrologie: 'nécrologie',
        necrologie: 'nécrologie',
      };
      const typeLabel = typeLabels[type.toLowerCase()] || 'Autre';

      let dateStr = '';
      if (item.DateDeEvenement) {
        const d = new Date(String(item.DateDeEvenement));
        dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
      }

      let endDateStr = '';
      if (item.DateDeFin) {
        const d = new Date(String(item.DateDeFin));
        endDateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
      }

      const socialHtml = buildSocialWidgetHtml({
        listName: 'annonces',
        itemId: itemIdNum,
        likedBy,
        comments,
        currentUserEmail,
        currentUserDisplayName,
      });

      const imageUrl = await resolveImage(siteUrl, 'annonces', item, fallbackImg);
      return `
        <div class="row">
          <div class="col-md-12 text-center">
            ${imageUrl ? `<div class="text-center mb-4">
              <img src="${imageUrl}" class="img-fluid rounded" style="max-width:100%;max-height:400px;object-fit:cover;border-radius:8px;">
            </div>` : ''}
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${name}</h1>
            <p style="color: #888; font-size: 14px; margin-bottom: 20px; text-align:center;">
              <span class="badge" style="background:#004991;">${typeLabel}</span>
              ${dateStr ? `<span class="ms-2"><i class="bi bi-calendar"></i> ${dateStr}</span>` : ''}
              ${endDateStr ? `<span class="ms-2"><i class="bi bi-calendar-check"></i> Fin: ${endDateStr}</span>` : ''}
            </p>
            ${lieu ? `<p style="text-align:center;"><i class="bi bi-geo-alt"></i> <strong>Lieu :</strong> ${lieu}</p>` : ''}
            ${description ? `<div style="font-size: 15px; line-height: 1.8; color: #444; max-width:800px; margin-left:auto; margin-right:auto; text-align:center;">${description}</div>` : ''}

            ${socialHtml}

            <div class="mt-4 text-center">
              <a href="#page-toutes-les-annonces" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour aux annonces
              </a>
            </div>
          </div>
        </div>`;
    } catch (err) {
      console.error('[Annonces] detail load error:', err);
      return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
    }
  });
}
