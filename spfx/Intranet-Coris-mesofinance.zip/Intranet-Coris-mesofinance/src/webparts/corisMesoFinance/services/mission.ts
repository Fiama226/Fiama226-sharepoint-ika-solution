﻿import { resolveImage } from './utils';
import { cacheFetchSmart } from './cache';

const MISSION_CACHE_KEY = 'mission-html';
const MISSION_TTL = 30 * 60 * 1000;

export function loadMission(siteUrl: string): Promise<string> {
  const fallbackImg = 'assets/imges/mission.png';

  return cacheFetchSmart(MISSION_CACHE_KEY, siteUrl, 'Mission', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Mission')/items?$select=*&$top=20`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui';
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucune donnée</p>';

    const firstItem = items[0];
    const mainTitle = String(firstItem.Title || 'MISSION');
    const mainDesc = String(firstItem.Description || '');

    const sections = items.slice(1).map((item: Record<string, unknown>) => {
      const sectionTitle = String(item.Title || '');
      const sectionDesc = String(item.Description || '');
      if (!sectionDesc) return '';
      const lis = sectionDesc.split('\n').filter((l: string) => l.trim()).map((l: string) => `<li style="font-size: 17px;">${l.trim()}</li>`).join('');
      return `
          <hr>
          <h3 style="margin-left: 20px;">${sectionTitle}</h3>
          <ul style="margin-left: 20px;">${lis}</ul>`;
    }).join('');

    const mainImageUrl = await resolveImage(siteUrl, 'Mission', firstItem, fallbackImg);
    return `
        <div class="col-md-12">
          <div style="text-align: center;">
            <img src="${mainImageUrl}" style="max-width: 700px; width: 100%;">
          </div>
        </div>
        <br>
        <div class="col-md-12">
          <br><br><br>
          <div class="group-single-title mb-4">
            <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">${mainTitle}</h1>
            ${mainDesc ? `<p style="font-size: 17px; color: black; margin-left: 20px;">${mainDesc}</p>` : ''}
            ${sections}
          </div>
        </div>`;
  }, MISSION_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Mission load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}
