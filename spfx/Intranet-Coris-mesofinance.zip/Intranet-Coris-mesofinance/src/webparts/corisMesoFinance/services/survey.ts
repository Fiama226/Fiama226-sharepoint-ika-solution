﻿import { resolveImage } from './utils';
import { cacheFetchSmart } from './cache';

function getLink(item: Record<string, unknown>): string {
  const link = item.Link;
  if (!link) return '#';
  if (typeof link === 'string') return link;
  if ((link as { Url?: string }).Url) return (link as { Url: string }).Url;
  return '#';
}

const CACHE_TTL = 5 * 60 * 1000;

/**
 * Charge tous les sondages / quiz actifs
 */
export function loadSurveyAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('survey-all', siteUrl, 'Survey', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Survey')/items?$select=*&$orderby=Modified desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = String(item.Active || '');
      return a === 'Yes' || a === '1' || a === 'true';
    });

    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun sondage disponible</p>';

    const cards = await Promise.all(
      items.map((item: Record<string, unknown>) =>
        resolveImage(siteUrl, 'Survey', item, '').then((imageUrl) => {
          const title = String(item.Title || '');
          const link = getLink(item);
          const description = item.Description ? String(item.Description) : '';
          const iconHtml = imageUrl
            ? '<img src="' + imageUrl + '" alt="' + title + '">'
            : '<span>QUIZ</span>';

          return `
              <a href="${link}" target="_blank" rel="noopener noreferrer" class="survey-item">
                <div class="survey-item-icon">${iconHtml}</div>
                <div class="survey-item-text">
                  <h6>${title}</h6>
                  ${description ? '<div class="survey-item-description">' + description + '</div>' : ''}
                </div>
                <i class="bi bi-box-arrow-up-right survey-item-arrow"></i>
              </a>`;
        })
      )
    );

    const left = cards.filter((_, i) => i % 2 === 0).join('');
    const right = cards.filter((_, i) => i % 2 === 1).join('');
    return `<div class="row">
          <div class="col-md-6">
            <div class="survey-list">${left}</div>
          </div>
          <div class="col-md-6">
            <div class="survey-list">${right}</div>
          </div>
        </div>`;
  }, CACHE_TTL).catch((err) => {
    console.error('[Survey] load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}
