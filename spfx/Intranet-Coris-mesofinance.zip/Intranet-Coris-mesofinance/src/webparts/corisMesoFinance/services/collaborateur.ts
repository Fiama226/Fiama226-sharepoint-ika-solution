﻿import { resolveImage } from './utils';
import { cacheFetchSmart } from './cache';

const CACHE_TTL = 5 * 60 * 1000;

export function loadTrombinoscope(siteUrl: string): Promise<{ html: string; items: Array<Record<string, unknown>> }> {
  return cacheFetchSmart('trombinoscope', siteUrl, 'Collaborateurs', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Collaborateurs')/items?$select=*&$top=5000`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const collabData: Record<string, unknown>[] = data.value || [];

    const imagePromises = collabData.map((item) => resolveImage(siteUrl, 'Collaborateurs', item, ''));

    const imageUrls = await Promise.all(imagePromises);
    const itemsWithImages: Array<Record<string, unknown>> = collabData.map((item, idx) => ({
      ...item,
      _imageUrl: imageUrls[idx] || '',
    }));

    const html = itemsWithImages.map((item) => {
      const displayName = String(item.displayName || '');
      const givenName = String(item.givenName || '');
      const surname = String(item.surname || '');
      const fullName = displayName || `${givenName} ${surname}`.trim() || 'Nom Prénom';
      const jobTitle = String(item.jobTitle || '');
      const department = String(item.department || '');
      const imageUrl = String(item._imageUrl || '');

      const imgHtml = imageUrl
        ? `<img src="${imageUrl}" class="card-img-top" alt="Photo de ${fullName}">`
        : `<div class="card-img-top d-flex align-items-center justify-content-center" style="background:#f0f0f0;"><i class="bi bi-person-circle" style="font-size:80px;color:#004991;"></i></div>`;

      return `
            <div class="col-md-3 mb-3">
              <div class="card h-100">
                ${imgHtml}
                <div class="card-body">
                  <h5 class="card-title">${fullName}</h5>
                  <p class="card-text">${jobTitle}</p>
                  <p class="card-text">${department}</p>
                </div>
              </div>
            </div>`;
    }).join('');

    return { html, items: itemsWithImages };
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Trombinoscope load error:', err);
    return { html: '<p class="text-center text-muted p-3">Erreur de chargement</p>', items: [] };
  });
}
