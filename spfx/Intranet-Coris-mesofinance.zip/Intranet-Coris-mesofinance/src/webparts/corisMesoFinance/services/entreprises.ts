import { cacheFetchSmart } from './cache';

const LIST_NAME = "Services Entreprises";
const CACHE_TTL = 5 * 60 * 1000;

export function loadEntreprisesAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('entreprises-all', siteUrl, LIST_NAME, async () => {
    const url = `${siteUrl}/_api/web/lists/getbytitle('${LIST_NAME}')/items?$select=*&$orderby=Modified desc`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata' },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []) as Record<string, unknown>[];
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun service disponible</p>';

    const cards = items.map((item) => {
      const title = String(item.Titre || item.Title || '');
      const desc = item.description ? String(item.description) : '';
      const descText = desc.replace(/<[^>]*>/g, '');
      const snippet = descText.length > 200 ? descText.substring(0, 200) + '...' : descText;

      return `
        <div class="col-12 mb-3">
          <div style="border:1px solid #e0e0e0;border-radius:8px;background:#fff;display:flex;flex-direction:row;align-items:center;width:100%;padding:16px 20px;transition:box-shadow 0.2s;" onmouseover="this.style.boxShadow='0 2px 12px rgba(0,73,145,0.10)'" onmouseout="this.style.boxShadow='none'">
            <div style="width:50px;height:50px;min-width:50px;border-radius:50%;background:#004991;color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:bold;margin-right:20px;">${title.charAt(0).toUpperCase()}</div>
            <div style="display:flex;flex-direction:column;justify-content:center;flex:1;">
              <h5 style="color:#004991;font-weight:600;font-size:16px;margin:0 0 6px 0;">${title}</h5>
              ${snippet ? `<p style="color:#555;font-size:13px;line-height:1.6;margin:0 0 10px 0;">${snippet}</p>` : ''}
              <a href="#page-detail-service-entreprise&id=${item.Id}" style="display:inline-block;background:#004991;color:#fff;padding:7px 18px;border-radius:4px;text-decoration:none;font-size:13px;font-weight:500;text-align:center;align-self:flex-start;">
                En savoir plus <i class="bi bi-arrow-right" style="margin-left:4px;"></i>
              </a>
            </div>
          </div>
        </div>`;
    });
    return '<div class="row">' + cards.join('') + '</div>';
  }, CACHE_TTL).catch(() => '<p class="text-center text-muted p-3">Erreur de chargement</p>');
}
