﻿import { resolveImage } from './utils';
import { cacheFetchSmart, cacheFetchSmartItem } from './cache';

const fallbackImg = 'assets/imges/tabs-1.jpg';
const CACHE_TTL = 5 * 60 * 1000;

/**
 * Charge toutes les actualités (liste complète)
 */
export function loadActualitesAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('actualites-all', siteUrl, 'actualites', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('actualites')/items?$select=*&$orderby=NewsDate desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui' || !a;
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucune actualité</p>';

    const cards = items.map((item: Record<string, unknown>) => {
      const title = String(item.Titre || item.Title || '');
      const description = item.Description ? String(item.Description) : '';
      const descriptionText = item.DescriptionText ? String(item.DescriptionText) : '';
      const rawSnippet = descriptionText || (description ? description.replace(/<[^>]*>/g, '') : '');
      const snippet = rawSnippet.length > 80 ? rawSnippet.substring(0, 80) + '…' : rawSnippet;
      let dateStr = '';
      if (item.NewsDate) {
        const d = new Date(String(item.NewsDate));
        dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
      }
      const firstLetter = title ? title.charAt(0).toUpperCase() : 'A';

      return `
          <div style="border:1px solid #eee;border-radius:6px;padding:12px 14px;margin-bottom:12px;background:#fff;">
            <div class="d-flex align-items-center gap-2 mb-2">
              <div style="width:36px;height:36px;min-width:36px;background:#004991;color:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;font-weight:bold;border-radius:5px;">${firstLetter}</div>
              <div>
                <span style="color:#888;font-size:11px;"><i class="bi bi-calendar"></i> ${dateStr}</span>
                <h4 style="color:#004991;font-size:12px;font-weight:600;text-transform:uppercase;margin:0;line-height:1.3;">${title}</h4>
              </div>
            </div>
            ${snippet ? '<p style="color:#004991;font-size:14px;line-height:1.4;margin:0 0 6px 0;">' + snippet + '</p>' : ''}
            ${description ? '<div style="font-size:14px;color:#333;line-height:1.4;max-height:5.6em;overflow:hidden;margin-bottom:6px;">' + description + '</div>' : ''}
            <a href="#page-detail-actualite&id=${item.Id}" style="color:#004991;font-weight:600;text-decoration:none;font-size:12px;">En savoir plus</a>
          </div>`;
    });

    return '<div class="row"><div class="col-md-6">' + cards.filter((_: string, i: number) => i % 2 === 0).join('') + '</div><div class="col-md-6">' + cards.filter((_: string, i: number) => i % 2 === 1).join('') + '</div></div>';
  }, CACHE_TTL).catch((err) => {
    console.error('[Actualites] load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/**
 * Charge le détail d'une actualité par son ID
 */
export function loadActualiteDetail(siteUrl: string, itemId: number): Promise<string> {
  return cacheFetchSmartItem(`detail-actualite-${itemId}`, siteUrl, 'actualites', itemId, async () => {
    try {
      const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('actualites')/items(${itemId})`;
      const res = await fetch(listApiUrl, {
        headers: {
          Accept: 'application/json;odata=nometadata',
          'Content-Type': 'application/json;odata=nometadata',
        },
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`HTTP ${res.status}: ${t}`);
      }
      const item = await res.json();
      if (!item) return '<p class="text-center text-muted p-3">Actualité introuvable</p>';

      const title = String(item.Titre || item.Title || '');
      const descriptionText = item.DescriptionText ? String(item.DescriptionText) : '';
      const description = item.Description ? String(item.Description) : '';
      const resume = descriptionText || (description ? description.replace(/<[^>]*>/g, '').trim() : '');

      let dateStr = '';
      if (item.NewsDate) {
        const d = new Date(String(item.NewsDate));
        dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
        const hours = d.getHours();
        const minutes = d.getMinutes();
        const hh = hours < 10 ? '0' + hours : '' + hours;
        const mm = minutes < 10 ? '0' + minutes : '' + minutes;
        dateStr += ' à  ' + hh + ':' + mm;
      }

      const imageUrl = await resolveImage(siteUrl, 'actualites', item, fallbackImg);
      return `
        <div class="row">
          <div class="col-md-12 text-center">
            ${imageUrl ? `<div class="text-center mb-4">
              <img src="${imageUrl}" class="img-fluid rounded" style="max-width:100%;max-height:450px;object-fit:cover;border-radius:8px;">
            </div>` : ''}
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${title}</h1>
            <p style="color: #888; font-size: 14px; margin-bottom: 20px; text-align:center;">
              <i class="bi bi-calendar"></i> ${dateStr}
            </p>
            ${resume ? `<p style="font-size: 16px; font-weight: 500; color: #333; margin-bottom: 20px; text-align:center;">${resume}</p>` : ''}
            ${description ? `<div style="font-size: 15px; line-height: 1.8; color: #444; max-width:800px; margin-left:auto; margin-right:auto; text-align:center;">${description}</div>` : ''}
            ${(!resume && !description) ? '<p class="text-center text-muted">Aucune description disponible.</p>' : ''}
            <div class="mt-4 text-center">
              <a href="#page-toutes-les-actualites" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour aux actualités
              </a>
            </div>
          </div>
        </div>`;
    } catch (err) {
      console.error('[Actualites] detail load error:', err);
      return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
    }
  });
}
