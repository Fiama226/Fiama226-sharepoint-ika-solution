﻿import { resolveImage } from './utils';
import { cacheFetchSmart } from './cache';

const VALEUR_CACHE_KEY = 'valeur-html';
const VALEUR_TTL = 30 * 60 * 1000;

export function loadValeur(siteUrl: string): Promise<string> {
  const fallbackImg = 'assets/imges/nos_valeurs.png';

  return cacheFetchSmart(VALEUR_CACHE_KEY, siteUrl, 'Valeur', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Valeur')/items?$select=*&$top=20`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui';
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucune donnée</p>';

    const firstItem = items[0];
    const mainTitle = String(firstItem.Title || 'VALEURS');
    const introDesc = String(firstItem.Description || '');

    const values = items.slice(1).map((item: Record<string, unknown>) => {
      const valTitle = String(item.Title || '');
      const valDesc = String(item.Description || '');
      if (!valDesc) return '';
      return `
          <hr>
          <h3 style="margin-left: 20px;">${valTitle}</h3>
          <ul>${valDesc}</ul>`;
    }).join('');

    const mainImageUrl = await resolveImage(siteUrl, 'Valeur', firstItem, fallbackImg);
    return `
        <div class="col-md-12">
          <div style="text-align: center;">
            <img src="${mainImageUrl}" style="max-width: 700px; width: 100%;">
          </div>
        </div>
        <br>
        <div class="col-md-12">
          <br><br><br>
          <div class="group-single-title mb-4">
            <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">${mainTitle}</h1>
            ${introDesc ? `<p style="font-size: 17px; color: black;">${introDesc}</p>` : ''}
            ${values}
          </div>
        </div>`;
  }, VALEUR_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Valeur load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}
