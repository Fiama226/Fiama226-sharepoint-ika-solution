﻿import { resolveImage } from './utils';
import { cacheFetchSmart, cacheFetchSmartItem } from './cache';

const fallbackImg = 'assets/imges/tabs-21.jpg';
const CACHE_TTL = 5 * 60 * 1000;

/**
 * Charge tous les produits (liste complète)
 */
export function loadProduitsAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('produits-all', siteUrl, 'ProductSlides', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('ProductSlides')/items?$select=*&$orderby=Modified desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui' || !a;
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun produit</p>';

    const cards = items.map((item: Record<string, unknown>) => {
      const title = String(item.Titre || item.Title || '');
      const productType = String(item.ProductType || '');
      const description = item.Description ? String(item.Description) : '';
      const descriptionText = description.replace(/<[^>]*>/g, '');
      const snippet = descriptionText.length > 80 ? descriptionText.substring(0, 80) + '...' : descriptionText;
      const firstLetter = title ? title.charAt(0).toUpperCase() : 'P';

      return `
          <div style="border:1px solid #eee;border-radius:6px;padding:12px 14px;margin-bottom:12px;background:#fff;">
            <div class="d-flex align-items-center gap-2 mb-2">
              <div style="width:36px;height:36px;min-width:36px;background:#004991;color:#fff;
                display:flex;align-items:center;justify-content:center;font-size:17px;
                font-weight:bold;border-radius:5px;">${firstLetter}</div>
              <div>
                ${productType ? '<span style="color:#888;font-size:11px;text-transform:uppercase;">' + productType + '</span>' : ''}
                <h4 style="color:#004991;font-size:12px;font-weight:600;text-transform:uppercase;
                  margin:0;line-height:1.3;">${title}</h4>
              </div>
            </div>
            ${snippet ? '<p style="color:#004991;font-size:14px;line-height:1.4;margin:0 0 6px 0;">' + snippet + '</p>' : ''}
            ${description ? '<div style="font-size:14px;color:#333;line-height:1.4;max-height:5.6em;overflow:hidden;margin-bottom:6px;">' + description + '</div>' : ''}
            <a href="#page-detail-produit&id=${item.Id}" style="color:#004991;font-weight:600;text-decoration:none;font-size:12px;">En savoir plus</a>
          </div>`;
    });

    return '<div class="row"><div class="col-md-6">'
      + cards.filter((_: string, i: number) => i % 2 === 0).join('')
      + '</div><div class="col-md-6">'
      + cards.filter((_: string, i: number) => i % 2 === 1).join('')
      + '</div></div>';
  }, CACHE_TTL).catch((err) => {
    console.error('[Produits] load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/**
 * Charge le détail d'un produit par son ID
 */
export function loadProduitDetail(siteUrl: string, itemId: number): Promise<string> {
  return cacheFetchSmartItem(`detail-produit-${itemId}`, siteUrl, 'ProductSlides', itemId, async () => {
    try {
      const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('ProductSlides')/items(${itemId})`;
      const res = await fetch(listApiUrl, {
        headers: {
          Accept: 'application/json;odata=nometadata',
          'Content-Type': 'application/json;odata=nometadata',
        },
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`HTTP ${res.status}: ${t}`);
      }
      const item = await res.json();
      if (!item) return '<p class="text-center text-muted p-3">Produit introuvable</p>';

      const title = String(item.Titre || item.Title || '');
      const productType = String(item.ProductType || '');
      const description = item.Description ? String(item.Description) : '';

      const imageUrl = await resolveImage(siteUrl, 'ProductSlides', item, fallbackImg);
      return `
        <div class="row">
          <div class="col-md-12 text-center">
            ${imageUrl ? `<div class="text-center mb-4">
              <img src="${imageUrl}" class="img-fluid rounded" style="max-width:100%;max-height:450px;object-fit:cover;border-radius:8px;">
            </div>` : ''}
            ${productType ? `<p style="color:#004991;font-size:14px;text-transform:uppercase;font-weight:600;margin-bottom:5px;text-align:center;">${productType}</p>` : ''}
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${title}</h1>
            ${description ? `<div style="font-size: 15px; line-height: 1.8; color: #444; margin-top:20px; max-width:800px; margin-left:auto; margin-right:auto; text-align:center;">${description}</div>` : ''}
            <div class="mt-4 text-center">
              <a href="#page-tous-les-produits" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour aux produits
              </a>
            </div>
          </div>
        </div>`;
    } catch (err) {
      console.error('[Produits] detail load error:', err);
      return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
    }
  });
}
