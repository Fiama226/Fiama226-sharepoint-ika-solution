﻿import { cacheFetchSmart, cacheFetchSmartItem } from './cache';

const CACHE_TTL = 5 * 60 * 1000;

/**
 * Charge tout l'agenda (liste complète)
 */
export function loadAgendaAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('agenda-all', siteUrl, 'Agenda', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Agenda')/items?$select=*&$orderby=StartDateTime desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui' || !a;
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun événement</p>';

    const moisFr: Record<string, string> = {
      '01': 'JAN', '02': 'FÉV', '03': 'MAR', '04': 'AVR',
      '05': 'MAI', '06': 'JUN', '07': 'JUL', '08': 'AOà›',
      '09': 'SEP', '10': 'OCT', '11': 'NOV', '12': 'DÉC',
    };

    const cards = items.map((item: Record<string, unknown>) => {
      const title = String(item.Title || '');
      const startDate = item.StartDateTime ? new Date(String(item.StartDateTime)) : null;
      if (!startDate) {
        return `
            <a href="#page-detail-agenda&id=${item.Id}" class="agenda-item-link">
              <div class="meeting-box">
                <div class="meeting-text">
                  <h6>${title}</h6>
                </div>
              </div>
            </a>`;
      }

      const dayNum = startDate.getDate();
      const monthNum = startDate.getMonth() + 1;
      const day = dayNum < 10 ? '0' + dayNum : '' + dayNum;
      const monthKey = monthNum < 10 ? '0' + monthNum : '' + monthNum;
      const monthLabel = moisFr[monthKey] || monthKey;
      const fullDate = startDate.toLocaleDateString('fr-FR', {
        day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
      }).toUpperCase();

      return `
          <a href="#page-detail-agenda&id=${item.Id}" class="agenda-item-link">
            <div class="meeting-box">
              <div class="meeting-date">
                <h6>${day}</h6>
                <p>${monthLabel}</p>
              </div>
              <div class="meeting-border"></div>
              <div class="meeting-text">
                <h6>${title}</h6>
                <p>${fullDate}</p>
              </div>
            </div>
          </a>`;
    });

    const left = cards.filter((_: string, i: number) => i % 2 === 0).join('');
    const right = cards.filter((_: string, i: number) => i % 2 === 1).join('');

    return `<div class="row">
        <div class="col-md-6">
          <div class="meeting-agendas all-agenda-list">${left}</div>
        </div>
        <div class="col-md-6">
          <div class="meeting-agendas all-agenda-list">${right}</div>
        </div>
      </div>`;
  }, CACHE_TTL).catch((err) => {
    console.error('[Agenda] load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/**
 * Charge le détail d'un événement agenda par son ID
 */
export function loadAgendaDetail(siteUrl: string, itemId: number): Promise<string> {
  return cacheFetchSmartItem(`detail-agenda-${itemId}`, siteUrl, 'Agenda', itemId, async () => {
    try {
      const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Agenda')/items(${itemId})`;
      const res = await fetch(listApiUrl, {
        headers: {
          Accept: 'application/json;odata=nometadata',
          'Content-Type': 'application/json;odata=nometadata',
        },
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`HTTP ${res.status}: ${t}`);
      }
      const item = await res.json();
      if (!item) return '<p class="text-center text-muted p-3">Événement introuvable</p>';

      const title = String(item.Title || '');
      let dateStr = '';
      let endDateStr = '';
      if (item.StartDateTime) {
        const d = new Date(String(item.StartDateTime));
        dateStr = d.toLocaleDateString('fr-FR', {
          day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
        });
      }
      if (item.EndDateTime) {
        const d = new Date(String(item.EndDateTime));
        endDateStr = d.toLocaleDateString('fr-FR', {
          day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
        });
      }
      const location = item.Location ? String(item.Location) : '';
      const description = item.Description ? String(item.Description) : '';

      return `
        <div class="row">
          <div class="col-md-12 text-center">
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${title}</h1>
            <p style="color: #888; font-size: 14px; margin-bottom: 20px; text-align:center;">
              <i class="bi bi-calendar"></i> ${dateStr}
              ${endDateStr ? `<br><i class="bi bi-calendar-check"></i> Fin : ${endDateStr}` : ''}
            </p>
            ${location ? `<p style="text-align:center;color:#666;"><i class="bi bi-geo-alt"></i> ${location}</p>` : ''}
            ${description ? `<div style="font-size: 15px; line-height: 1.8; color: #444; max-width:800px; margin-left:auto; margin-right:auto; text-align:center;">${description}</div>` : ''}
            <div class="mt-4 text-center">
              <a href="#page-tout-agenda" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour à  l'agenda
              </a>
            </div>
          </div>
        </div>`;
    } catch (err) {
      console.error('[Agenda] detail load error:', err);
      return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
    }
  });
}
