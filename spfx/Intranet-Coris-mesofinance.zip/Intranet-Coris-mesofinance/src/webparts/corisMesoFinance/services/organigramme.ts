﻿export interface OrgChartOptions {
  container?: string;
  siteUrl?: string;
}

declare global {
  interface Window {
    initOrgChart: (options?: OrgChartOptions) => void;
  }
}

export function loadOrganigramme(siteUrl: string): Promise<string> {
  setTimeout(() => {
    if (typeof window.initOrgChart === 'function') {
      window.initOrgChart({ container: '#chart-container', siteUrl });
    }
  }, 100);
  return Promise.resolve('');
}
