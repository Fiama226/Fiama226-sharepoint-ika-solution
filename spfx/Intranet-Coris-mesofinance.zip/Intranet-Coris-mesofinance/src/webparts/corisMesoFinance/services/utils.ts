﻿
/**
 * Résout l'URL d'une image depuis une liste SharePoint.
 * Le champ image est stocké comme JSON avec fileName, l'URL réelle vient des AttachmentFiles.
 * @param fieldName - Nom du champ image (défaut: 'Image')
 */
export function resolveImage(siteUrl: string, listName: string, item: Record<string, unknown>, fallbackImg: string, fieldName = 'Image'): Promise<string> {
  const img = item[fieldName];
  if (!img) return Promise.resolve(fallbackImg);
  try {
    const imgData = typeof img === 'string' ? JSON.parse(img) : img;
    if (!imgData.fileName) return Promise.resolve(fallbackImg);
    const itemId = Number(item.Id || item.ID);
    const attachUrl = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})/AttachmentFiles`;
    return fetch(attachUrl, { headers: { Accept: 'application/json;odata=nometadata' } })
      .then((r) => r.json())
      .then((d) => {
        const files: Array<{ FileName: string; ServerRelativeUrl: string }> = d.value || [];
        const match = files.find((f) => f.FileName === imgData.fileName);
        return match ? match.ServerRelativeUrl : fallbackImg;
      })
      .catch(() => fallbackImg);
  } catch (e) {
    return Promise.resolve(fallbackImg);
  }
}
