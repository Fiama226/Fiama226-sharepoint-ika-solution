﻿import { cacheFetchSmart } from './cache';

const FOOTER_CACHE_KEY = 'footer-html';
const FOOTER_TTL = 30 * 60 * 1000;

export async function loadFooter(siteUrl: string): Promise<string> {
  return cacheFetchSmart(FOOTER_CACHE_KEY, siteUrl, 'FooterDetails', async () => {
    const url = `${siteUrl}/_api/web/lists/getbytitle('FooterDetails')/items?$select=*&$top=100`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata' },
    });
    if (!res.ok) {
      const text = await res.text();
      console.error('[Footer] HTTP error:', res.status, text);
      return _fallbackFooter();
    }
    const data = await res.json();
    const items: Array<Record<string, string>> = (data.value || []).filter((i: any) => {
      const a = i.Active;
      if (a === true || a === 1) return true;
      if (typeof a === 'string') return a.toLowerCase() === 'oui' || a.toLowerCase() === 'yes';
      return false;
    });

    if (items.length === 0) {
      console.warn('[Footer] Aucun élément actif trouvé dans FooterDetails');
      return _fallbackFooter();
    }

    console.log('[Footer] Premier élément:', JSON.stringify(items[0], null, 2));

    const groups: Record<string, Array<{ titre: string; url: string }>> = {};
    for (const item of items) {
      const cat = String(item.Category || 'Autres');
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push({ titre: String(item.Title || item.Titre || ''), url: String(item.URL || '') });
    }

    const socialDomains = ['twitter.com', 'x.com', 'linkedin.com', 'facebook.com', 'youtube.com'];
    const socialLinks: Array<{ titre: string; url: string }> = [];
    const categoryGroups: Record<string, Array<{ titre: string; url: string }>> = {};

    Object.keys(groups).forEach((cat) => {
      const catItems = groups[cat];
      const nonSocial = catItems.filter((item: { titre: string; url: string }) => {
        const isSocial = socialDomains.some((d: string) => item.url.toLowerCase().includes(d));
        if (isSocial) socialLinks.push(item);
        return !isSocial;
      });
      if (nonSocial.length > 0) categoryGroups[cat] = nonSocial;
    });

    const catKeys = Object.keys(categoryGroups);
    let html = '<div class="footer"><div class="container"><div class="row">';

    catKeys.forEach((cat, idx) => {
      const items = categoryGroups[cat];
      const hasContact = items.some(i => !i.url || i.url.startsWith('tel:') || i.url.startsWith('mailto:'));
      html += `<div class="col-lg-4 col-md-6 col-12"><div class="single_footer${hasContact ? ' single_footer_address' : ''}"><h4>${_esc(cat)}</h4><ul>`;
      items.forEach(item => {
        const icon = _icon(item.url);
        if (item.url) {
          html += `<li>${icon ? `<i class="bi ${icon} me-2"></i>` : ''}<a href="${_esc(item.url)}" target="_blank" rel="noopener noreferrer">${_esc(item.titre)}</a></li>`;
        } else {
          html += `<li>${icon ? `<i class="bi ${icon} me-2"></i>` : ''}${_esc(item.titre)}</li>`;
        }
      });
      html += '</ul>';

      if (socialLinks.length > 0 && idx === catKeys.length - 1) {
        html += `<div class="single_footer single_footer_address" style="margin-top: 30px;"><h4>Restons connecté sur</h4></div><div class="social_profile"><ul>`;
        socialLinks.forEach(item => {
          const icon = _icon(item.url);
          html += `<li><a href="${_esc(item.url)}" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;justify-content:center;width:42px;height:42px;border-radius:50%;border:1px solid rgba(255,255,255,0.5);color:#fff;text-decoration:none;">${icon ? `<i class="bi ${icon}"></i>` : _esc(item.titre)}</a></li>`;
        });
        html += '</ul></div>';
      }

      html += '</div></div>';
    });

    html += '</div></div>';

    html += `<div class="container-fluid"><div class="row"><div class="col-12"><p class="copyright">Copyright &copy; ${new Date().getFullYear()} <a href="#">CORIS HOLDING</a>.</p></div></div></div></div>`;

    return html;
  }, FOOTER_TTL);
}

function _esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function _icon(url: string): string {
  if (!url) return 'bi-geo-alt-fill';
  if (url.startsWith('tel:')) return 'bi-telephone-fill';
  if (url.startsWith('mailto:')) return 'bi-envelope-fill';
  if (url.includes('x.com') || url.includes('twitter.com')) return 'bi-twitter';
  if (url.includes('linkedin.com')) return 'bi-linkedin';
  if (url.includes('facebook.com')) return 'bi-facebook';
  if (url.includes('youtube.com')) return 'bi-youtube';
  return '';
}

function _fallbackFooter(): string {
  return `<div class="footer"><div class="container"><div class="row"><div class="col-12 text-center p-3"><p class="copyright">Copyright &copy; ${new Date().getFullYear()} <a href="#">CORIS HOLDING</a>.</p></div></div></div></div>`;
}
