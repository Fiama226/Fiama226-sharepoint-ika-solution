export interface ISocialComment {
  user: string;
  email: string;
  text: string;
  date: string;
}

export type SocialListName = 'annonces' | 'EmployeDuMois';

export function parseLikedBy(value: unknown): string[] {
  try {
    const parsed = JSON.parse(String(value || '[]'));
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}

export function getLikedByFromItem(item: Record<string, unknown>): string[] {
  const keys = Object.keys(item);
  const likeField = keys.find((k) => k.toLowerCase().replace(/[^a-z]/g, '') === 'likedby') || 'LikedBy';
  return parseLikedBy(item[likeField]);
}

export function parseComments(value: unknown): ISocialComment[] {
  try {
    const parsed = JSON.parse(String(value || '[]'));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function getSocialPrefix(listName: SocialListName, itemId: number): string {
  return listName === 'annonces' ? `annonce-${itemId}` : `edm-${itemId}`;
}

function formatCommentDate(dateStr: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
}

function getInitials(name: string): string {
  return (name || 'U')
    .split(' ')
    .map((p) => p[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();
}

export function buildCommentsListHtml(comments: ISocialComment[]): string {
  if (comments.length === 0) {
    return '<p class="social-no-comments">Aucun commentaire. Soyez le premier à  commenter !</p>';
  }

  return comments
    .slice()
    .reverse()
    .map((c) => {
      const dateLabel = formatCommentDate(c.date);
      const initials = getInitials(c.user || 'Utilisateur');
      return `
        <div class="social-comment-item">
          <div class="social-comment-avatar">${initials}</div>
          <div class="social-comment-body">
            <div class="social-comment-meta">
              <span class="social-comment-author">${c.user || 'Utilisateur'}</span>
              ${dateLabel ? `<span class="social-comment-date">${dateLabel}</span>` : ''}
            </div>
            <p class="social-comment-text">${c.text}</p>
          </div>
        </div>`;
    })
    .join('');
}

export interface ISocialWidgetOptions {
  listName: SocialListName;
  itemId: number;
  likedBy: string[];
  comments: ISocialComment[];
  currentUserEmail?: string;
  currentUserDisplayName?: string;
  variant?: 'default' | 'compact' | 'compact-light';
}

export function buildSocialWidgetHtml(options: ISocialWidgetOptions): string {
  const {
    listName,
    itemId,
    likedBy,
    comments,
    currentUserEmail = '',
    currentUserDisplayName = '',
    variant = 'default',
  } = options;

  const prefix = getSocialPrefix(listName, itemId);
  const hasLiked = currentUserEmail ? likedBy.indexOf(currentUserEmail) !== -1 : false;
  const likeCount = likedBy.length;
  const commentCount = comments.length;
  const isCompact = variant === 'compact' || variant === 'compact-light';

  const barClass =
    variant === 'compact-light'
      ? 'social-bar social-bar-compact social-bar-compact--light'
      : variant === 'compact'
        ? 'social-bar social-bar-compact'
        : 'social-bar';

  const likeLabel = isCompact
    ? ''
    : `<span class="social-like-label">${likeCount > 1 ? 'J\'aimes' : 'J\'aime'}</span>`;

  const commentLabel = isCompact
    ? `<span class="social-comment-label social-comment-label--count-only">${commentCount}</span>`
    : `<span class="social-comment-label">${commentCount} Commentaire${commentCount > 1 ? 's' : ''}</span>`;

  return `
    <div class="${barClass}"
      data-social-list="${listName}"
      data-social-item-id="${itemId}">
      <button
        type="button"
        class="social-like-btn ${hasLiked ? 'liked' : ''}"
        id="like-btn-${prefix}"
        title="${hasLiked ? 'Retirer votre j\'aime' : 'J\'aimer cette publication'}">
        <i class="bi ${hasLiked ? 'bi-hand-thumbs-up-fill' : 'bi-hand-thumbs-up'}"></i>
        <span class="social-like-count" id="like-count-${prefix}">${likeCount}</span>
        ${likeLabel}
      </button>
      <button type="button" class="social-comment-toggle-btn" id="comment-toggle-${prefix}">
        <i class="bi bi-chat-dots${commentCount > 0 ? '-fill' : ''}"></i>
        ${commentLabel}
      </button>
    </div>`;
}
