import { cacheFetchSmart, cacheFetchSmartItem } from './cache';
import { resolveImage } from './utils';

const LIST_NAME = "Services Particuliers";
const FALLBACK_IMG = 'assets/imges/tabs-21.jpg';
const CACHE_TTL = 5 * 60 * 1000;

export function loadServicesAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('services-all', siteUrl, LIST_NAME, async () => {
    const url = `${siteUrl}/_api/web/lists/getbytitle('${LIST_NAME}')/items?$select=*&$orderby=Modified desc`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata' },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []) as Record<string, unknown>[];
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun service disponible</p>';

    const cards = await Promise.all(items.map(async (item) => {
      const title = String(item.Titre || item.Title || '');
      const description = item.description ? String(item.description) : '';
      const descText = description.replace(/<[^>]*>/g, '');
      const snippet = descText.length > 150 ? descText.substring(0, 150) + '...' : descText;
      const imgUrl = await resolveImage(siteUrl, LIST_NAME, item, FALLBACK_IMG, 'image');

      return `
        <div class="col-lg-4 col-md-6 mb-4 d-flex">
          <div style="border:1px solid #e0e0e0;border-radius:8px;overflow:hidden;background:#fff;display:flex;flex-direction:column;width:100%;">
            <div style="height:200px;overflow:hidden;background:#f5f5f5;">
              <img src="${imgUrl}" alt="${title}" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'">
            </div>
            <div style="padding:18px 16px 20px;display:flex;flex-direction:column;flex:1;">
              <h5 style="color:#004991;font-weight:600;font-size:16px;margin:0 0 10px 0;">${title}</h5>
              ${snippet ? `<p style="color:#555;font-size:13px;line-height:1.5;margin:0 0 14px 0;flex:1;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;">${snippet}</p>` : '<div style="flex:1;"></div>'}
              <a href="#page-detail-service-particulier&id=${item.Id}" style="display:inline-block;background:#004991;color:#fff;padding:8px 20px;border-radius:4px;text-decoration:none;font-size:13px;font-weight:500;text-align:center;align-self:flex-start;">
                En savoir plus <i class="bi bi-arrow-right" style="margin-left:4px;"></i>
              </a>
            </div>
          </div>
        </div>`;
    }));
    return '<div class="row">' + cards.join('') + '</div>';
  }, CACHE_TTL).catch((err) => {
    console.error('[Services Particuliers] load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

export function loadServiceDetail(siteUrl: string, itemId: number): Promise<string> {
  return cacheFetchSmartItem(`service-detail-${itemId}`, siteUrl, LIST_NAME, itemId, async () => {
    try {
      const url = `${siteUrl}/_api/web/lists/getbytitle('${LIST_NAME}')/items(${itemId})`;
      const res = await fetch(url, {
        headers: { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata' },
      });
      if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
      const item = await res.json() as Record<string, unknown>;
      if (!item) return '<p class="text-center text-muted p-3">Service introuvable</p>';

      const title = String(item.Titre || item.Title || '');
      const description = item.description ? String(item.description) : '';
      const imgUrl = await resolveImage(siteUrl, LIST_NAME, item, FALLBACK_IMG, 'image');

      return `
        <div class="row">
          <div class="col-md-12">
            ${imgUrl ? `<div class="text-center mb-4">
              <img src="${imgUrl}" class="img-fluid rounded" style="max-width:100%;max-height:450px;object-fit:cover;border-radius:8px;">
            </div>` : ''}
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${title}</h1>
            ${description ? `<div style="font-size: 15px; line-height: 1.8; color: #444; margin-top:20px; max-width:800px; margin-left:auto; margin-right:auto; text-align:center;">${description}</div>` : ''}
            <div class="mt-4 text-center">
              <a href="#page-service-particulier" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour aux services
              </a>
            </div>
          </div>
        </div>`;
    } catch (err) {
      console.error('[Services Particuliers] detail error:', err);
      return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
    }
  });
}
