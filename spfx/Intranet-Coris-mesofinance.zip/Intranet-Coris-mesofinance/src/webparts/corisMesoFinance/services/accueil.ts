﻿import { buildSocialWidgetHtml, parseComments, parseLikedBy, getLikedByFromItem } from './social';
import { cacheFetchSmart } from './cache';

const CACHE_TTL = 5 * 60 * 1000;

function fetchList(siteUrl: string, listName: string, select = '*'): Promise<any[]> {
  const url = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=${select}&$top=100`;
  return fetch(url, {
    headers: {
      Accept: 'application/json;odata=nometadata',
      'Content-Type': 'application/json;odata=nometadata',
    },
  })
    .then((res) => {
      if (!res.ok) { return res.text().then((t) => { throw new Error(`HTTP ${res.status}: ${t}`); }); }
      return res.json();
    })
    .then((data) => data.value || []);
}

function fetchJson<T>(url: string): Promise<T> {
  return fetch(url, {
    headers: {
      Accept: 'application/json;odata=nometadata',
      'Content-Type': 'application/json;odata=nometadata',
    },
  })
    .then((res) => {
      if (!res.ok) { return res.text().then((t) => { throw new Error(`HTTP ${res.status}: ${t}`); }); }
      return res.json();
    });
}

function escapeODataString(value: string): string {
  return value.replace(/'/g, "''");
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function getGalerieRootUrl(siteUrl: string): Promise<string> {
  const url = `${siteUrl}/_api/web/lists/getbytitle('galerie')/RootFolder?$select=ServerRelativeUrl`;
  return fetchJson<{ ServerRelativeUrl: string }>(url).then((data) => data.ServerRelativeUrl);
}

function isImageFile(fileName: string): boolean {
  return /\.(apng|avif|bmp|gif|jpe?g|png|svg|webp)$/i.test(fileName);
}

function imageUrl(siteUrl: string, listName: string, itemId: number, fileName: string): Promise<string> {
  const attachUrl = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})/AttachmentFiles`;
  return fetch(attachUrl, { headers: { Accept: 'application/json;odata=nometadata' } })
    .then((r) => r.json())
    .then((d) => {
      const files: Array<{ FileName: string; ServerRelativeUrl: string }> = d.value || [];
      const match = files.find((f) => f.FileName === fileName);
      return match ? match.ServerRelativeUrl : '';
    })
    .catch(() => '');
}

function resolveImage(item: Record<string, unknown>, siteUrl: string, listName: string, fallback: string, fieldName = 'Image'): Promise<string> {
  const img = item[fieldName];
  if (!img) return Promise.resolve(fallback);
  try {
    const imgData = typeof img === 'string' ? JSON.parse(img) : img;
    if (!imgData.fileName) return Promise.resolve(fallback);
    const itemId = Number(item.Id || item.ID);
    return imageUrl(siteUrl, listName, itemId, imgData.fileName);
  } catch (e) {
    return Promise.resolve(fallback);
  }
}

/* â”€â”€ Agenda â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadAgenda(siteUrl: string): Promise<string> {
  return cacheFetchSmart('agenda-home', siteUrl, 'Agenda', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Agenda')/items?$select=Id,Title,StartDateTime&$orderby=StartDateTime desc&$top=6`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    if (!data.value || data.value.length === 0) return '<p class="text-center text-muted p-3">Aucun événement</p>';

    const moisFr: Record<string, string> = {
      '01': 'JAN', '02': 'FÉV', '03': 'MAR', '04': 'AVR',
      '05': 'MAI', '06': 'JUN', '07': 'JUL', '08': 'AOà›',
      '09': 'SEP', '10': 'OCT', '11': 'NOV', '12': 'DÉC',
    };

    return data.value.map((item: { Id: number; Title: string; StartDateTime: string }) => {
      const d = new Date(item.StartDateTime);
      const dayNum = d.getDate();
      const monthNum = d.getMonth() + 1;
      const day = dayNum < 10 ? '0' + dayNum : '' + dayNum;
      const monthKey = monthNum < 10 ? '0' + monthNum : '' + monthNum;
      const monthLabel = moisFr[monthKey] || monthKey;
      const fullDate = d.toLocaleDateString('fr-FR', {
        day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
      }).toUpperCase();

      return `
          <a href="#page-detail-agenda&id=${item.Id}" class="meeting-box-link" style="text-decoration:none;color:inherit;display:block;">
            <div class="meeting-box">
              <div class="meeting-date">
                <h6>${day}</h6>
                <p>${monthLabel}</p>
              </div>
              <div class="meeting-border"></div>
              <div class="meeting-text">
                <h6 class="agenda-title" style="transition: color 0.2s;">${item.Title}</h6>
                <p>${fullDate}</p>
              </div>
            </div>
          </a>`;
    }).join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Agenda load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/* â”€â”€ Evenements â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadEvenements(siteUrl: string): Promise<string> {
  return cacheFetchSmart('evenements-home', siteUrl, 'Evenement', async () => {
    const items = await fetchList(siteUrl, 'Evenement', '*');
    const filtered = items
      .filter((item: { Active: unknown }) => item.Active === true || item.Active === 1 || item.Active === 'Yes')
      .sort((a: { EventDate: string }, b: { EventDate: string }) => new Date(b.EventDate).getTime() - new Date(a.EventDate).getTime());

    if (filtered.length === 0) return '<p class="text-center text-muted p-3">Aucun événement</p>';

    const htmls = await Promise.all(
      filtered.map(async (item: Record<string, unknown>) => {
        const img = await resolveImage(item, siteUrl, 'Evenement', 'assets/imges/event-1.jpg', 'Images');
        const eventDate = item.EventDate || '';
        const eventText = item.EventText || '';
        const d = eventDate ? new Date(String(eventDate)) : new Date();
        const now = new Date();
        const diffMs = now.getTime() - d.getTime();
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        let timeLabel: string;
        if (diffDays === 0) timeLabel = "Aujourd'hui";
        else if (diffDays === 1) timeLabel = 'Hier';
        else if (diffDays < 30) timeLabel = 'Il y a ' + diffDays + ' jours';
        else if (diffDays < 365) timeLabel = 'Il y a ' + Math.floor(diffDays / 30) + ' mois';
        else timeLabel = 'Il y a ' + Math.floor(diffDays / 365) + ' an' + (Math.floor(diffDays / 365) > 1 ? 's' : '');
        const snippet = eventText ? String(eventText).substring(0, 120) + (String(eventText).length > 120 ? '…' : '') : '';

        return `
              <div class="event-news">
                <a href="#page-detail-evenement&id=${item.Id}" class="d-flex align-content-start gap-2">
                  <div class="img-box"><img src="${img}"></div>
                  <div class="event-text">
                    <div><p>${item.Title || ''}</p></div>
                    <h3>${snippet}</h3>
                    <div class="mb-auto d-flex align-items-center gap-2">
                      <div class="event-time">
                        <i class="bi bi-clock-history"></i>
                        <span>${timeLabel}</span>
                      </div>
                    </div>
                  </div>
                </a>
              </div>`;
      })
    );
    return htmls.join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Evenements load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/* â”€â”€ Articles â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadArticles(siteUrl: string): Promise<string> {
  return cacheFetchSmart('articles-home', siteUrl, 'Articles', async () => {
    const items = await fetchList(siteUrl, 'Articles', '*');
    const filtered = items
      .filter((item: { Active: unknown }) => item.Active === true || item.Active === 1 || item.Active === 'Yes')
      .sort((a: { NewsDate: string }, b: { NewsDate: string }) => new Date(b.NewsDate).getTime() - new Date(a.NewsDate).getTime());

    if (filtered.length === 0) return '<p class="text-center text-muted p-3">Aucun article</p>';

    const htmls = await Promise.all(
      filtered.map(async (item: Record<string, unknown>) => {
        const img = await resolveImage(item, siteUrl, 'Articles', 'assets/imges/artical-1.jpg', 'Images');
        const newsDate = item.NewsDate || '';
        const newsText = item.NewsText || '';
        const d = newsDate ? new Date(String(newsDate)) : new Date();
        const now = new Date();
        const diffMs = now.getTime() - d.getTime();
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        let timeLabel: string;
        if (diffDays === 0) timeLabel = "Aujourd'hui";
        else if (diffDays === 1) timeLabel = 'Hier';
        else if (diffDays < 30) timeLabel = 'Il y a ' + diffDays + ' jours';
        else if (diffDays < 365) timeLabel = 'Il y a ' + Math.floor(diffDays / 30) + ' mois';
        else timeLabel = 'Il y a ' + Math.floor(diffDays / 365) + ' an' + (Math.floor(diffDays / 365) > 1 ? 's' : '');
        const snippet = newsText ? String(newsText).substring(0, 120) + (String(newsText).length > 120 ? '…' : '') : '';

        return `
              <div class="event-news">
                <a href="#" class="d-flex align-content-start gap-2">
                  <div class="img-box"><img src="${img}"></div>
                  <div class="event-text">
                    <h6>${item.Title || ''}</h6>
                    <h3>${snippet}</h3>
                    <div class="mb-auto d-flex align-items-center gap-2">
                      <div class="event-time">
                        <i class="bi bi-clock-history"></i>
                        <span>${timeLabel}</span>
                      </div>
                    </div>
                  </div>
                </a>
              </div>`;
      })
    );
    return htmls.join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Articles load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/* â”€â”€ Devise (Informations Financieres) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadDevise(siteUrl: string): Promise<{ transfert: string; cash: string }> {
  return cacheFetchSmart('devise-home', siteUrl, 'InformationsFinancieres', async () => {
    const items = await fetchList(siteUrl, 'InformationsFinancieres', '*');
    const filtered = items.filter((item: { Active: unknown }) => item.Active === true || item.Active === 1 || item.Active === 'Yes');

    if (filtered.length === 0) {
      return { transfert: '<p class="text-center text-muted p-3">Aucune donnée</p>', cash: '<p class="text-center text-muted p-3">Aucune donnée</p>' };
    }

    const fmt = (v: any): string => v != null ? Number(v).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '-';

    const buildTable = (achCol: string, ventCol: string): string => {
      const rows = filtered.map((item: any) => `
        <tr>
          <td>${item.Title || ''}</td>
          <td>${fmt(item[achCol])}</td>
          <td>${fmt(item[ventCol])}</td>
        </tr>`).join('');
      return `
        <table class="devise-table">
          <thead>
            <tr>
              <th>Devise</th>
              <th>Achat</th>
              <th>Vente</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>`;
    };

    return { transfert: buildTable('AchatTransfert', 'VenteTransfert'), cash: buildTable('AchatCash', 'VenteCash') };
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Devise load error:', err);
    return { transfert: '<p class="text-center text-muted p-3">Erreur de chargement</p>', cash: '<p class="text-center text-muted p-3">Erreur de chargement</p>' };
  });
}

/* â”€â”€ Collaborateurs (Nouveaux) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadCollaborateurs(siteUrl: string): Promise<string> {
  return cacheFetchSmart('collaborateurs-home', siteUrl, 'Nouveaux collaborateurs', async () => {
    const items = await fetchList(siteUrl, 'Nouveaux collaborateurs', '*');
    const filtered = items.filter((item: { Active: unknown }) => item.Active === true || item.Active === 1 || item.Active === 'Yes').slice(0, 6);

    if (filtered.length === 0) return '<p class="text-center text-muted p-3">Aucun collaborateur</p>';

    const htmls = await Promise.all(
      filtered.map(async (item: Record<string, unknown>) => {
        const img = await resolveImage(item, siteUrl, 'Nouveaux collaborateurs', 'assets/imges/user-1.jpg', 'MemberProfileImage');
        const email = String(item.MemberEmail || '#');
        const tel = String(item.MemberTelephone || '');
        const division = String(item.Division || '');
        const position = String(item.MemberPosition || '');
        const name = String(item.Title || '');
        const esc = (s: string) => s.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        return `
              <div class="staff-director" role="button" tabindex="0"
                data-collab-name="${esc(name)}"
                data-collab-position="${esc(position)}"
                data-collab-email="${esc(email)}"
                data-collab-phone="${esc(tel)}"
                data-collab-division="${esc(division)}"
                data-collab-image="${esc(img)}">
                <div class="staff-photos"><img src="${img}"></div>
                <div class="d-flex align-items-end justify-content-between flex-grow-1 gap-3">
                  <div class="staff-name">
                    <h5>${name}</h5>
                    <p>${position}</p>
                  </div>
                  <div class="staff-icons">
                    <a href="tel:${tel}"><button onclick="event.stopPropagation()"><i class="bi bi-chat-dots-fill"></i></button></a>
                    <a href="mailto:${email}"><button onclick="event.stopPropagation()"><i class="bi bi-envelope-fill"></i></button></a>
                  </div>
                </div>
              </div>`;
      })
    );
    return htmls.join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Collaborateurs load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/* â”€â”€ Collaborateurs List (tableau) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadCollaborateursList(siteUrl: string): Promise<{ html: string; depts: string[]; count: number; items: Array<Record<string, unknown>> }> {
  return cacheFetchSmart('collaborateurs-list', siteUrl, 'Collaborateurs', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Collaborateurs')/items?$select=*&$top=5000&$orderby=department asc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const collabData = data.value || [];
    const depts = new Set<string>();
    collabData.forEach((item: Record<string, unknown>) => {
      const dept = item.department || item.Department || '';
      if (dept) depts.add(String(dept));
    });

    const imagePromises = collabData.map((item: Record<string, unknown>) => {
      const img = item.userImg;
      if (!img) return Promise.resolve('');
      try {
        const imgData = typeof img === 'string' ? JSON.parse(img) : img;
        if (!imgData.fileName) return Promise.resolve('');
        const itemId = item.Id || item.ID;
        const attachUrl = siteUrl + "/_api/web/lists/getbytitle('Collaborateurs')/items(" + itemId + ")/AttachmentFiles";
        return fetch(attachUrl, { headers: { Accept: 'application/json;odata=nometadata' } })
          .then((r) => r.json())
          .then((d) => {
            const files: Array<{ FileName: string; ServerRelativeUrl: string }> = d.value || [];
            const match = files.find((f) => f.FileName === imgData.fileName);
            return match ? match.ServerRelativeUrl : '';
          })
          .catch(() => '');
      } catch (e) {
        return Promise.resolve('');
      }
    });

    const imageUrls = await Promise.all(imagePromises);
    const rows = collabData.map((item: Record<string, unknown>, idx: number) => {
      const img = imageUrls[idx];
      const imgHtml = img
        ? '<div class="table-user"><img src="' + img + '"></div>'
        : '<div class="table-user d-flex align-items-center justify-content-center" style="width:24px;height:24px"><i class="bi bi-person-circle" style="font-size:24px;color:#004991"></i></div>';
      const esc = (s: string) => s.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
      const givenName = String(item.givenName || item.displayName || '');
      const surname = String(item.surname || '');
      const mail = String(item.mail || '');
      const jobTitle = String(item.jobTitle || '');
      const dept = String(item.department || '');
      const phones = String(item.businessPhones || '');
      const office = String(item.officeLocation || '');
      const mobile = String(item.mobilePhone || '');
      const country = String(item.country || '');
      const usageLoc = String(item.usageLocation || '');
      const upn = String(item.userPrincipalName || '');
      const uid = String(item.userId || '');
      const filiale = String(item.NomFiliales || '');
      return `
            <tr role="button" tabindex="0"
              data-detail-image="${esc(img)}"
              data-detail-name="${esc(givenName + ' ' + surname)}"
              data-detail-given="${esc(givenName)}"
              data-detail-surname="${esc(surname)}"
              data-detail-mail="${esc(mail)}"
              data-detail-jobtitle="${esc(jobTitle)}"
              data-detail-department="${esc(dept)}"
              data-detail-phones="${esc(phones)}"
              data-detail-office="${esc(office)}"
              data-detail-mobile="${esc(mobile)}"
              data-detail-country="${esc(country)}"
              data-detail-usage="${esc(usageLoc)}"
              data-detail-upn="${esc(upn)}"
              data-detail-uid="${esc(uid)}"
              data-detail-filiale="${esc(filiale)}">
              <td>${imgHtml}</td>
              <td>${givenName}</td>
              <td>${surname}</td>
              <td>${mail}</td>
              <td>${jobTitle}</td>
              <td>${dept}</td>
              <td>${phones}</td>
              <td>${office}</td>
              <td>${mobile}</td>
            </tr>`;
    }).join('');

    const itemsWithImages = collabData.map((item: Record<string, unknown>, idx: number) => ({
      ...item,
      _imageUrl: imageUrls[idx] || '',
    }));
    return { html: rows, depts: Array.from(depts).sort(), count: collabData.length, items: itemsWithImages };
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Collaborateurs list load error:', err);
    return { html: '<tr><td colspan="9" class="text-center text-muted p-3">Erreur de chargement</td></tr>', depts: [], count: 0, items: [] };
  });
}

/* â”€â”€ Employe du mois â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadEmployeDuMois(
  siteUrl: string,
  currentUserEmail = '',
  currentUserDisplayName = ''
): Promise<string> {
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  return cacheFetchSmart('employe-du-mois', siteUrl, 'EmployeDuMois', async () => {
    const items = await fetchList(siteUrl, 'EmployeDuMois', '*');
    const filtered = items.filter((item: Record<string, unknown>) => {
      const m = String(item.Month || '');
      const y = String(item.Year || '');
      const a = String(item.Active || '');
      return m === String(currentMonth) && y === String(currentYear) && (a === 'Yes' || a === '1' || a === 'true');
    });

    if (filtered.length === 0) return '<h2><a href="#page-tous-les-employes-du-mois" class="actualites-link">Employé du mois</a></h2><p class="text-center text-muted">Aucun employé ce mois</p>';

    const item = filtered[0];
    const title = String(item.Title || '');
    const position = String(item.Position || '');
    const likedBy = getLikedByFromItem(item);
    const comments = parseComments(item.Comments);
    const itemId = Number(item.Id);

    const img = await resolveImage(item, siteUrl, 'EmployeDuMois', '');
    const imgHtml = img
      ? '<img src="' + img + '" style="width:100px;height:100px;object-fit:cover;border-radius:50%">'
      : '<i class="bi bi-person-circle" style="font-size:80px;color:rgba(255,255,255,0.85)"></i>';

    const socialHtml = buildSocialWidgetHtml({
      listName: 'EmployeDuMois',
      itemId,
      likedBy,
      comments,
      currentUserEmail,
      currentUserDisplayName,
      variant: 'compact-light',
    });

    return `
        <h2><a href="#page-tous-les-employes-du-mois" class="actualites-link">Employé du mois</a></h2>
        <div class="user-img">${imgHtml}</div>
        <h5>${title}</h5>
        <p style="color:#fff">${position}</p>
        ${socialHtml}
        <a href="#page-detail-employe-du-mois&id=${itemId}">Voir le profil</a>`;
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Employé du mois load error:', err);
    return '<h2><a href="#page-tous-les-employes-du-mois" class="actualites-link">Employé du mois</a></h2><p class="text-center text-muted">Erreur de chargement</p>';
  });
}

/* â”€â”€ Outils â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadOutils(siteUrl: string): Promise<string> {
  return cacheFetchSmart('outils-home', siteUrl, 'Outils', async () => {
    const items = await fetchList(siteUrl, 'Outils', '*');
    const filtered = items.filter((item: { Active: unknown }) => item.Active === true || item.Active === 1 || item.Active === 'Yes');
    if (filtered.length === 0) return '<p class="text-center text-muted p-3">Aucun outil</p>';

    const getLink = (item: Record<string, unknown>): string => {
      const link = item.LinktoAccess;
      if (!link) return '#';
      if (typeof link === 'string') return link;
      if ((link as { Url?: string }).Url) return (link as { Url: string }).Url;
      return '#';
    };

    const htmls = await Promise.all(
      filtered.map(async (item: Record<string, unknown>) => {
        const img = await resolveImage(item, siteUrl, 'Outils', '', 'ToolImage');
        const link = getLink(item);
        const icon = img
          ? '<img src="' + img + '" style="width:40px;height:40px;object-fit:contain">'
          : '<i class="bi bi-tools" style="font-size:24px"></i>';
        return `
            <a href="${link}" class="outlink-box" target="_blank">
              <div class="outlink-box-link">
                ${icon}
                <p>${item.Title || ''}</p>
              </div>
            </a>`;
      })
    );
    return htmls.join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Outils load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/* â”€â”€ Survey â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
/* Galerie */
export interface IGalerieImage {
  title: string;
  description: string;
  name: string;
  url: string;
}

export function loadGalerieFolders(siteUrl: string): Promise<string> {
  return cacheFetchSmart('galerie-folders', siteUrl, 'galerie', async () => {
    const rootUrl = await getGalerieRootUrl(siteUrl);
    const url = `${siteUrl}/_api/web/GetFolderByServerRelativeUrl('${escapeODataString(rootUrl)}')/Folders?$select=Name,ServerRelativeUrl,TimeLastModified,ItemCount&$orderby=Name asc`;
    const data = await fetchJson<{ value: Array<{ Name: string; ServerRelativeUrl: string; ItemCount?: number }> }>(url);
    const folders = (data.value || []).filter((folder) => {
      const name = String(folder.Name || '');
      return name && name !== 'Forms' && !name.startsWith('_');
    });

    if (folders.length === 0) return '<p class="text-center text-muted p-3">Aucun dossier</p>';

    return folders.map((folder) => {
      const title = String(folder.Name || '');
      const count = Number(folder.ItemCount || 0);
      return `
          <button type="button" class="galerie-folder" data-gallery-folder-url="${escapeHtml(folder.ServerRelativeUrl)}" data-gallery-folder-title="${escapeHtml(title)}">
            <span class="galerie-folder-icon"><i class="bi bi-folder-fill"></i></span>
            <span class="galerie-folder-title">${escapeHtml(title)}</span>
            ${count > 0 ? `<span class="galerie-folder-count">${count}</span>` : ''}
          </button>`;
    }).join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Galerie folders load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

export function loadGalerieImages(siteUrl: string, folderUrl: string): Promise<IGalerieImage[]> {
  const cacheKey = `galerie-images-${folderUrl}`;
  return cacheFetchSmart(cacheKey, siteUrl, 'galerie', async () => {
    const url = `${siteUrl}/_api/web/GetFolderByServerRelativeUrl('${escapeODataString(folderUrl)}')/Files?$select=Name,ServerRelativeUrl,TimeLastModified,ListItemAllFields/Title,ListItemAllFields/_ExtendedDescription,ListItemAllFields/Description&$expand=ListItemAllFields&$orderby=Name asc&$top=5000`;
    const data = await fetchJson<{
      value: Array<{
        Name: string;
        ServerRelativeUrl: string;
        ListItemAllFields?: {
          Title?: string;
          _ExtendedDescription?: string;
          Description?: string;
        };
      }>;
    }>(url);
    return (data.value || [])
      .filter((file) => isImageFile(String(file.Name || '')))
      .map((file) => {
        const fields = file.ListItemAllFields || {};
        const title = String(fields.Title || file.Name || '');
        const description = String(fields._ExtendedDescription || fields.Description || '');
        return {
          title,
          description,
          name: String(file.Name || ''),
          url: encodeURI(String(file.ServerRelativeUrl || '')),
        };
      });
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Galerie images load error:', err);
    return [];
  });
}

export function loadSurvey(siteUrl: string): Promise<string> {
  return cacheFetchSmart('survey-home', siteUrl, 'Survey', async () => {
    const items = await fetchList(siteUrl, 'Survey', '*');
    const filtered = items.filter((item: Record<string, unknown>) => {
      const a = String(item.Active || '');
      return a === 'Yes' || a === '1' || a === 'true';
    }).slice(0, 3);

    if (filtered.length === 0) return '<p class="text-center text-muted p-3">Aucun sondage</p>';

    const getLink = (item: Record<string, unknown>): string => {
      const link = item.Link;
      if (!link) return '#';
      if (typeof link === 'string') return link;
      if ((link as { Url?: string }).Url) return (link as { Url: string }).Url;
      return '#';
    };

    const htmls = await Promise.all(
      filtered.map(async (item: Record<string, unknown>) => {
        const img = await resolveImage(item, siteUrl, 'Survey', '');
        const title = String(item.Title || '');
        const link = getLink(item);
        const iconHtml = img
          ? '<img src="' + img + '" style="width:48px;height:48px;border-radius:50%;object-fit:cover">'
          : '<div style="width:48px;height:48px;border-radius:50%;background:#E40E20;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:11px;flex-shrink:0">QUIZ</div>';
        return `
            <a href="${link}" target="_blank" class="survey-home-item" style="display:flex;align-items:center;gap:12px;padding:10px 8px;text-decoration:none;color:#004991;border-bottom:1px solid #f0f0f0;transition:background 0.2s,color 0.2s">
              <div style="flex-shrink:0">${iconHtml}</div>
              <span style="font-size:14px;font-weight:500;line-height:1.4">${title}</span>
            </a>`;
      })
    );
    return htmls.join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Survey load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/* â”€â”€ Announcements â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadAnnouncements(
  siteUrl: string,
  currentUserEmail = '',
  currentUserDisplayName = ''
): Promise<Record<string, string>> {
  return cacheFetchSmart('announcements-home', siteUrl, 'annonces', async () => {
    const items = await fetchList(siteUrl, 'annonces', '*');
    const now = new Date();
    const valid = items.filter((item: Record<string, unknown>) => {
      const startDate = item.DateDeEvenement ? new Date(String(item.DateDeEvenement)) : null;
      const endDate = item.DateDeFin ? new Date(String(item.DateDeFin)) : null;
      if (startDate && now < startDate) return false;
      if (endDate && now > endDate) return false;
      return true;
    });

    const groups: Record<string, Array<Record<string, unknown>>> = { birthday: [], mariage: [], death: [], other: [] };
    valid.forEach((item: Record<string, unknown>) => {
      const t = String(item.type || '').toLowerCase();
      if (t === 'anniversaire') groups.birthday.push(item);
      else if (t === 'mariage') groups.mariage.push(item);
      else if (t === 'nécrologie' || t === 'necrologie') groups.death.push(item);
      else groups.other.push(item);
    });

    const greetingMap: Record<string, string> = {
      birthday: 'Joyeux anniversaire à ', mariage: 'Joyeux anniversaire de mariage', death: 'Nos sincères condoléances', other: '',
    };

    const iconMap: Record<string, string> = {
      birthday: '<i class="bi bi-gift-fill" style="font-size:20px;color:#fff"></i>',
      mariage: '<i class="bi bi-heart-fill" style="font-size:20px;color:#fff"></i>',
      death: '<i class="bi bi-flower1" style="font-size:20px;color:#fff"></i>',
      other: '<i class="bi bi-megaphone-fill" style="font-size:20px;color:#fff"></i>',
    };

    const result: Record<string, string> = {};

    await Promise.all(
      Object.keys(groups).map(async (type) => {
        const typeItems = groups[type];
        if (typeItems.length === 0) {
          result[type] = '<p class="text-center text-muted p-3">Aucune donnée disponible</p>';
          return;
        }
        const htmls = await Promise.all(
          typeItems.map(async (item: Record<string, unknown>) => {
            const img = await resolveImage(item, siteUrl, 'annonces', 'assets/imges/user-1.jpg');
            const name = String(item.Titre || item.Title || '');
            const greeting = greetingMap[type] || '';
            const greetingText = greeting ? greeting + ' ' + name : name;
            const dateVal = item.DateDeEvenement || '';
            let dateStr = '';
            if (dateVal) {
              const d = new Date(String(dateVal));
              dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' });
            }
            const likedBy = parseLikedBy(item.LikedBy);
            const comments = parseComments(item.Comments);
            const itemId = Number(item.Id);
            const lieu = item.Lieu ? String(item.Lieu) : '';
            const lieuHtml = lieu ? '<p style="font-size:12px;color:#999;margin:2px 0 0 0"><i class="bi bi-geo-alt"></i> ' + lieu + '</p>' : '';

            const typeIcon = iconMap[type] || iconMap.other;
            const socialHtml = buildSocialWidgetHtml({
              listName: 'annonces',
              itemId,
              likedBy,
              comments,
              currentUserEmail,
              currentUserDisplayName,
              variant: 'compact',
            });

            return `
              <div class="event-news">
                <a href="#page-detail-annonce&id=${itemId}" class="d-flex align-content-start gap-2 event-news-main">
                  <div class="img-box"><img src="${img}"></div>
                  <div class="event-text flex-grow-1">
                    <div class="d-flex gap-3 align-items-start">
                      <div class="annouce-icon">${typeIcon}</div>
                      <div>
                        <h3>${greetingText}</h3>
                        <p style="font-size:13px;color:#666;margin:4px 0 0 0"><i class="bi bi-calendar"></i> ${dateStr}</p>
                        ${lieuHtml}
                      </div>
                    </div>
                  </div>
                </a>
                <div class="event-news-social">
                  ${socialHtml}
                </div>
              </div>`;
          })
        );
        result[type] = htmls.join('');
      })
    );
    return result;
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Announcements load error:', err);
    return { birthday: '<p class="text-center text-muted p-3">Erreur de chargement</p>', mariage: '<p class="text-center text-muted p-3">Erreur de chargement</p>', death: '<p class="text-center text-muted p-3">Erreur de chargement</p>', other: '<p class="text-center text-muted p-3">Erreur de chargement</p>' };
  });
}

/* â”€â”€ Actualites du groupe â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadActualites(siteUrl: string): Promise<string> {
  return cacheFetchSmart('actualites-home', siteUrl, 'actualites', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('actualites')/items?$select=*&$top=50&$orderby=NewsDate desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui' || !a;
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucune actualité</p>';

    return items.map((item: Record<string, unknown>) => {
      const title = String(item.Titre || item.Title || '');
      const description = item.Description ? String(item.Description) : '';
      const descriptionText = item.DescriptionText ? String(item.DescriptionText) : '';
      const snippet = descriptionText || (description ? description.replace(/<[^>]*>/g, '').trim() : '');
      let dateStr = '';
      if (item.NewsDate) {
        const d = new Date(String(item.NewsDate));
        dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
      }
      const firstLetter = title ? title.charAt(0).toUpperCase() : 'A';

      return `
          <a href="#page-detail-actualite&id=${item.Id}" class="swiper-slide group-news-box group-news-link" style="text-decoration:none;color:inherit;">
            <div class="d-flex align-items-start gap-2">
              <div class="big-later">${firstLetter}</div>
              <div class="big-latter-border"></div>
              <div class="group-news-title">
                <p>${dateStr}</p>
                <h4>${title}</h4>
              </div>
            </div>
            <div class="event-detiles">
              ${snippet ? '<p class="description-body">' + snippet + '</p>' : ''}
              ${description ? '<div class="description-text">' + description + '</div>' : ''}
              <span class="btn-en-savoir-plus">En savoir plus</span>
            </div>
          </a>`;
    }).join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Actualités load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/* â”€â”€ Hero Slider â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadHeroSlider(siteUrl: string): Promise<string> {
  return cacheFetchSmart('hero-slider', siteUrl, 'actualites', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('actualites')/items?$select=*&$top=3&$orderby=NewsDate desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui' || !a;
    });
    if (items.length === 0) return '';

    const slides = await Promise.all(
      items.map(async (item: Record<string, unknown>) => {
        const img = await resolveImage(item, siteUrl, 'actualites', 'assets/imges/tabs-1.jpg');
        const descriptionText = item.DescriptionText ? String(item.DescriptionText) : '';
        const title = String(item.Titre || item.Title || '');
        const text = descriptionText || title;
        return `
              <div class="swiper-slide">
                <a href="#page-detail-actualite&id=${item.Id}" class="flex-grow-1 position-relative">
                  <img src="${img}" class="d-block">
                  <div class="image-overly"></div>
                  <div class="imagewithtext">
                    <h2>${text}</h2>
                  </div>
                </a>
              </div>`;
      })
    );
    return slides.join('');
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Hero slider load error:', err);
    return '';
  });
}

/* â”€â”€ Product Slides â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
export function loadProductSlides(siteUrl: string): Promise<{ slides: string; initSwiper: boolean }> {
  return cacheFetchSmart('product-slides', siteUrl, 'ProductSlides', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('ProductSlides')/items?$select=*&$top=4&$orderby=Modified desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui';
    });
    if (items.length === 0) return { slides: '', initSwiper: false };

    const slideData = await Promise.all(
      items.map(async (item: Record<string, unknown>) => {
        const img = await resolveImage(item, siteUrl, 'ProductSlides', 'assets/imges/tabs-21.jpg');
        const title = String(item.Titre || item.Title || '');
        const showTitle = item.ShowTitle;
        const showType = item.ShowProductType;
        const productType = String(item.ProductType || '');
        const titleHtml = showTitle === 'Yes' || showTitle === true ? '<h2>' + title + '</h2>' : '';
        const typeHtml = showType === 'Yes' || showType === true && productType ? '<p>' + productType + '</p>' : '<p>' + title + '</p>';
        return { imageUrl: img, titleHtml, typeHtml, itemId: item.Id };
      })
    );

    const vertSlides: string[] = [];
    for (let i = 0; i < slideData.length; i += 2) {
      const pair = slideData.slice(i, i + 2);
      let slidesHtml = '<div class="swiper-slide">';
      pair.forEach((data, j: number) => {
        slidesHtml += `
              <a href="#page-detail-produit&id=${data.itemId}" class="${j === 0 ? 'mb-2 ' : ''}position-relative small-image">
                <img src="${data.imageUrl}" class="img-fluid">
                <div class="image-overly"></div>
                <div class="small-imagewithtext">
                  ${data.typeHtml}
                  ${data.titleHtml}
                </div>
              </a>`;
      });
      slidesHtml += '</div>';
      vertSlides.push(slidesHtml);
    }
    return { slides: vertSlides.join(''), initSwiper: slideData.length > 0 };
  }, CACHE_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Product slides load error:', err);
    return { slides: '', initSwiper: false };
  });
}
