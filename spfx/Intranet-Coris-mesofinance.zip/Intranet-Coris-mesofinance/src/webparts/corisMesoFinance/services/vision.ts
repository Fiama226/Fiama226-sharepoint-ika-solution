﻿import { resolveImage } from './utils';
import { cacheFetchSmart } from './cache';

const VISION_CACHE_KEY = 'vision-html';
const VISION_TTL = 30 * 60 * 1000;

export function loadVision(siteUrl: string): Promise<string> {
  const fallbackImg = 'assets/imges/vision.png';

  return cacheFetchSmart(VISION_CACHE_KEY, siteUrl, 'Vision', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Vision')/items?$select=*&$top=10`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui';
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucune donnée</p>';

    const item = items[0];
    const title = String(item.Title || 'VISION');
    const description = String(item.Description || '');

    const imageUrl = await resolveImage(siteUrl, 'Vision', item, fallbackImg);
    return `
        <div class="col-md-12">
          <div style="text-align: center;">
            <img src="${imageUrl}" style="display: inline-block; margin: 0 auto; max-width: 700px; width: 100%;">
          </div>
        </div>
        <div class="col-md-12">
          <br><br><br>
          <div class="group-single-title mb-4">
            <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">${title}</h1>
            <ul>${description}</ul>
          </div>
        </div>`;
  }, VISION_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Vision load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}
