﻿import { resolveImage } from './utils';
import { cacheFetchSmart, cacheFetchSmartItem } from './cache';

const fallbackImg = 'assets/imges/event-1.jpg';
const CACHE_TTL = 5 * 60 * 1000;

/**
 * Charge tous les évènements (liste complète)
 */
export function loadEvenementsAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('evenements-all', siteUrl, 'Evenement', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Evenement')/items?$select=*&$orderby=EventDate desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui' || !a;
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun événement</p>';

    const cards = await Promise.all(
      items.map((item: Record<string, unknown>) =>
        resolveImage(siteUrl, 'Evenement', item, fallbackImg, 'Images').then((imageUrl) => {
          const title = String(item.Title || '');
          const eventText = item.EventText ? String(item.EventText) : '';
          const descriptionText = eventText.replace(/<[^>]*>/g, '');
          const snippet = descriptionText.length > 120
            ? descriptionText.substring(0, 120) + '…'
            : descriptionText;

          const eventDate = item.EventDate || '';
          const d = eventDate ? new Date(String(eventDate)) : new Date();
          const now = new Date();
          const diffMs = now.getTime() - d.getTime();
          const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
          let timeLabel: string;
          if (diffDays === 0) timeLabel = "Aujourd'hui";
          else if (diffDays === 1) timeLabel = 'Hier';
          else if (diffDays < 30) timeLabel = 'Il y a ' + diffDays + ' jours';
          else if (diffDays < 365) timeLabel = 'Il y a ' + Math.floor(diffDays / 30) + ' mois';
          else timeLabel = 'Il y a ' + Math.floor(diffDays / 365) + ' an' + (Math.floor(diffDays / 365) > 1 ? 's' : '');

          return `
              <div class="event-news">
                <a href="#page-detail-evenement&id=${item.Id}" class="d-flex align-content-start gap-2">
                  <div class="img-box"><img src="${imageUrl}"></div>
                  <div class="event-text">
                    <div><p>${title}</p></div>
                    <h3>${snippet}</h3>
                    <div class="mb-auto d-flex align-items-center gap-2">
                      <div class="event-time">
                        <i class="bi bi-clock-history"></i>
                        <span>${timeLabel}</span>
                      </div>
                    </div>
                  </div>
                </a>
              </div>`;
        })
      )
    );

    const left = cards.filter((_, i) => i % 2 === 0).join('');
    const right = cards.filter((_, i) => i % 2 === 1).join('');
    return `<div class="row">
      <div class="col-md-6">
        <div class="event-news-box">${left}</div>
      </div>
      <div class="col-md-6">
        <div class="event-news-box">${right}</div>
      </div>
    </div>`;
  }, CACHE_TTL).catch((err) => {
    console.error('[Evenements] load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/**
 * Charge le détail d'un évènement par son ID
 */
export function loadEvenementDetail(siteUrl: string, itemId: number): Promise<string> {
  return cacheFetchSmartItem(`detail-evenement-${itemId}`, siteUrl, 'Evenement', itemId, async () => {
    try {
      const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Evenement')/items(${itemId})`;
      const res = await fetch(listApiUrl, {
        headers: {
          Accept: 'application/json;odata=nometadata',
          'Content-Type': 'application/json;odata=nometadata',
        },
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`HTTP ${res.status}: ${t}`);
      }
      const item = await res.json();
      if (!item) return '<p class="text-center text-muted p-3">Évènement introuvable</p>';

      const title = String(item.Title || '');
      const eventText = item.EventText ? String(item.EventText) : '';

      let dateStr = '';
      if (item.EventDate) {
        const d = new Date(String(item.EventDate));
        dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
        const hours = d.getHours();
        const minutes = d.getMinutes();
        const hh = hours < 10 ? '0' + hours : '' + hours;
        const mm = minutes < 10 ? '0' + minutes : '' + minutes;
        dateStr += ' à  ' + hh + ':' + mm;
      }

      const imageUrl = await resolveImage(siteUrl, 'Evenement', item, fallbackImg, 'Images');
      return `
        <div class="row">
          <div class="col-md-12 text-center">
            ${imageUrl ? `<div class="text-center mb-4">
              <img src="${imageUrl}" class="img-fluid rounded" style="max-width:100%;max-height:450px;object-fit:cover;border-radius:8px;">
            </div>` : ''}
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${title}</h1>
            <p style="color: #888; font-size: 14px; margin-bottom: 20px; text-align:center;">
              <i class="bi bi-calendar"></i> ${dateStr}
            </p>
            ${eventText ? `<div style="font-size: 15px; line-height: 1.8; color: #444; max-width:800px; margin-left:auto; margin-right:auto; text-align:center;">${eventText}</div>` : ''}
            <div class="mt-4 text-center">
              <a href="#page-tous-les-evenements" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour aux évènements
              </a>
            </div>
          </div>
        </div>`;
    } catch (err) {
      console.error('[Evenements] detail load error:', err);
      return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
    }
  });
}
