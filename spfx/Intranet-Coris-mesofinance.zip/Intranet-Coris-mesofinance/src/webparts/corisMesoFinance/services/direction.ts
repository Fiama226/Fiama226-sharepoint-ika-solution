﻿import { resolveImage } from './utils';
import { cacheFetchSmart } from './cache';

const DIRECTION_CACHE_KEY = 'direction-html';
const DIRECTION_TTL = 30 * 60 * 1000;

export function loadDirection(siteUrl: string): Promise<string> {
  const fallbackImg = 'assets/imges/logo-holding.png';

  return cacheFetchSmart(DIRECTION_CACHE_KEY, siteUrl, 'Direction', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('Direction')/items?$select=*&$top=50`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []).filter((item: Record<string, unknown>) => {
      const a = item.Active;
      return a === true || a === 1 || a === 'Yes' || a === 'Oui';
    });
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucune direction</p>';

    const imagePromises = items.map((item: Record<string, unknown>) => resolveImage(siteUrl, 'Direction', item, fallbackImg));
    const imageUrls = await Promise.all(imagePromises);

    return items.map((item: Record<string, unknown>, index: number) => {
      const title = String(item.Title || '');
      const description = String(item.Description || '');
      const imageUrl = imageUrls[index];
      const collapseId = `collapseDir${index}`;
      const headingId = `headingDir${index}`;
      const isFirst = index === 0;

      return `
            <div class="accordion-item">
              <h2 class="accordion-header" id="${headingId}">
                <button class="accordion-button ${isFirst ? '' : 'collapsed'}" type="button" data-bs-target="#${collapseId}" aria-expanded="${isFirst ? 'true' : 'false'}" aria-controls="${collapseId}">
                  ${title}
                </button>
              </h2>
              <div id="${collapseId}" class="accordion-collapse collapse ${isFirst ? 'show' : ''}" aria-labelledby="${headingId}">
                <div class="accordion-body">
                  <div class="row">
                    <div class="col-md-2">
                      <img src="${imageUrl}" alt="${title}" class="img-fluid">
                    </div>
                    <div class="col-md-10">
                      ${description}
                    </div>
                  </div>
                </div>
              </div>
            </div>`;
    }).join('');
  }, DIRECTION_TTL).catch((err) => {
    console.error('[Coris Meso Finance] Direction load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}
