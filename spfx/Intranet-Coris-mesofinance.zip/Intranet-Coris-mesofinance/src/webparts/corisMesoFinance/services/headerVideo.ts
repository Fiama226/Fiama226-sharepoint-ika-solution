﻿import { cacheFetchSmart } from './cache';

const HEADER_VIDEO_CACHE_KEY = 'header-video';
const HEADER_VIDEO_TTL = 30 * 60 * 1000;

export async function loadHeaderVideo(siteUrl: string): Promise<string> {
  return cacheFetchSmart(HEADER_VIDEO_CACHE_KEY, siteUrl, 'HeaderVideo', async () => {
    const url = `${siteUrl}/_api/web/lists/getbytitle('HeaderVideo')/items?$select=Title,Active&$top=5`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata' },
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    const items: Array<Record<string, unknown>> = data.value || [];
    const active = items.find(
      (i) => i.Active === true || i.Active === 'Oui' || i.Active === 'Yes' || i.Active === 1
    );
    return active?.Title ? String(active.Title) : '';
  }, HEADER_VIDEO_TTL);
}

export function extractYouTubeId(url: string): string {
  if (!url) return '';
  const patterns = [
    /(?:youtube\.com\/watch\?v=)([^&]+)/,
    /(?:youtu\.be\/)([^?]+)/,
    /(?:youtube\.com\/embed\/)([^?]+)/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return '';
}
