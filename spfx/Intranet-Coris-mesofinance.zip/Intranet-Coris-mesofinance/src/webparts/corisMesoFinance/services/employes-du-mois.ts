﻿import { resolveImage } from './utils';
import { buildSocialWidgetHtml, parseComments, parseLikedBy, getLikedByFromItem } from './social';
import { cacheFetchSmart, cacheFetchSmartItem } from './cache';

const fallbackImg = '';
const CACHE_TTL = 5 * 60 * 1000;

/**
 * Charge tous les employés du mois (archive)
 */
export function loadEmployesDuMoisAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('employes-du-mois-all', siteUrl, 'EmployeDuMois', async () => {
    const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('EmployeDuMois')/items?$select=*&$orderby=Year desc,Month desc`;
    const res = await fetch(listApiUrl, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-Type': 'application/json;odata=nometadata',
      },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = data.value || [];
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun employé du mois</p>';

    const moisNoms: Record<string, string> = {
      '1': 'Janvier', '2': 'Février', '3': 'Mars', '4': 'Avril',
      '5': 'Mai', '6': 'Juin', '7': 'Juillet', '8': 'Août',
      '9': 'Septembre', '10': 'Octobre', '11': 'Novembre', '12': 'Décembre',
    };

    const cards = await Promise.all(
      items.map((item: Record<string, unknown>) =>
        resolveImage(siteUrl, 'EmployeDuMois', item, fallbackImg).then((imageUrl) => {
          const title = String(item.Title || '');
          const position = String(item.Position || '');
          const description = item.Description ? String(item.Description) : '';
          const month = String(item.Month || '');
          const year = String(item.Year || '');
          const monthName = moisNoms[month] || '';
          const period = monthName ? monthName + ' ' + year : year;

          const likedBy = getLikedByFromItem(item);
          const likeCount = likedBy.length;

          const imgHtml = imageUrl
            ? `<img src="${imageUrl}" alt="${title}">`
            : '<i class="bi bi-person-circle" style="font-size:48px;color:#004991;"></i>';

          return `
              <div class="event-news employe-mois-item">
                <a href="#page-detail-employe-du-mois&id=${item.Id}" class="d-flex align-content-start gap-2">
                  <div class="img-box employe-mois-img">${imgHtml}</div>
                  <div class="event-text d-flex flex-column justify-content-between flex-grow-1">
                    <div>
                      <div><p>${period}</p></div>
                      <h3>${title}</h3>
                      ${position ? `<div style="font-size:13px;color:#666;margin:4px 0 0 0"><i class="bi bi-briefcase"></i> ${position}</div>` : ''}
                      ${description ? `<div class="employe-mois-description">${description}</div>` : ''}
                    </div>
                    <div class="d-flex align-items-center gap-2 justify-content-end">
                      <div class="d-flex align-items-center like-btn">
                        <p>${likeCount}</p>
                        <button type="button"><i class="bi bi-hand-thumbs-up-fill"></i></button>
                      </div>
                    </div>
                  </div>
                </a>
              </div>`;
        })
      )
    );

    const left = cards.filter((_, i) => i % 2 === 0).join('');
    const right = cards.filter((_, i) => i % 2 === 1).join('');
    return `<div class="row">
          <div class="col-md-6">
            <div class="event-news-box all-employes-list">${left}</div>
          </div>
          <div class="col-md-6">
            <div class="event-news-box all-employes-list">${right}</div>
          </div>
        </div>`;
  }, CACHE_TTL).catch((err) => {
    console.error('[EmployesDuMois] load error:', err);
    return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
  });
}

/**
 * Charge le détail d'un employé du mois par son ID
 */
export function loadEmployeDuMoisDetail(
  siteUrl: string,
  itemId: number,
  currentUserEmail = '',
  currentUserDisplayName = ''
): Promise<string> {
  return cacheFetchSmartItem(`detail-employe-du-mois-${itemId}`, siteUrl, 'EmployeDuMois', itemId, async () => {
    try {
      const listApiUrl = `${siteUrl}/_api/web/lists/getbytitle('EmployeDuMois')/items(${itemId})`;
      const res = await fetch(listApiUrl, {
        headers: {
          Accept: 'application/json;odata=nometadata',
          'Content-Type': 'application/json;odata=nometadata',
        },
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`HTTP ${res.status}: ${t}`);
      }
      const item = await res.json();
      if (!item) return '<p class="text-center text-muted p-3">Employé introuvable</p>';

      const title = String(item.Title || '');
      const position = String(item.Position || '');
      const description = String(item.Description || '');
      const moisNoms: Record<string, string> = {
        '1': 'Janvier', '2': 'Février', '3': 'Mars', '4': 'Avril',
        '5': 'Mai', '6': 'Juin', '7': 'Juillet', '8': 'Août',
        '9': 'Septembre', '10': 'Octobre', '11': 'Novembre', '12': 'Décembre',
      };
      const month = String(item.Month || '');
      const year = String(item.Year || '');
      const monthName = moisNoms[month] || 'Mois inconnu';

      const likedBy = getLikedByFromItem(item);
      const comments = parseComments(item.Comments);
      const itemIdNum = Number(item.Id);

      const socialHtml = buildSocialWidgetHtml({
        listName: 'EmployeDuMois',
        itemId: itemIdNum,
        likedBy,
        comments,
        currentUserEmail,
        currentUserDisplayName,
      });

      const imageUrl = await resolveImage(siteUrl, 'EmployeDuMois', item, fallbackImg);
      const imgHtml = imageUrl
        ? '<img src="' + imageUrl + '" style="width:200px;height:200px;object-fit:cover;border-radius:8px;border:5px solid #004991;">'
        : '<i class="bi bi-person-circle" style="font-size:120px;color:#004991;"></i>';

      return `
        <div class="row">
          <div class="col-md-12 text-center">
            <div class="text-center mb-4">${imgHtml}</div>
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${title}</h1>
            ${position ? `<div style="text-align:center;font-size:16px;color:#666;font-weight:500;margin-bottom:8px;">${position}</div>` : ''}
            <p style="text-align:center;color:#888;font-size:14px;"><i class="bi bi-calendar"></i> ${monthName} ${year}</p>
            ${description ? `<div style="font-size: 15px; line-height: 1.8; color: #444; max-width:800px; margin-left:auto; margin-right:auto; text-align:center; margin-bottom:24px;">${description}</div>` : ''}

            ${socialHtml}

            <div class="mt-4 text-center">
              <a href="#page-tous-les-employes-du-mois" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour aux employés du mois
              </a>
            </div>
          </div>
        </div>`;
    } catch (err) {
      console.error('[EmployesDuMois] detail load error:', err);
      return '<p class="text-center text-muted p-3">Erreur de chargement</p>';
    }
  });
}
