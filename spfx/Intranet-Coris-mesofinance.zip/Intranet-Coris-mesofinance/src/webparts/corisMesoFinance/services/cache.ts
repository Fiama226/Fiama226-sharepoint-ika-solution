﻿interface CacheEntry<T> {
  data: T;
  timestamp: number;
  modified?: string;
  itemCount?: number;
}

const STORE_KEY = 'coris-holding-cache';
const store = new Map<string, CacheEntry<unknown>>();

function persistStore(): void {
  try {
    const entries: Record<string, CacheEntry<unknown>> = {};
    store.forEach((v, k) => { entries[k] = v; });
    sessionStorage.setItem(STORE_KEY, JSON.stringify(entries));
  } catch { }
}

function restoreStore(): void {
  try {
    const raw = sessionStorage.getItem(STORE_KEY);
    if (!raw) return;
    const entries = JSON.parse(raw) as Record<string, CacheEntry<unknown>>;
    Object.keys(entries).forEach((k) => store.set(k, entries[k]));
  } catch { }
}

restoreStore();

export function cacheInvalidate(key: string): void {
  store.delete(key);
  persistStore();
}

export function cacheClear(): void {
  store.clear();
  persistStore();
}

export function cacheGet<T>(key: string): T | undefined {
  const entry = store.get(key) as CacheEntry<T> | undefined;
  if (entry) {
    return entry.data;
  }
  return undefined;
}

async function getLatestModified(siteUrl: string, listName: string): Promise<string | null> {
  try {
    const url = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Modified&$top=1&$orderby=Modified desc`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata' },
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.value?.[0]?.Modified ?? null;
  } catch {
    return null;
  }
}

async function getItemCount(siteUrl: string, listName: string): Promise<number | null> {
  try {
    const url = `${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ItemCount`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata' },
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.ItemCount ?? null;
  } catch {
    return null;
  }
}

async function getItemModified(siteUrl: string, listName: string, itemId: number): Promise<string | null> {
  try {
    const url = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${itemId})?$select=Modified`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata' },
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.Modified ?? null;
  } catch {
    return null;
  }
}

export async function cacheFetchSmartItem<T>(
  key: string,
  siteUrl: string,
  listName: string,
  itemId: number,
  fetcher: () => Promise<T>,
  ttl: number = 5 * 60 * 1000
): Promise<T> {
  const entry = store.get(key) as CacheEntry<T> | undefined;
  const now = Date.now();

  if (entry && now - entry.timestamp < ttl) {
    const latestModified = await getItemModified(siteUrl, listName, itemId);
    if (latestModified === null || (entry.modified && latestModified === entry.modified)) {
      return entry.data;
    }
  }

  const [data, modified] = await Promise.all([
    fetcher(),
    getItemModified(siteUrl, listName, itemId),
  ]);

  store.set(key, {
    data,
    timestamp: Date.now(),
    modified: modified ?? undefined,
  });
  persistStore();

  return data;
}

export async function cacheFetchSmart<T>(
  key: string,
  siteUrl: string,
  listName: string,
  fetcher: () => Promise<T>,
  ttl: number = 5 * 60 * 1000
): Promise<T> {
  const entry = store.get(key) as CacheEntry<T> | undefined;
  const now = Date.now();

  if (entry && now - entry.timestamp < ttl) {
    const [latestModified, latestCount] = await Promise.all([
      getLatestModified(siteUrl, listName),
      getItemCount(siteUrl, listName),
    ]);

    if (latestModified === null || latestCount === null) {
      return entry.data;
    }

    const modifiedMatch = entry.modified && latestModified === entry.modified;
    const countMatch = entry.itemCount !== undefined && latestCount === entry.itemCount;

    if (modifiedMatch && countMatch) {
      return entry.data;
    }
  }

  const [data, modified, itemCount] = await Promise.all([
    fetcher(),
    getLatestModified(siteUrl, listName),
    getItemCount(siteUrl, listName),
  ]);

  store.set(key, {
    data,
    timestamp: Date.now(),
    modified: modified ?? undefined,
    itemCount: itemCount ?? undefined,
  });
  persistStore();

  return data;
}
