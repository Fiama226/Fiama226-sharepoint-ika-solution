import { cacheFetchSmart, cacheFetchSmartItem } from './cache';

const LIST_NAME = "Partenariats";
const CACHE_TTL = 5 * 60 * 1000;

export function loadPartenariatsAll(siteUrl: string): Promise<string> {
  return cacheFetchSmart('partenariats-all', siteUrl, LIST_NAME, async () => {
    const url = `${siteUrl}/_api/web/lists/getbytitle('${LIST_NAME}')/items?$select=*&$orderby=Modified desc`;
    const res = await fetch(url, {
      headers: { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata' },
    });
    if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
    const data = await res.json();
    const items = (data.value || []) as Record<string, unknown>[];
    if (items.length === 0) return '<p class="text-center text-muted p-3">Aucun partenariat disponible</p>';

    const cards = items.map((item) => {
      const title = String(item.Title || '');
      const desc = item.Description ? String(item.Description) : '';
      const descText = desc.replace(/<[^>]*>/g, '');
      const snippet = descText.length > 200 ? descText.substring(0, 200) + '...' : descText;

      return `
        <div class="col-12 mb-3">
          <div style="border:1px solid #e0e0e0;border-radius:8px;background:#fff;display:flex;flex-direction:row;align-items:center;width:100%;padding:16px 20px;transition:box-shadow 0.2s;" onmouseover="this.style.boxShadow='0 2px 12px rgba(0,73,145,0.10)'" onmouseout="this.style.boxShadow='none'">
            <div style="width:50px;height:50px;min-width:50px;border-radius:50%;background:#004991;color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:bold;margin-right:20px;">${title.charAt(0).toUpperCase()}</div>
            <div style="display:flex;flex-direction:column;justify-content:center;flex:1;">
              <h5 style="color:#004991;font-weight:600;font-size:16px;margin:0 0 6px 0;">${title}</h5>
              ${snippet ? `<p style="color:#555;font-size:13px;line-height:1.6;margin:0 0 10px 0;">${snippet}</p>` : ''}
              <a href="#page-detail-partenariat&id=${item.Id}" style="display:inline-block;background:#004991;color:#fff;padding:7px 18px;border-radius:4px;text-decoration:none;font-size:13px;font-weight:500;text-align:center;align-self:flex-start;">
                En savoir plus <i class="bi bi-arrow-right" style="margin-left:4px;"></i>
              </a>
            </div>
          </div>
        </div>`;
    });
    return '<div class="row">' + cards.join('') + '</div>';
  }, CACHE_TTL).catch(() => '<p class="text-center text-muted p-3">Erreur de chargement</p>');
}

export function loadPartenariatDetail(siteUrl: string, itemId: number): Promise<string> {
  return cacheFetchSmartItem(`partenariat-detail-${itemId}`, siteUrl, LIST_NAME, itemId, async () => {
    try {
      const url = `${siteUrl}/_api/web/lists/getbytitle('${LIST_NAME}')/items(${itemId})`;
      const res = await fetch(url, {
        headers: { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata' },
      });
      if (!res.ok) { const t = await res.text(); throw new Error(`HTTP ${res.status}: ${t}`); }
      const item = await res.json() as Record<string, unknown>;
      if (!item) return '<p class="text-center text-muted p-3">Partenariat introuvable</p>';

      const title = String(item.Title || '');
      const description = item.Description ? String(item.Description) : '';

      return `
        <div class="row">
          <div class="col-md-12">
            <h1 style="color: #E40E20; font-weight: bold; text-align:center;">${title}</h1>
            ${description ? `<div style="font-size: 15px; line-height: 1.8; color: #444; margin-top:20px; max-width:800px; margin-left:auto; margin-right:auto;">${description}</div>` : ''}
            <div class="mt-4 text-center">
              <a href="#page-partenariats" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Retour aux partenariats
              </a>
            </div>
          </div>
        </div>`;
    } catch { return '<p class="text-center text-muted p-3">Erreur de chargement</p>'; }
  });
}
