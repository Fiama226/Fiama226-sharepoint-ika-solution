import { SIDEBAR_HTML } from '../components/Sidebar';

export const POLE_MESO_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="row">
                            <div class="col-md-4">
                                <div>
                                    <img src="assets/imges/corismeso.png" class="img-fluid" style="max-width: 800px; width: 100%;">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="group-single-title mb-4">
                                    <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">BANQUE</h1>
                                    <h3 style="margin-left: 20px;">MESO FINANCE</h3>
                                    <ul>La Méso Finance, chaînon manquant entre la Micro Finance représentée au sens strict par les Institutions de Micro Finance (IMF) et la Finance Classique des banques a pour ambition d'accompagner les entreprises qui sont devenues trop grandes pour continuer d'être financées par les structures de micro finance et dont leurs tailles ne leur permettent pas d'être accompagnées par les banques. Il s'agit d'une niche composée de Très Petites et Moyennes Entreprises TPME et d'informels qui ont cependant besoin de trouver des financements adaptés à  leur cycle de croissance à  des conditions souples et bien étudiées. Cette niche représente un grand pan de l'économie malheureusement pas assez soutenu du fait de plusieurs contraintes liées notamment à  la faiblesse des structures organisationnelles, l'absence ou l'insuffisance d'informations financières fiables et exploitables, l'absence de garanties et la faiblesse des capacités managériales. Le Groupe Coris à  travers cette finance inclusive veut se positionner sur cette cible d'avenir comme accélérateur de croissance de l'économie des pays de la sous-région avec une stratégie de développement bien définie.</ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('pm')}
            </div>
        </div>
    </div>
</section>

`;
