import { SIDEBAR_HTML } from '../components/Sidebar';

export const POLE_BARAKA_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="row">
                            <div class="col-md-4">
                                <div>
                                    <img src="assets/imges/logo_CBI_BARAKA-scaled.jpg" class="img-fluid" style="max-width: 800px; width: 100%;">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="group-single-title mb-4">
                                    <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">BANQUE</h1>
                                    <h3 style="margin-left: 20px;">Finance Islamique (Coris Bank International Baraka)</h3>
                                    <ul>Une branche Islamique est une partie de l'institution financière conventionnelle fournissant des prestations de gestion des fonds et des activités de financement et d'investissement en conformité avec les principes et règles de la Finance Islamique. C'est cette voix que Coris Bank International a décidé de suivre par la mise en place d'une entité dédiée dénommée Coris Bank International BARAKA.</ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('pba')}
            </div>
        </div>
    </div>
</section>

`;
