import { SIDEBAR_HTML } from '../components/Sidebar';

export const TOUTES_LES_ANNONCES_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="box-title mb-3">
                            <h4 style="color:#004991;font-weight:bold;font-size:22px;">Toutes les annonces</h4>
                            <div class="title-border"></div>
                        </div>
                        <div class="annonces">
                        <ul class="tabs" id="annonces-tabs">
                            <li class="tab-link current" data-tab="birthday">Anniversaires</li>
                            <li class="tab-link" data-tab="mariage">Mariages</li>
                            <li class="tab-link" data-tab="death">Nécrologie</li>
                            <li class="tab-link" data-tab="other">Autre</li>
                        </ul>
                        <div id="birthday" class="tab-content current">
                            <div class="annonces-box all-annonces-list" id="annonces-all-birthday">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div id="mariage" class="tab-content">
                            <div class="annonces-box all-annonces-list" id="annonces-all-mariage">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div id="death" class="tab-content">
                            <div class="annonces-box all-annonces-list" id="annonces-all-death">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div id="other" class="tab-content">
                            <div class="annonces-box all-annonces-list" id="annonces-all-other">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('tann')}
            </div>
        </div>
    </div>
</section>

`;
