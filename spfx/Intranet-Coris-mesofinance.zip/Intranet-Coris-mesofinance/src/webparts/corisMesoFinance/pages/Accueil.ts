
export const ACCUEIL_HTML = `

    <section class="mt-3">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-9 col-md-12">
                    <div class="row">
                        <div class="col-lg-8 pe-0">
                            <div class="swiper VisionSwiper full-imagewithtext">
                                <div class="swiper-wrapper" id="hero-slider-items">
                                    <div class="swiper-slide">
                                        <div class="d-block" style="height:511px;background:#004991;display:flex;align-items:center;justify-content:center">
                                            <div class="skeleton skeleton-circle" style="width:48px;height:48px;background:rgba(255,255,255,0.2)"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="swiper verticalSwiper" style="height:511px;">
                                <div class="swiper-wrapper" id="hero-vertical-items">
                                    <div class="swiper-slide">
                                        <div style="height:255px;background:#f0f0f0;display:flex;align-items:center;justify-content:center">
                                            <div class="skeleton" style="width:40px;height:40px;border-radius:50%"></div>
                                        </div>
                                        <div style="height:255px;background:#f0f0f0;display:flex;align-items:center;justify-content:center">
                                            <div class="skeleton" style="width:40px;height:40px;border-radius:50%"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-12">
                    <div class="agencies-box">
                        <div class="box-title">
                            <h4><a href="#page-tous-les-evenements" class="actualites-link">Evènements</a></h4>
                            <div class="title-border"></div>
                        </div>
                        <div class="event-news-box" id="evenements-items">
                            <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                        </div>
                        <div class="view-all-link">
                            <a href="#page-tous-les-evenements">Voir plus</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="mt-4">
        <div class="container-fluid ">
            <div class="row ">
                <div class="col-lg-9 col-md-12">
                    <div class="agencies-box position-relative">
                        <div class="box-title mb-3">
                            <h4><a href="#page-toutes-les-actualites" class="actualites-link">Actualités du groupe</a></h4>
                            <div class="title-border"></div>
                        </div>
                        <div class="swiper group-news">
                            <div class="swiper-wrapper" id="actualites-items">
                                <div class="swiper-slide">
                                    <div class="p-3" style="min-height:300px;background:#f8f9fa;border-radius:8px;display:flex;align-items:center;justify-content:center">
                                        <div style="text-align:center">
                                            <div class="skeleton skeleton-line" style="width:200px;margin-bottom:12px"></div>
                                            <div class="skeleton skeleton-line-sm" style="width:140px;margin:0 auto 8px"></div>
                                            <div class="skeleton skeleton-line-sm" style="width:120px;margin:0 auto"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        <div class="view-all-link">
                            <a href="#page-toutes-les-actualites">Voir tout</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-12">
                    <div class="agencies-box annonces">
                        <div class="box-title">
                            <h4><a href="#page-toutes-les-annonces" class="actualites-link">Annonces</a></h4>
                            <div class="title-border"></div>
                        </div>
                        <ul class="tabs">
                            <li class="tab-link current" data-tab="birthday">Anniversaires</li>
                            <li class="tab-link" data-tab="mariage">Mariages</li>
                            <li class="tab-link" data-tab="death">Nécrologie</li>
                            <li class="tab-link" data-tab="other">Autre</li>
                        </ul>
                        <div id="birthday" class="tab-content current">
                            <div class="annonces-box" id="annonces-birthday">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div id="mariage" class="tab-content">
                            <div class="annonces-box" id="annonces-mariage">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div id="death" class="tab-content">
                            <div class="annonces-box" id="annonces-death">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div id="other" class="tab-content">
                            <div class="annonces-box" id="annonces-other">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div class="view-all-link">
                            <a href="#page-toutes-les-annonces">Voir tout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="mt-4">
        <div class="container-fluid ">
            <div class="row equal-height-row">
                <div class="col-lg-3 col-md-6 d-flex flex-column">
                    <div class="agencies-box flex-grow-1">
                        <div class="box-title">
                            <h4>Nouveau collaborateur</h4>
                            <div class="title-border"></div>
                        </div>
                        <div class="staff-director-box" id="collaborateurs-items">
                            <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex flex-column">
                    <div class="agencies-box flex-grow-1">
                        <div class="box-title">
                            <h4><a href="#page-tout-agenda" class="actualites-link">Agenda</a></h4>
                            <div class="title-border"></div>
                        </div>
                        <div class="meeting-agendas" id="agenda-items">
                            <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex flex-column">
                    <div class="usefulinfo mb-3" id="employe-mois" style="flex-shrink:0;">
                        <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                    </div>
                    <div class="agencies-box quiz-box flex-grow-1">
                        <div class="box-title">
                            <h4><a href="#page-tous-les-quiz" class="actualites-link">Sondage/Quiz</a></h4>
                            <div class="title-border"></div>
                        </div>
                        <div id="survey-items" class="p-2">
                            <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 d-flex flex-column">
                    <div class="agencies-box mb-3" style="flex-shrink:0;">
                        <div class="box-title">
                            <h4>Outils</h4>
                            <div class="title-border"></div>
                        </div>
                        <div class="d-flex align-items-center gap-3 flex-wrap" id="outils-items">
                            <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                        </div>
                    </div>
                    <div class="agencies-box annonces flex-grow-1">
                        <div class="box-title">
                            <h4>Informations financieres</h4>
                            <div class="title-border"></div>
                        </div>
                        <ul class="tabs">
                            <li class="tab-link current" data-tab="bourse">Transfert</li>
                            <li class="tab-link" data-tab="device">Cash</li>
                        </ul>
                        <div id="bourse" class="tab-content current">
                            <div id="transfert-items">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                        <div id="device" class="tab-content">
                            <div id="cash-items">
                                <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Modal Profil Collaborateur (Nouveau) -->
    <div class="modal fade" id="collabProfileModal" tabindex="-1" aria-labelledby="collabProfileModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content collab-modal-content">
                <button type="button" class="btn-close collab-modal-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-body collab-modal-body">
                    <div class="row align-items-start">
                        <div class="col-md-4 text-center mb-3 mb-md-0">
                            <div class="collab-modal-avatar-wrap">
                                <img id="collab-modal-img" src="" class="collab-modal-avatar" alt="" style="display:none;">
                                <div id="collab-modal-img-fallback" class="collab-modal-avatar-fallback"><i class="bi bi-person-circle" style="font-size:60px;color:#004991"></i></div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <h4 id="collab-modal-name" class="collab-modal-name"></h4>
                            <p id="collab-modal-position" class="collab-modal-position"></p>
                            <div class="collab-modal-icons mb-3">
                                <a id="collab-modal-chat" href="#" class="collab-modal-icon-link"><i class="bi bi-chat-dots-fill"></i></a>
                                <a id="collab-modal-email-link" href="#" class="collab-modal-icon-link"><i class="bi bi-envelope-fill"></i></a>
                                <a id="collab-modal-phone-link" href="#" class="collab-modal-icon-link"><i class="bi bi-telephone-fill"></i></a>
                            </div>
                            <hr class="collab-modal-divider">
                            <div class="row collab-modal-details">
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-envelope"></i> Email</span>
                                    <p id="collab-modal-email" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-chat-dots-fill"></i> Chat</span>
                                    <p id="collab-modal-chat-val" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-telephone"></i> Mobile</span>
                                    <p id="collab-modal-phone" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-geo-alt"></i> Division</span>
                                    <p id="collab-modal-division" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-person-badge"></i> Job Title</span>
                                    <p id="collab-modal-jobtitle" class="collab-modal-detail-value"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Détails Collaborateur (Tableau) -->
    <div class="modal fade" id="collabDetailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content collab-modal-content">
                <button type="button" class="btn-close collab-modal-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-body collab-modal-body">
                    <div class="row align-items-start">
                        <div class="col-md-4 text-center mb-3 mb-md-0">
                            <div class="collab-modal-avatar-wrap">
                                <img id="collab-detail-img" src="" class="collab-modal-avatar" alt="" style="display:none;">
                                <div id="collab-detail-img-fallback" class="collab-modal-avatar-fallback"><i class="bi bi-person-circle" style="font-size:60px;color:#004991"></i></div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <h4 id="collab-detail-name" class="collab-modal-name"></h4>
                            <p id="collab-detail-jobtitle" class="collab-modal-position"></p>
                            <div class="collab-modal-icons mb-3">
                                <a id="detail-chat" href="#" class="collab-modal-icon-link"><i class="bi bi-chat-dots-fill"></i></a>
                                <a id="detail-email-link" href="#" class="collab-modal-icon-link"><i class="bi bi-envelope-fill"></i></a>
                                <a id="detail-phone-link" href="#" class="collab-modal-icon-link"><i class="bi bi-telephone-fill"></i></a>
                            </div>
                            <hr class="collab-modal-divider">
                            <div class="row collab-modal-details">
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-envelope"></i> Email</span>
                                    <p id="detail-mail" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-telephone"></i> Téléphone</span>
                                    <p id="detail-business-phones" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-phone"></i> Mobile</span>
                                    <p id="detail-mobile" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-building"></i> Département</span>
                                    <p id="detail-department" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-geo-alt"></i> Bureau</span>
                                    <p id="detail-office" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-globe"></i> Pays</span>
                                    <p id="detail-country" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-person-badge"></i> Prénom</span>
                                    <p id="detail-given" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-person"></i> Nom</span>
                                    <p id="detail-surname" class="collab-modal-detail-value"></p>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <span class="collab-modal-detail-label"><i class="bi bi-pin-map"></i> Filiale</span>
                                    <p id="detail-filiale" class="collab-modal-detail-value"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="mt-4">
        <div class="container-fluid ">
            <div class="row">
                <div class="col-lg-9 col-md-12">
                    <div class="agencies-box" style="height: 100%;">
                        <div class="box-title">
                            <h4><a href="#page-trombinoscope" class="box-title-link">Collaborateurs</a></h4>
                            <div class="title-border"></div>
                        </div>
                        <div class="collaborateurs-form">
                            <form class="row" onsubmit="return false;">
                                <div class="col-md-3 col-12 d-flex align-items-center gap-2 mb-2">
                                    <label class="form-label">Nom</label>
                                    <input type="text" class="form-control" id="collab-filter-nom" placeholder="Rechercher...">
                                </div>
                                <div class="col-md-3 col-12 d-flex align-items-center gap-2 mb-2">
                                    <label class="form-label">Direction</label>
                                    <select class="form-select" id="collab-filter-dept">
                                        <option value="">Toutes</option>
                                    </select>
                                </div>
                                <div class="col-md-2 col-12 d-flex align-items-center gap-2 mb-2">
                                    <button type="button" class="btn btn-secondary" id="collab-search-btn">Recherche</button>
                                    <span id="collab-count" class="text-muted ms-2 d-flex align-items-center" style="font-size:12px;white-space:nowrap"></span>
                                </div>
                            </form>
                        </div>
                        <div class="collaborateurs-box">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Image</th>
                                        <th scope="col">D'abord</th>
                                        <th scope="col">Dernière</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Titre</th>
                                        <th scope="col">Département</th>
                                        <th scope="col">Bureau</th>
                                        <th scope="col">Poste IP</th>
                                        <th scope="col">Téléphone</th>
                                    </tr>
                                </thead>
                                <tbody id="collaborateurs-tbody">
                                    <tr><td colspan="9" class="p-3">
                              <div class="skeleton-table-row"><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div></div>
                              <div class="skeleton-table-row"><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div></div>
                              <div class="skeleton-table-row"><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div><div class="skeleton skeleton-table-cell"></div></div>
                            </td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="agencies-box">
                                <div class="box-title">
                                    <h4>Galerie</h4>
                                    <div class="title-border"></div>
                                </div>
                                <div class="galerie-folders" id="galerie-folders">
                                    <div class="p-3">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                              </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <div class="coris-gallery-modal" id="galerie-modal" aria-hidden="true">
        <button type="button" class="coris-gallery-close" id="galerie-close" aria-label="Fermer"><i class="bi bi-x-lg"></i></button>
        <button type="button" class="coris-gallery-nav coris-gallery-prev" id="galerie-prev" aria-label="Image précédente"><i class="bi bi-chevron-left"></i></button>
        <div class="coris-gallery-stage">
            <div class="coris-gallery-loading" id="galerie-loading" style="display:none"><div class="skeleton-card"><div class="skeleton skeleton-circle"></div><div class="skeleton-card-body"><div class="skeleton skeleton-line"></div><div class="skeleton skeleton-line-sm"></div></div></div></div>
            <img id="galerie-modal-img" src="" alt="">
            <div class="coris-gallery-caption">
                <h5 id="galerie-modal-title"></h5>
                <p id="galerie-modal-description"></p>
                <span id="galerie-modal-counter"></span>
            </div>
        </div>
        <button type="button" class="coris-gallery-nav coris-gallery-next" id="galerie-next" aria-label="Image suivante"><i class="bi bi-chevron-right"></i></button>
    </div>
    <style>
      .galerie-folders {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 16px 18px;
      }
      .galerie-folder {
        appearance: none;
        background: transparent;
        border: 0;
        color: #003b73;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
        min-width: 0;
        padding: 0;
        text-align: left;
      }
      .galerie-folder-icon {
        color: #ffc94d;
        filter: drop-shadow(0 2px 0 #111);
        font-size: 72px;
        line-height: 1;
      }
      .galerie-folder-title {
        color: #003b73;
        font-size: 12px;
        line-height: 1.25;
        max-width: 100%;
        overflow-wrap: anywhere;
      }
      .galerie-folder-count {
        color: #777;
        font-size: 11px;
      }
      .coris-gallery-modal {
        align-items: center;
        background: rgba(0, 0, 0, 0.78);
        display: none;
        inset: 0;
        justify-content: center;
        padding: 42px 72px;
        position: fixed;
        z-index: 99999;
      }
      .coris-gallery-modal.is-open {
        display: flex;
      }
      .coris-gallery-stage {
        align-items: center;
        display: flex;
        justify-content: center;
        max-height: calc(100vh - 84px);
        max-width: calc(100vw - 144px);
        min-height: 260px;
        min-width: 320px;
        position: relative;
      }
      .coris-gallery-stage img {
        display: none;
        max-height: calc(100vh - 84px);
        max-width: calc(100vw - 144px);
        object-fit: contain;
      }
      .coris-gallery-stage.has-image img {
        display: block;
      }
      .coris-gallery-loading {
        color: #fff;
        font-size: 14px;
      }
      .coris-gallery-stage.has-image .coris-gallery-loading {
        display: none;
      }
      .coris-gallery-close,
      .coris-gallery-nav {
        align-items: center;
        background: rgba(0, 0, 0, 0.35);
        border: 0;
        color: #fff;
        display: flex;
        justify-content: center;
        position: fixed;
      }
      .coris-gallery-close {
        height: 42px;
        right: 20px;
        top: 16px;
        width: 42px;
      }
      .coris-gallery-nav {
        height: 62px;
        top: 50%;
        transform: translateY(-50%);
        width: 54px;
      }
      .coris-gallery-prev { left: 0; }
      .coris-gallery-next { right: 0; }
      .coris-gallery-caption {
        background: linear-gradient(transparent, rgba(0, 0, 0, 0.72));
        bottom: 0;
        color: #fff;
        left: 0;
        padding: 48px 18px 14px;
        position: absolute;
        right: 0;
      }
      .coris-gallery-caption h5 {
        font-size: 15px;
        margin: 0 0 4px;
      }
      .coris-gallery-caption p,
      .coris-gallery-caption span {
        font-size: 12px;
        margin: 0;
      }
      .quiz-box .title-border { background-color: #E40E20 !important; }
      .quiz-box .survey-item-icon { background-color: #E40E20 !important; }
      .quiz-box .survey-item:hover,
      .quiz-box .survey-item:hover h6,
      .quiz-box .survey-item:hover .survey-item-arrow,
      .quiz-box .survey-item:hover .survey-item-description { color: #E40E20 !important; }
      .survey-home-item:hover { background-color: #f5f9ff !important; }
      .survey-home-item:hover,
      .survey-home-item:hover span { color: #E40E20 !important; }
      @media (max-width: 991px) {
        .galerie-folders { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      }
      @media (max-width: 575px) {
        .galerie-folders { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .galerie-folder-icon { font-size: 56px; }
        .coris-gallery-modal { padding: 54px 42px; }
        .coris-gallery-stage,
        .coris-gallery-stage img {
          max-height: calc(100vh - 108px);
          max-width: calc(100vw - 84px);
        }
      }
    </style>

`;
