import { SIDEBAR_HTML } from '../components/Sidebar';

export const TOUS_LES_EMPLOYES_DU_MOIS_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-employes-box">
                    <div class="group-single">
                        <div class="box-title mb-3">
                            <h4 style="color:#004991;font-weight:bold;font-size:22px;">Employés du mois</h4>
                            <div class="title-border"></div>
                        </div>
                        <div id="employes-mois-all-items">
                            <div class="p-5">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('tem')}
            </div>
        </div>
    </div>
</section>

`;
