import { SIDEBAR_HTML } from '../components/Sidebar';

export const POLE_BANQUE_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="row">
                            <div class="col-md-4">
                                <div>
                                    <img src="assets/imges/logo-holding.png" class="img-fluid" style="max-width: 800px; width: 100%;">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="group-single-title mb-4">
                                    <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">BANQUE</h1>
                                    <h3 style="margin-left: 20px;">Banque Conventionnelle (Coris Bank International)</h3>
                                    <ul>Coris Bank International (CBI) est une banque commerciale à  vision panafricaine. Depuis sa création en 2008, CBI ambitionne d'être la banque de référence en Afrique. Servir et donner satisfaction à  ses clients et partenaires, faire la banque autrement, tel est son leitmotiv. Aujourd'hui, CBI compte à  son actif neuf (9) filiales et succursales au Burkina Faso, en Côte d'Ivoire, au Mali, au Togo, au Sénégal, au Bénin, au Niger, en Guinée et en Guinée Bissau.</ul>
                                    <ul>Son portefeuille électronique Coris Money se déploie également suivant le développement de son réseau bancaire dans les pays d'Afrique.</ul>
                                    <ul>Coris Bank International nourrit par de fortes ambitions panafricaines, a bâti son levier stratégique de développement autour d'un modèle industriel unique et adapté aux spécificités de ses zones de présence. L'excellence et l'innovation sont les critères prépondérants de son business model répondant parfaitement aux attentes de la clientèle.</ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('pb')}
            </div>
        </div>
    </div>
</section>

`;
