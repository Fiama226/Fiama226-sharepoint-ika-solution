import { SIDEBAR_HTML } from '../components/Sidebar';

export const RESEAU_AGENCES_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="box-title mb-3">
                            <h4 style="color:#004991;font-weight:bold;font-size:22px;">Réseau d'Agences et GAB</h4>
                            <div class="title-border"></div>
                        </div>
                        <div id="reseau-agences-all-items">
                            <div class="p-5">
                                <div class="skeleton skeleton-line"></div>
                                <div class="skeleton skeleton-line-sm" style="width:60%;margin:0 auto"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('ra')}
            </div>
        </div>
    </div>
</section>

`;
