import { SIDEBAR_HTML } from '../components/Sidebar';

export const VISION_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="row" id="vision-content">
                            <div class="col-md-12 text-center p-3">
                                <div class="skeleton-card">
                                  <div class="skeleton skeleton-circle"></div>
                                  <div class="skeleton-card-body">
                                    <div class="skeleton skeleton-line"></div>
                                    <div class="skeleton skeleton-line-sm"></div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('vis')}
            </div>
        </div>
    </div>
</section>

`;
