import { SIDEBAR_HTML } from '../components/Sidebar';

export const AGENDA_PERSONNEL_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box" style="min-height: 500px; display: flex; align-items: center; justify-content: center; background: #fff; border-radius: 8px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05); padding: 40px;">
                    <div class="text-center" style="max-width: 550px;">
                        <div style="font-size: 64px; color: #004991; margin-bottom: 20px; animation: pulse 2s infinite;">
                            <i class="bi bi-calendar3"></i>
                        </div>
                        <h2 style="color: #004991; font-weight: 700; margin-bottom: 15px;">Ouverture de votre Agenda Personnel</h2>
                        <p style="color: #666; font-size: 15px; line-height: 1.6; margin-bottom: 30px;">
                            Nous tentons d'ouvrir votre calendrier Microsoft Teams. Si l'application ou le calendrier Web ne s'est pas ouvert automatiquement, veuillez utiliser l'un des boutons ci-dessous.
                        </p>
                        <div class="d-flex flex-column gap-3 align-items-center">
                            <a id="btn-open-teams-web" href="https://teams.microsoft.com/v2/#/calendarv2" target="_blank" rel="noopener noreferrer" class="btn" style="background-color: #E40E20; color: #fff; font-weight: 600; padding: 12px 30px; border-radius: 6px; border: none; font-size: 16px; transition: all 0.3s; box-shadow: 0 4px 10px rgba(228, 14, 32, 0.2); width: 100%; max-width: 350px;">
                                <i class="bi bi-microsoft-teams me-2"></i> Ouvrir le calendrier Teams (Web)
                            </a>
                            <button id="btn-open-teams-app" class="btn btn-outline-secondary" style="font-weight: 600; padding: 10px 20px; border-radius: 6px; font-size: 14px; transition: all 0.3s; width: 100%; max-width: 350px;">
                                <i class="bi bi-laptop me-2"></i> Ouvrir avec l'application Teams
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('ap')}
            </div>
        </div>
    </div>
</section>


<style>
@keyframes pulse {
    0% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.05); opacity: 0.8; }
    100% { transform: scale(1); opacity: 1; }
}
#btn-open-teams-web:hover {
    background-color: #c30c1b !important;
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(228, 14, 32, 0.3) !important;
}
#btn-open-teams-app:hover {
    background-color: #f8f9fa !important;
    transform: translateY(-2px);
}
</style>
`;
