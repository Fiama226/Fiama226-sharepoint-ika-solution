import { SIDEBAR_HTML } from '../components/Sidebar';

export const DETAIL_ACTUALITE_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row detail-page-row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="row" id="detail-actualite-content">
                            <div class="col-md-12 text-center p-5">
                                <div class="skeleton-card">
                                  <div class="skeleton skeleton-circle"></div>
                                  <div class="skeleton-card-body">
                                    <div class="skeleton skeleton-line"></div>
                                    <div class="skeleton skeleton-line-sm"></div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                <div class="detail-sidebar">
                ${SIDEBAR_HTML('da')}
                </div>
            </div>
        </div>
    </div>
</section>

`;
