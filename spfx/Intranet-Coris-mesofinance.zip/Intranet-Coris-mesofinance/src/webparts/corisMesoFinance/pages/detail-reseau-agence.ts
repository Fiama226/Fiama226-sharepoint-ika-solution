import { SIDEBAR_HTML } from '../components/Sidebar';

export const DETAIL_RESEAU_AGENCE_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="row" id="detail-reseau-agence-content">
                            <div class="col-md-12 text-center p-5">
                                <div class="skeleton-card">
                                  <div class="skeleton skeleton-circle"></div>
                                  <div class="skeleton-card-body">
                                    <div class="skeleton skeleton-line"></div>
                                    <div class="skeleton skeleton-line-sm"></div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('dra')}
            </div>
        </div>
    </div>
</section>

`;
