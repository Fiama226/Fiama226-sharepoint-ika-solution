
export const PAGE_404_HTML = `

<section class="d-flex align-items-center justify-content-center" style="min-height:70vh">
  <div class="text-center">
    <h1 style="font-size:120px;font-weight:700;color:#004991">404</h1>
    <p style="font-size:18px;color:#6c757d;margin-bottom:30px">La page que vous recherchez n'existe pas.</p>
    <a href="#page-accueil" class="btn btn-primary" style="background:#004991;border-color:#004991;padding:10px 30px;font-size:16px;border-radius:8px">
      Retour &agrave; l&apos;accueil
    </a>
  </div>
</section>


`;
