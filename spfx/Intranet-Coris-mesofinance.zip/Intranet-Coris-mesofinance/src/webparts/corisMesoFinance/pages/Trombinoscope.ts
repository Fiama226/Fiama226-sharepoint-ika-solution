import { SIDEBAR_HTML } from '../components/Sidebar';

export const TROMBINOSCOPE_HTML = `
<style>
    .card {
        border: none;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease-in-out;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    }
    .card-img-top {
        height: 200px;
        object-fit: cover;
    }
    .contact-info {
        margin-top: 10px;
    }
</style>
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">TROMBINOSCOPE</h1>
                        <br>
                        <div class="row">
                            <div class="col-md-6">
                                <form class="d-flex" id="searchByNameForm">
                                    <input class="form-control me-2" type="search" id="searchByNameInput" placeholder="Rechercher par nom" aria-label="Search">
                                    <button class="btn btn-primary" type="submit">Chercher</button>
                                </form>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12" id="trombinoscope-letter-buttons">
                                <button class="btn btn-primary" type="submit">A</button>
                                <button class="btn btn-primary" type="submit">B</button>
                                <button class="btn btn-primary" type="submit">C</button>
                                <button class="btn btn-primary" type="submit">D</button>
                                <button class="btn btn-primary" type="submit">E</button>
                                <button class="btn btn-primary" type="submit">F</button>
                                <button class="btn btn-primary" type="submit">G</button>
                                <button class="btn btn-primary" type="submit">H</button>
                                <button class="btn btn-primary" type="submit">I</button>
                                <button class="btn btn-primary" type="submit">J</button>
                                <button class="btn btn-primary" type="submit">K</button>
                                <button class="btn btn-primary" type="submit">L</button>
                                <button class="btn btn-primary" type="submit">M</button>
                                <button class="btn btn-primary" type="submit">N</button>
                                <button class="btn btn-primary" type="submit">O</button>
                                <button class="btn btn-primary" type="submit">P</button>
                                <button class="btn btn-primary" type="submit">Q</button>
                                <button class="btn btn-primary" type="submit">R</button>
                                <button class="btn btn-primary" type="submit">S</button>
                                <button class="btn btn-primary" type="submit">T</button>
                                <button class="btn btn-primary" type="submit">U</button>
                                <button class="btn btn-primary" type="submit">V</button>
                                <button class="btn btn-primary" type="submit">W</button>
                                <button class="btn btn-primary" type="submit">X</button>
                                <button class="btn btn-primary" type="submit">Y</button>
                                <button class="btn btn-primary" type="submit">Z</button>
                            </div>
                        </div>
                        <br><br>
                        <div class="row" id="trombinoscope-content">
                            <div class="p-5">
                                <div class="skeleton-card">
                                  <div class="skeleton skeleton-circle"></div>
                                  <div class="skeleton-card-body">
                                    <div class="skeleton skeleton-line"></div>
                                    <div class="skeleton skeleton-line-sm"></div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('trom')}
            </div>
        </div>
    </div>
</section>

`;
