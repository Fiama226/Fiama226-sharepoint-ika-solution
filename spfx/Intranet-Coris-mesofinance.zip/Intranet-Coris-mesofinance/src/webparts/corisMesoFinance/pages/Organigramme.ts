import { SIDEBAR_HTML } from '../components/Sidebar';

export const ORGANIGRAMME_HTML = `
<section class="mt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="all-articles-box">
                    <div class="group-single">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="group-single-title mb-4">
                                    <h1 style="color: #E40E20; font-weight: bold; margin-left: 20px;">ORGANIGRAMME</h1>
                                    <br>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div id="chart-container">
                                    <div class="p-5">
                                        <div class="skeleton-card">
                                          <div class="skeleton skeleton-circle"></div>
                                          <div class="skeleton-card-body">
                                            <div class="skeleton skeleton-line"></div>
                                            <div class="skeleton skeleton-line-sm"></div>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                ${SIDEBAR_HTML('org')}
            </div>
        </div>
    </div>
</section>

`;
