declare module '*.module.scss' {
  const content: { [className: string]: string };
  export default content;
}

declare module 'CorisMesoFinanceWebPartStrings' {
  const strings: {
    PropertyPaneDescription: string;
    BasicGroupName: string;
    DescriptionFieldLabel: string;
    AppLocalEnvironmentSharePoint: string;
    AppSharePointEnvironment: string;
    AppLocalEnvironmentTeams: string;
    AppTeamsTabEnvironment: string;
    AppLocalEnvironmentOffice: string;
    AppOfficeEnvironment: string;
    AppLocalEnvironmentOutlook: string;
    AppOutlookEnvironment: string;
    UnknownEnvironment: string;
  } = strings;
  export = strings;
}
