﻿(function () {
  var css = '\
#chart-container{position:relative;width:100%;overflow-x:auto;overflow-y:visible;min-height:400px;padding:20px 0;text-align:center}\
.orgchart{display:inline-block;text-align:center;user-select:none}\
.orgchart .nodes{display:flex;justify-content:center;align-items:flex-start;list-style:none;padding:0;margin:0;position:relative}\
.orgchart .nodes .nodes{position:relative}\
.orgchart .nodes .nodes::before{content:"";position:absolute;top:0;left:50%;width:2px;height:25px;background-color:#bbb;transform:translateX(-50%)}\
.orgchart .hierarchy{display:flex;flex-direction:column;align-items:center;position:relative;padding-top:50px;margin:0 12px}\
.orgchart .hierarchy::before{content:"";position:absolute;top:25px;left:50%;width:2px;height:25px;background-color:#bbb;transform:translateX(-50%)}\
.orgchart .hierarchy::after{content:"";position:absolute;top:25px;left:-12px;right:-12px;height:2px;background-color:#bbb}\
.orgchart .hierarchy:first-child::after{left:50%;right:-12px}\
.orgchart .hierarchy:last-child::after{right:50%;left:-12px}\
.orgchart .hierarchy:only-child::after{display:none}\
.orgchart>.nodes>.hierarchy{padding-top:0;margin:0}\
.orgchart>.nodes>.hierarchy::before,.orgchart>.nodes>.hierarchy::after{display:none}\
.orgchart .node{border-radius:10px;text-align:center;min-width:120px;max-width:180px;z-index:1;position:relative;font-size:13px;line-height:1.3;cursor:default;box-shadow:0 2px 8px rgba(0,0,0,.12)}\
.orgchart .node .title{border-radius:10px 10px 0 0;padding:10px 12px 5px;font-weight:bold;text-align:center;min-height:40px;display:flex;flex-direction:column;align-items:center;justify-content:center}\
.orgchart .node .title .org-avatar{width:42px;height:42px;border-radius:50%;object-fit:cover;margin-bottom:6px;border:2px solid rgba(255,255,255,.4);display:block}\
.orgchart .node .content{border-radius:0 0 10px 10px;padding:5px 10px 10px;font-size:11px;line-height:1.4;text-align:center;border-top:1px solid rgba(0,0,0,.08)}\
.orgchart .node .content .org-svc{font-size:10px;margin-top:3px;opacity:.85}\
.orgchart .node .content .org-desc{font-size:10px;margin-top:2px;opacity:.7;font-style:italic}\
.orgchart .node .edge{display:none}\
@media(max-width:768px){.orgchart .node{min-width:100px;max-width:150px}.orgchart .node .title{font-size:11px;padding:8px 10px 4px}.orgchart .node .title .org-avatar{width:34px;height:34px}.orgchart .node .content{font-size:10px;padding:4px 8px 8px}.orgchart .hierarchy{padding-top:40px;margin:0 8px}.orgchart .nodes .nodes::before{height:20px}.orgchart .hierarchy::before{top:20px;height:20px}.orgchart .hierarchy::after{top:20px;left:-8px;right:-8px}.orgchart .hierarchy:first-child::after{left:50%;right:-8px}.orgchart .hierarchy:last-child::after{right:50%;left:-8px}}\
';
  var s = document.createElement('style');
  s.type = 'text/css';
  s.styleSheet ? (s.styleSheet.cssText = css) : s.appendChild(document.createTextNode(css));
  document.head.appendChild(s);
})();
