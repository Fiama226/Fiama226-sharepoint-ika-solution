﻿(function (window) {
  'use strict';

  var KNOWN_FIELDS = [
    'FileSystemObjectType','Id','ServerRedirectedEmbedUri','ServerRedirectedEmbedUrl',
    'ContentTypeId','OData__ColorTag','ComplianceAssetId','ManagerId','ManagerStringId',
    'ID','Modified','Created','AuthorId','EditorId','OData__UIVersionString',
    'Attachments','GUID'
  ];

  window.initOrgChart = function (options) {
    var container = (options && options.container) || '#chart-container';
    var siteUrl = (options && options.siteUrl) || (typeof _spPageContextInfo !== 'undefined' ? _spPageContextInfo.webAbsoluteUrl : '');
    if (!siteUrl) { $(container).html('<p class="text-center text-muted p-5">Erreur : URL du site non disponible.</p>'); return; }

    loadOrgChartData(siteUrl).then(function (items) {
      if (items && items.length > 0) renderOrgChart(items, container);
      else $(container).html('<p class="text-center text-muted p-5">Aucun élément actif.</p>');
    }).catch(function (err) {
      console.error('[Orgchart]', err);
      $(container).html('<p class="text-center text-muted p-5">Erreur de chargement.</p>');
    });
  };

  function loadOrgChartData(siteUrl) {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: siteUrl + "/_api/lists/getbytitle('Organigramme')/items?$select=*&$filter=Active eq 'Yes'&$orderby=Id&$top=1000",
        headers: { Accept: "application/json;odata=nometadata" },
        success: function (data) {
          var results = data.value || [];
          if (!results.length) { resolve([]); return; }

          var sampleKeys = Object.keys(results[0]);
          var parentKey = detectParentField(sampleKeys, results[0]);

          var items = results.map(function (item) {
            var img = parseManagerPicture(item.ManagerPicture);
            var mgr = parseManager(item.Manager);
            var ref = parseParentRef(item, parentKey);

            return {
              id: item.Id,
              name: item.Title || '',
              parentTitle: ref,
              manager: mgr,
              imageUrl: img,
              services: item.ServicesListe || '',
              description: item.Description || '',
              colorCode: item.ColorCode || '',
              bgColor: item.BGColor || ''
            };
          });

          resolve(items);
        },
        error: function (xhr, s, e) { reject(e || new Error(s)); }
      });
    });
  }

  function detectParentField(keys, sample) {
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].toLowerCase().indexOf('parent') >= 0) return keys[i];
    }
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (KNOWN_FIELDS.indexOf(k) >= 0) continue;
      if (k === 'Title' || k === 'ServicesListe' || k === 'Description' || k === 'ColorCode' || k === 'BGColor' || k === 'ManagerPicture' || k === 'Active') continue;
      return k;
    }
    return '';
  }

  function parseParentRef(item, parentKey) {
    if (!parentKey) return '';
    var raw = item[parentKey];
    if (raw === null || raw === undefined) return '';
    if (typeof raw === 'string') return raw.trim();
    if (typeof raw === 'number') return '';
    if (Array.isArray(raw) && raw.length > 0) return String(raw[0].Title || raw[0].Value || raw[0].LookupValue || '');
    if (typeof raw === 'object') return String(raw.Title || raw.Value || raw.LookupValue || raw.Label || '');
    return '';
  }

  function parseManagerPicture(val) {
    if (!val) return '';
    try {
      var obj = JSON.parse(val);
      if (obj && obj.serverRelativeUrl) return (obj.serverUrl || '') + obj.serverRelativeUrl;
    } catch (e) {}
    return val !== '#' ? val : '';
  }

  function parseManager(val) {
    if (!val) return '';
    if (typeof val === 'object' && val.Title) return val.Title;
    if (typeof val === 'string') return val;
    return '';
  }

  function buildHierarchy(items) {
    var roots = [];
    var titleMap = {};
    items.forEach(function (it) { it.children = []; });
    items.forEach(function (it) { if (it.name) titleMap[it.name.toLowerCase()] = it; });

    items.forEach(function (it) {
      if (it.parentTitle) {
        var parent = titleMap[it.parentTitle.toLowerCase()];
        if (parent) { parent.children.push(it); return; }
      }
      roots.push(it);
    });
    return roots;
  }

  function centerChart(container) {
    var el = $(container)[0];
    if (el && el.scrollWidth > el.clientWidth) {
      $(container).scrollLeft((el.scrollWidth - el.clientWidth) / 2);
    }
  }

  function renderOrgChart(items, container) {
    var roots = buildHierarchy(items);
    if (roots.length === 0) { $(container).html('<p class="text-center text-muted p-5">Aucun élément racine.</p>'); return; }

    var data = roots.length === 1 ? roots[0] : { id: 0, name: 'Organigramme', children: roots };
    var $c = $(container).empty();

    if (typeof $c.orgchart !== 'function') {
      $(container).html('<p class="text-center text-muted p-5">Plugin orgchart non chargé.</p>');
      return;
    }

    $c.orgchart({
      data: data,
      nodeTitle: 'name',
      nodeContent: 'manager',
      nodeID: 'id',
      toggleSiblingsResp: false,
      verticalLevel: 5,
      createNode: function ($node, d) {
        var bg = d.bgColor || '#e5e5e5';
        var fg = d.colorCode || '#333';
        $node.find('.title').css({ 'background-color': bg, color: fg });
        $node.find('.content').css({ 'background-color': bg, color: fg });
        if (d.imageUrl) $node.find('.title').prepend('<img class="org-avatar" src="' + d.imageUrl + '" />');
        var extra = '';
        if (d.services) extra += '<div class="org-svc">' + d.services + '</div>';
        if (d.description) extra += '<div class="org-desc">' + d.description + '</div>';
        if (extra) $node.find('.content').append(extra);
      },
      initCompleted: function () {
        centerChart(container);
      }
    });

    $(container + ' .edge').remove();
    setTimeout(function () { centerChart(container); }, 100);
    setTimeout(function () { centerChart(container); }, 500);
  }

})(window);
